# plan.md '7. 완성의 기준'을 휴대폰 크기 브라우저에서 실제로 눌러 보며 확인한다.
# 실행: python tests\check_plan.py   (index.html은 고치지 않고 읽기만 한다)
import json
import shutil
import sys
import tempfile
import traceback
from datetime import date
from pathlib import Path

from playwright.sync_api import sync_playwright

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
URL = (ROOT / 'index.html').as_uri()
KEY = 'hikingRecords.v1'
PHONE = dict(viewport={'width': 360, 'height': 780}, device_scale_factor=3,
             is_mobile=True, has_touch=True, locale='ko-KR')

TODAY = date.today().isoformat()
Y = date.today().year          # 올해
L = Y - 1                      # 작년


def fmt_dur(m):
    h, mm = divmod(m, 60)
    if h and mm:
        return f'{h}시간 {mm}분'
    if h:
        return f'{h}시간'
    if mm:
        return f'{mm}분'
    return '0시간'


def rec(i, d, mountain, course='코스', dur=120, rating=3, memo='', comp=''):
    return {'id': f'h_{1700000000000 + i}', 'date': d, 'mountain': mountain, 'course': course,
            'durationMin': dur, 'rating': rating, 'memo': memo, 'companions': comp}


# ---------- 앱을 다루는 도우미 ----------
class App:
    def __init__(self, page):
        self.page = page
        self.dialogs = []        # (종류, 문구)
        self.answer = True       # 확인창에서 '확인'을 누를지
        page.on('dialog', self._dialog)

    def _dialog(self, d):
        self.dialogs.append((d.type, d.message))
        d.accept() if self.answer else d.dismiss()

    def open(self):
        self.page.goto(URL)
        self.wait_home()

    def seed(self, records):
        self.page.evaluate('([k, v]) => localStorage.setItem(k, v)', [KEY, json.dumps(records, ensure_ascii=False)])
        self.page.reload()
        self.wait_home()

    def stored(self):
        return json.loads(self.page.evaluate('k => localStorage.getItem(k)', KEY) or '[]')

    def wait_home(self):
        self.page.wait_for_selector('#vHome:not(.hidden)')

    def wait_form(self):
        self.page.wait_for_selector('#vForm:not(.hidden)')

    def fill_form(self, d=None, mountain=None, course=None, h=None, m=None, rating=None, memo=None, comp=None):
        p = self.page
        if d is not None:
            p.fill('#fDate', d)
        if mountain is not None:
            p.fill('#fMountain', mountain)
        if course is not None:
            p.fill('#fCourse', course)
        if h is not None:
            p.select_option('#fH', str(h))
        if m is not None:
            p.select_option('#fM', str(m))
        if rating is not None:
            p.click(f'.star[data-v="{rating}"]')
        if memo is not None:
            p.fill('#fMemo', memo)
        if comp is not None:
            p.fill('#fComp', comp)

    def add(self, d=None, mountain='북한산', course='우이동 → 백운대', h=2, m=30, rating=4, memo=None, comp=None):
        self.page.click('#addBtn')
        self.wait_form()
        self.fill_form(d, mountain, course, h, m, rating, memo, comp)
        self.page.click('#saveBtn')
        self.wait_home()

    def cards(self):
        return self.page.eval_on_selector_all('#list .card', '''els => els.map(e => ({
            id: e.dataset.id,
            date: e.querySelector('.top span').textContent,
            mountain: e.querySelector('.mt').textContent,
            stars: e.querySelector('.stars-s').getAttribute('aria-label'),
            course: e.querySelector('.course').textContent,
            text: e.innerText}))''')

    def mountains(self):
        return [c['mountain'] for c in self.cards()]

    def summary(self):
        p = self.page
        return (p.text_content('#sumYear'), p.text_content('#sumCount'), p.text_content('#sumTime'))

    def list_text(self):
        return self.page.inner_text('#list')

    def people(self):
        return self.page.eval_on_selector_all('#peopleList .chip', 'els => els.map(e => e.textContent)')

    def options(self, datalist_id):
        return self.page.eval_on_selector_all(f'#{datalist_id} option', 'els => els.map(e => e.value)')

    def search(self, text):
        self.page.fill('#search', text)

    def year(self, value):
        self.page.select_option('#yearSel', str(value))


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def same(actual, expected, what):
    if actual != expected:
        raise AssertionError(f'{what}: 기대 {expected!r}, 실제 {actual!r}')


# ---------- 완성의 기준 하나하나 ----------
TESTS = []


def test(text):
    def deco(fn):
        TESTS.append((text, fn))
        return fn
    return deco


@test('휴대폰 브라우저에서 HTML 파일을 열면 홈 화면이 가로 스크롤 없이 보인다.')
def t_no_hscroll(app):
    long = '아주아주긴산이름' * 6
    app.open()
    app.seed([rec(1, TODAY, long, '가' * 80, 1439, 5, comp='김' * 40 + ', 민수'),
              rec(2, f'{L}-05-05', '북한산', '우이동 → 백운대 → 우이동 → 도선사 → 하루재', 270, 1)])
    app.page.click('#people summary')
    for w in (320, 360, 412):
        app.page.set_viewport_size({'width': w, 'height': 780})
        r = app.page.evaluate('''() => {
            const W = document.documentElement.clientWidth;
            const sw = document.documentElement.scrollWidth;
            const over = [...document.querySelectorAll('#vHome *, header *, #bHome *')].filter(e => {
                if (!e.offsetParent && getComputedStyle(e).position !== 'fixed') return false;
                const box = e.getBoundingClientRect();
                return box.width && box.right > W + 0.5;
            }).map(e => e.id || e.className || e.tagName);
            return {W, sw, over};
        }''')
        check(r['sw'] <= r['W'], f'폭 {w}px에서 화면이 옆으로 넓어짐 (scrollWidth {r["sw"]} > {r["W"]})')
        check(not r['over'], f'폭 {w}px에서 화면 밖으로 삐져나간 요소: {r["over"][:5]}')


@test('「기록하기」를 누르면 날짜 칸에 오늘 날짜가 이미 채워져 있다.')
def t_today(app):
    app.open()
    app.page.click('#addBtn')
    app.wait_form()
    same(app.page.input_value('#fDate'), TODAY, '날짜 칸')


@test('필수 항목 중 하나라도 비우고 「저장」을 누르면 저장되지 않고 빈 칸이 표시된다. 메모와 함께 간 사람은 비워도 저장된다.')
def t_required(app):
    app.open()
    full = dict(d=TODAY, mountain='북한산', course='우이동', h=2, m=0, rating=4)
    cases = {'wDate': 'd', 'wMountain': 'mountain', 'wCourse': 'course', 'wDur': ('h', 'm'), 'wRating': 'rating'}
    for wrap, keys in cases.items():
        keys = keys if isinstance(keys, tuple) else (keys,)
        app.page.click('#addBtn')
        app.wait_form()
        args = {k: v for k, v in full.items() if k not in keys}
        if 'd' in keys:
            args['d'] = ''
        app.fill_form(**args)
        app.page.click('#saveBtn')
        check(app.page.is_visible('#vForm'), f'{wrap}를 비웠는데 입력 화면을 벗어남')
        bad = app.page.eval_on_selector_all('.field.invalid', 'els => els.map(e => e.id)')
        same(bad, [wrap], '빨갛게 표시된 칸')
        same(len(app.stored()), 0, f'{wrap}를 비웠을 때 저장된 기록 수')
        app.page.click('#backBtn')
        app.wait_home()
    # 공백만 넣은 산 이름·코스도 빈 칸으로 본다
    app.page.click('#addBtn')
    app.wait_form()
    app.fill_form(**dict(full, mountain='   ', course='  '))
    app.page.click('#saveBtn')
    bad = app.page.eval_on_selector_all('.field.invalid', 'els => els.map(e => e.id)')
    same(bad, ['wMountain', 'wCourse'], '공백만 넣었을 때 빨갛게 표시된 칸')
    app.page.click('#backBtn')
    app.wait_home()
    # 메모·함께 간 사람은 비워도 저장
    app.add(TODAY, '북한산', '우이동', 2, 0, 4)
    s = app.stored()
    same(len(s), 1, '메모·함께 간 사람 없이 저장한 기록 수')
    same((s[0]['memo'], s[0]['companions']), ('', ''), '메모·함께 간 사람 값')


@test('저장하면 홈으로 돌아오고, 방금 기록이 목록 맨 위에 보인다.')
def t_save_top(app):
    app.open()
    app.seed([rec(1, f'{L}-10-01', '관악산'), rec(2, f'{Y}-01-01', '도봉산')])
    app.add(mountain='청계산', course='원터골')
    check(app.page.is_visible('#vHome'), '저장 뒤 홈으로 돌아오지 않음')
    same(app.mountains()[0], '청계산', '목록 맨 위')


@test('검색어나 연도를 고른 채로 새 기록을 저장해도 검색 칸이 비워지고 연도가 \'전체 연도\'로 돌아가 방금 기록이 맨 위에 보인다.')
def t_save_resets_filter(app):
    app.open()
    app.seed([rec(1, f'{L}-10-01', '설악산'), rec(2, f'{Y}-01-01', '도봉산')])
    app.search('설악')
    app.year(L)
    same(app.mountains(), ['설악산'], '거른 목록')
    app.add(mountain='청계산', course='원터골')
    same(app.page.input_value('#search'), '', '검색 칸')
    same(app.page.input_value('#yearSel'), '', '연도 칸')
    same(app.mountains()[0], '청계산', '목록 맨 위')
    same(len(app.cards()), 3, '보이는 카드 수')


@test('날짜를 일부러 과거로 넣은 기록은 날짜 순서에 맞는 자리에 끼어 보인다.')
def t_past_order(app):
    app.open()
    app.add(f'{L}-09-01', '가산')
    app.add(f'{L}-03-01', '나산')
    app.add(f'{L}-06-01', '다산')
    app.add(f'{L}-06-01', '라산')   # 같은 날짜면 나중에 넣은 것이 위
    same(app.mountains(), ['가산', '라산', '다산', '나산'], '목록 순서')


@test('올해 기록을 하나 추가하면 상단 횟수가 1 늘고, 총 시간이 입력한 만큼 늘어난다.')
def t_summary_add(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '도봉산', dur=95), rec(2, f'{L}-05-05', '관악산', dur=60)])
    same(app.summary(), (f'{Y}년', '1회', fmt_dur(95)), '추가 전 요약')
    app.add(mountain='북한산', h=3, m=45)
    same(app.summary(), (f'{Y}년', '2회', fmt_dur(95 + 225)), '추가 후 요약')


@test('작년 날짜 기록은 목록에는 보이지만 올해 요약 숫자에는 더해지지 않는다.')
def t_last_year(app):
    app.open()
    app.add(TODAY, '북한산', h=1, m=0)
    before = app.summary()
    app.add(f'{L}-12-31', '관악산', h=5, m=0)
    check('관악산' in app.mountains(), '작년 기록이 목록에 없음')
    same(app.summary(), before, '작년 기록 추가 뒤 올해 요약')


@test('카드를 눌러 별점을 바꾸고 저장하면 목록에 바뀐 별점이 보인다.')
def t_edit_rating(app):
    app.open()
    app.add(mountain='북한산', rating=4)
    app.page.click('#list .card')
    app.wait_form()
    check(app.page.is_visible('#delBtn'), '수정 화면에 「삭제」 버튼이 없음')
    app.page.click('.star[data-v="2"]')
    app.page.click('#saveBtn')
    app.wait_home()
    same(app.cards()[0]['stars'], '별점 2점', '카드 별점')
    same(len(app.cards()), 1, '카드 수 (수정이 새 기록으로 늘면 안 됨)')


@test('「삭제」를 누르면 확인창이 뜨고, 확인하면 목록과 요약에서 사라진다.')
def t_delete(app):
    app.open()
    app.add(TODAY, '북한산', h=2, m=0)
    app.add(TODAY, '도봉산', h=1, m=0)
    app.page.click('#list .card >> text=도봉산')
    app.wait_form()
    app.answer = False
    app.page.click('#delBtn')
    same([t for t, _ in app.dialogs], ['confirm'], '뜬 창')
    check(app.page.is_visible('#vForm'), '취소했는데 화면이 바뀜')
    same(len(app.stored()), 2, '취소 뒤 기록 수')
    app.answer = True
    app.page.click('#delBtn')
    app.wait_home()
    same(app.mountains(), ['북한산'], '삭제 뒤 목록')
    same(app.summary()[1:], ('1회', fmt_dur(120)), '삭제 뒤 요약')


@test('브라우저를 완전히 닫았다가 다시 열어도 기록이 그대로 있다.')
def t_reopen(app, pw):
    folder = tempfile.mkdtemp(prefix='hiking-test-')
    try:
        ctx = pw.chromium.launch_persistent_context(folder, **PHONE)
        a = App(ctx.new_page())
        a.open()
        a.add(TODAY, '북한산', '우이동', 4, 30, 5, '단풍 절정', '민수, 지영')
        before = (a.cards(), a.summary())
        ctx.close()
        ctx = pw.chromium.launch_persistent_context(folder, **PHONE)
        b = App(ctx.new_page())
        b.open()
        same((b.cards(), b.summary()), before, '다시 연 뒤 목록·요약')
        ctx.close()
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def export_file(app, out_dir):
    app.page.click('#backupBtn')
    app.page.wait_for_selector('#vBackup:not(.hidden)')
    with app.page.expect_download() as dl:
        app.page.click('#exportBtn')
    d = dl.value
    path = Path(out_dir) / d.suggested_filename
    d.save_as(path)
    return d.suggested_filename, path


@test('「내보내기」를 누르면 JSON 파일이 저장된다.')
def t_export(app, tmp):
    app.open()
    app.add(TODAY, '북한산', comp='민수')
    app.add(f'{L}-06-01', '관악산', memo='"따옴표" <태그> & 기호')
    name, path = export_file(app, tmp)
    same(name, f'hiking-backup-{TODAY}.json', '파일 이름')
    same(json.loads(path.read_text(encoding='utf-8')), app.stored(), '파일 내용 (저장된 기록과 같아야 함)')
    same(app.page.text_content('#lastExport'), f'마지막 내보낸 날짜: {TODAY}', '마지막 내보낸 날짜')


@test('다른 기기(또는 저장소를 지운 브라우저)에서 그 파일을 「불러오기」 하면 목록과 요약이 원래와 똑같이 보인다.')
def t_import(app, tmp, browser):
    app.open()
    app.add(TODAY, '북한산', '우이동', 4, 30, 5, '단풍', '민수, 지영')
    app.add(f'{Y}-01-01', '도봉산', '도봉탐방', 3, 0, 3, '', '민수')
    app.add(f'{L}-06-01', '관악산', '서울대', 2, 15, 2)
    want = (app.cards(), app.summary(), app.people())
    _, path = export_file(app, tmp)

    ctx = browser.new_context(**PHONE)
    try:
        b = App(ctx.new_page())
        b.open()
        same(b.cards(), [], '새 브라우저의 처음 목록')
        b.page.click('#backupBtn')
        with b.page.expect_file_chooser() as fc:
            b.page.click('#importBtn')
        fc.value.set_files(str(path))
        b.wait_home()
        same([t for t, _ in b.dialogs], ['confirm', 'alert'], '뜬 창 (확인창 → 완료 안내)')
        check('바뀝니다' in b.dialogs[0][1], f'확인창 문구: {b.dialogs[0][1]!r}')
        same((b.cards(), b.summary(), b.people()), want, '불러온 뒤 목록·요약·함께 간 사람')
    finally:
        ctx.close()


@test('엉뚱한 파일을 불러오면 오류 안내가 뜨고 기존 기록은 지워지지 않는다.')
def t_bad_import(app, tmp):
    app.open()
    app.add(TODAY, '북한산')
    app.add(f'{L}-06-01', '관악산')
    want = (app.stored(), app.cards(), app.summary())
    good = rec(1, TODAY, '설악산')
    bad_files = {
        '글자.json': '이건 JSON이 아님',
        '빈파일.json': '',
        '객체.json': json.dumps({'records': [good]}),
        '별점7.json': json.dumps([dict(good, rating=7)]),
        '시간0.json': json.dumps([dict(good, durationMin=0)]),
        '날짜형식.json': json.dumps([dict(good, date='2026/10/25')]),
        '산이름없음.json': json.dumps([dict(good, mountain='')]),
        '같은id.json': json.dumps([good, dict(good, mountain='지리산')]),
        '사진.png': '\x89PNG\r\n',
    }
    for fname, body in bad_files.items():
        f = Path(tmp) / fname
        f.write_text(body, encoding='utf-8')
        app.dialogs.clear()
        app.page.click('#backupBtn')
        app.page.set_input_files('#fileInput', str(f))
        for _ in range(50):          # 파일을 읽고 안내창이 뜰 때까지 최대 5초
            if app.dialogs:
                break
            app.page.wait_for_timeout(100)
        app.page.wait_for_timeout(200)   # 뒤이어 다른 창이 뜨지 않는지도 본다
        same([t for t, _ in app.dialogs], ['alert'], f'{fname}: 뜬 창')
        check('불러올 수 없는 파일' in app.dialogs[0][1], f'{fname}: 안내 문구 {app.dialogs[0][1]!r}')
        app.page.click('#backBtn')
        app.wait_home()
        same((app.stored(), app.cards(), app.summary()), want, f'{fname}: 불러오기 실패 뒤 기록')


@test('산 이름 칸 자동완성 후보에 전에 다녀온 산 이름이 들어 있고, 같은 산은 한 번만 있다.')
def t_mountain_suggest(app):
    app.open()
    app.seed([rec(1, f'{L}-01-01', '북한산'), rec(2, f'{L}-02-01', '도봉산'),
              rec(3, f'{Y}-01-01', '북한산'), rec(4, f'{L}-03-01', '북한산')])
    app.page.click('#addBtn')
    app.wait_form()
    same(app.options('mountainList'), ['북한산', '도봉산'], '산 이름 후보')
    same(app.page.get_attribute('#fMountain', 'list'), 'mountainList', '산 이름 칸과 후보 연결')


@test('홈 검색 칸에 산 이름의 일부("북한")를 넣으면 그 글자가 들어간 기록만 남고, 검색 칸을 비우면 전체 목록이 다시 보인다.')
def t_search(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산'), rec(2, f'{Y}-01-02', '도봉산'),
              rec(3, f'{L}-01-03', '남북한산성'), rec(4, f'{L}-01-04', '관악산')])
    every = app.mountains()
    app.search('북한')
    same(sorted(app.mountains()), sorted(['북한산', '남북한산성']), '"북한" 검색 결과')
    app.search('')
    same(app.mountains(), every, '검색 칸을 비운 뒤 목록')


@test('홈 검색은 띄어쓰기를 무시한다. \'북한산\'으로 찾아도 \'북한 산\'으로 적은 기록이 나오고, \'북한 산\'으로 찾아도 \'북한산\' 기록이 나온다.')
def t_search_space(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산'), rec(2, f'{Y}-01-02', '북한 산성'),
              rec(3, f'{L}-01-03', '도봉산')])
    every = app.mountains()
    for q in ('북한산', '북한 산', '북 한산', ' 한 산 '):
        app.search(q)
        same(sorted(app.mountains()), sorted(['북한산', '북한 산성']), f'"{q}" 검색 결과')
    app.search('도 봉 산')
    same(app.mountains(), ['도봉산'], '"도 봉 산" 검색 결과')
    app.search('   ')
    same(app.mountains(), every, '띄어쓰기만 넣었을 때 목록')


@test('검색 중에도 상단 올해 요약 숫자는 바뀌지 않는다.')
def t_search_summary(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', dur=100), rec(2, f'{Y}-01-02', '도봉산', dur=50),
              rec(3, f'{L}-01-03', '관악산')])
    before = app.summary()
    for q in ('북한', '도봉', '없는산', ''):
        app.search(q)
        same(app.summary(), before, f'"{q}" 검색 중 요약')


@test('맞는 기록이 없으면 "기록이 없어요" 안내가 보이고, 검색 결과 카드를 눌러 수정·저장하고 돌아와도 검색어와 걸러진 목록이 그대로 있다.')
def t_search_keep(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', rating=3), rec(2, f'{Y}-01-02', '도봉산'),
              rec(3, f'{L}-01-03', '북한산', rating=1)])
    app.search('지리')
    check('기록이 없어요' in app.list_text(), f'안내 문구 없음: {app.list_text()!r}')
    same(app.cards(), [], '맞는 기록이 없을 때 카드')
    app.search('북한')
    filtered = app.mountains()
    app.page.click('#list .card')
    app.wait_form()
    app.page.click('.star[data-v="5"]')
    app.page.click('#saveBtn')
    app.wait_home()
    same(app.page.input_value('#search'), '북한', '돌아온 뒤 검색 칸')
    same(app.mountains(), filtered, '돌아온 뒤 목록')
    same(app.cards()[0]['stars'], '별점 5점', '수정한 카드 별점')


@test('연도 칸에는 기록이 있는 연도만 최근 연도부터 보이고, 처음에는 \'전체 연도\'로 되어 있다.')
def t_year_options(app):
    app.open()
    check(app.page.is_hidden('#filters'), '기록이 없는데 검색·연도 칸이 보임')
    app.seed([rec(1, f'{L - 3}-05-01', '가산'), rec(2, f'{Y}-01-01', '나산'),
              rec(3, f'{L}-05-01', '다산'), rec(4, f'{L}-07-01', '라산')])
    opts = app.page.eval_on_selector_all('#yearSel option', 'els => els.map(e => [e.value, e.textContent])')
    same(opts, [['', '전체 연도'], [str(Y), f'{Y}년'], [str(L), f'{L}년'], [str(L - 3), f'{L - 3}년']], '연도 칸 목록')
    same(app.page.input_value('#yearSel'), '', '처음 고른 연도')


@test('연도 칸에서 작년을 고르면 작년 기록만 남고 올해 요약은 그대로다. \'전체 연도\'로 돌리면 전체 목록이 다시 보인다.')
def t_year_filter(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산'), rec(2, f'{L}-05-01', '관악산'),
              rec(3, f'{L}-07-01', '도봉산'), rec(4, f'{L - 1}-07-01', '설악산')])
    every, before = app.mountains(), app.summary()
    app.year(L)
    same(app.mountains(), ['도봉산', '관악산'], '작년만 고른 목록')
    same(app.summary(), before, '작년을 고른 뒤 올해 요약')
    app.year('')
    same(app.mountains(), every, '전체 연도로 돌린 목록')


@test('연도를 고른 채 검색 칸에 산 이름을 넣으면 그해의 그 산 기록만 남는다.')
def t_year_and_search(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산'), rec(2, f'{L}-05-01', '북한산'),
              rec(3, f'{L}-07-01', '도봉산'), rec(4, f'{L}-08-01', '북한산')])
    app.year(L)
    app.search('북한')
    got = app.cards()
    same([(c['mountain'], c['id']) for c in got], [('북한산', 'h_1700000000004'), ('북한산', 'h_1700000000002')],
         '작년 + "북한" 결과')


@test('함께 간 사람에 "민수, 지영"과 "민수"를 넣은 기록이 있으면, 「함께 간 사람」을 펼쳤을 때 민수 2회가 지영 1회보다 앞에 보인다.')
def t_people_order(app):
    app.open()
    app.add(TODAY, '북한산', comp='민수, 지영')
    app.add(TODAY, '도봉산', comp='민수')
    check(app.page.is_visible('#people'), '「함께 간 사람」 칸이 안 보임')
    check(not app.page.is_visible('#peopleList'), '처음부터 펼쳐져 있음')
    app.page.click('#people summary')
    check(app.page.is_visible('#peopleList'), '눌러도 펼쳐지지 않음')
    same(app.people(), ['민수 2회', '지영 1회'], '사람별 횟수')


@test('연도 칸에서 작년을 고르면 「함께 간 사람」 횟수도 작년 기록만으로 다시 세어지고, 검색어를 넣어도 횟수는 바뀌지 않는다.')
def t_people_year(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', comp='민수, 지영'), rec(2, f'{Y}-02-01', '도봉산', comp='민수'),
              rec(3, f'{L}-05-01', '관악산', comp='철수, 지영'), rec(4, f'{L}-06-01', '북한산', comp='철수')])
    app.page.click('#people summary')
    same(app.people(), ['민수 2회', '지영 2회', '철수 2회'], '전체 연도 횟수')
    app.year(L)
    same(app.people(), ['철수 2회', '지영 1회'], '작년 횟수')
    for q in ('관악', '없는산', ''):
        app.search(q)
        same(app.people(), ['철수 2회', '지영 1회'], f'작년 + "{q}" 검색 중 횟수')


@test('함께 간 사람이 적힌 기록이 하나도 없으면 「함께 간 사람」 칸이 보이지 않는다.')
def t_people_hidden(app):
    app.open()
    app.add(TODAY, '북한산')
    app.add(TODAY, '도봉산', comp='   ')
    check(app.page.is_hidden('#people'), '함께 간 사람이 없는데 칸이 보임')
    app.add(TODAY, '관악산', comp='민수')
    check(app.page.is_visible('#people'), '함께 간 사람을 넣었는데 칸이 안 보임')


@test('「함께 간 사람」의 이름을 누르면 그 사람과 간 기록만 목록에 남고, 같은 이름을 다시 누르면 전체 목록이 돌아온다. 검색과 함께 쓸 수 있고, 새 기록을 저장하면 이름 거르기가 풀린다.')
def t_people_filter(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', comp='민수, 지영'), rec(2, f'{Y}-02-01', '도봉산', comp='민수'),
              rec(3, f'{Y}-03-01', '관악산', comp='지영'), rec(4, f'{L}-05-01', '설악산')])
    every, before = app.mountains(), app.summary()
    app.page.click('#people summary')
    app.page.click('#peopleList .chip[data-name="민수"]')
    same(sorted(app.mountains()), sorted(['북한산', '도봉산']), '민수와 간 기록')
    check('on' in app.page.get_attribute('#peopleList .chip[data-name="민수"]', 'class').split(), '선택한 이름이 강조되지 않음')
    same(app.summary(), before, '이름으로 거른 뒤 올해 요약')
    same(app.people(), ['민수 2회', '지영 2회'], '이름으로 거른 뒤 함께 간 사람 횟수')
    app.search('도봉')
    same(app.mountains(), ['도봉산'], '민수 + "도봉" 검색 결과')
    app.search('')
    app.page.click('#peopleList .chip[data-name="민수"]')
    same(app.mountains(), every, '같은 이름을 다시 누른 뒤 목록')
    check('on' not in app.page.get_attribute('#peopleList .chip[data-name="민수"]', 'class').split(), '다시 누른 뒤에도 강조됨')
    app.page.click('#peopleList .chip[data-name="지영"]')
    app.add(TODAY, '청계산')
    same(len(app.cards()), 5, '새 기록을 저장한 뒤 보이는 카드 수 (이름 거르기가 풀려야 함)')
    same(app.mountains()[0], '청계산', '새 기록이 목록 맨 위')


@test('「함께 간 사람」 이름을 고른 채 연도를 바꿔도 이름 거르기는 그대로이고, 그해에 그 사람과 간 기록이 없으면 안내가 보인다. 전체 연도로 돌리면 다시 그 사람 기록이 보인다.')
def t_people_year_keep(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', comp='민수, 지영'), rec(2, f'{Y}-02-01', '도봉산', comp='민수'),
              rec(3, f'{L}-05-01', '관악산', comp='지영'), rec(4, f'{L}-06-01', '설악산', comp='철수')])
    app.page.click('#people summary')
    app.page.click('#peopleList .chip[data-name="민수"]')
    same(sorted(app.mountains()), sorted(['북한산', '도봉산']), '민수와 간 기록 (전체 연도)')
    app.year(L)
    same(app.mountains(), [], '작년에 민수와 간 기록이 없을 때 카드')
    check('「민수」' in app.list_text() and '기록이 없어요' in app.list_text(), f'안내 문구 없음: {app.list_text()!r}')
    app.year('')
    same(sorted(app.mountains()), sorted(['북한산', '도봉산']), '전체 연도로 돌린 뒤 민수 기록')
    check('on' in app.page.get_attribute('#peopleList .chip[data-name="민수"]', 'class').split(), '전체 연도로 돌린 뒤 민수가 강조되지 않음')


@test('「함께 간 사람」을 접어도 제목에 고른 이름이 보이고, 이름을 다시 누르면 제목에서 사라진다.')
def t_people_title(app):
    app.open()
    app.seed([rec(1, f'{Y}-01-01', '북한산', comp='민수, 지영'), rec(2, f'{Y}-02-01', '도봉산', comp='민수')])
    same(app.page.text_content('#peopleTitle'), '함께 간 사람 (2명)', '처음 제목')
    app.page.click('#people summary')
    app.page.click('#peopleList .chip[data-name="민수"]')
    app.page.click('#people summary')
    check(not app.page.is_visible('#peopleList'), '접기가 되지 않음')
    same(app.page.text_content('#peopleTitle'), '함께 간 사람 (2명) · 「민수」만 보는 중', '접힌 제목 (이름을 고른 뒤)')
    app.page.click('#people summary')
    app.page.click('#peopleList .chip[data-name="민수"]')
    app.page.click('#people summary')
    same(app.page.text_content('#peopleTitle'), '함께 간 사람 (2명)', '이름을 다시 누른 뒤 제목')


def course_records():
    return [rec(1, f'{L}-01-01', '북한산', '우이동 코스'),
            rec(2, f'{L}-02-01', '북한산', '정릉 코스'),
            rec(3, f'{Y}-01-01', '북한산', '우이동 코스'),
            rec(4, f'{L}-03-01', '북한 산', '불광 코스'),
            rec(5, f'{L}-04-01', '설악산', '오색 코스')]


@test('산 이름 칸에 전에 다녀온 산(북한산)을 넣으면 그 산에서 다녀온 코스가 코스 칸 후보에 들어가고, 같은 코스는 한 번만 있다.')
def t_course_suggest(app):
    app.open()
    app.seed(course_records())
    app.page.click('#addBtn')
    app.wait_form()
    app.page.fill('#fMountain', '북한산')
    same(app.options('courseList'), ['우이동 코스', '불광 코스', '정릉 코스'], '북한산 코스 후보 (최근 순)')
    same(app.page.get_attribute('#fCourse', 'list'), 'courseList', '코스 칸과 후보 연결')


@test('산 이름을 \'북한 산\'으로 띄어 적은 기록의 코스도 산 이름 칸에 \'북한산\'을 넣으면 코스 후보에 나온다.')
def t_course_space(app):
    app.open()
    app.seed(course_records())
    app.page.click('#addBtn')
    app.wait_form()
    app.page.fill('#fMountain', '북한산')
    check('불광 코스' in app.options('courseList'), '북한산으로 넣었을 때 \'북한 산\' 코스가 없음')
    app.page.fill('#fMountain', '북 한 산')
    check('정릉 코스' in app.options('courseList'), '\'북 한 산\'으로 넣었을 때 북한산 코스가 없음')


@test('산 이름을 다른 산으로 바꾸면 코스 후보도 그 산의 코스로 바뀌고, 처음 가는 산이거나 산 이름이 비어 있으면 코스 후보가 뜨지 않는다.')
def t_course_change(app):
    app.open()
    app.seed(course_records())
    app.page.click('#addBtn')
    app.wait_form()
    same(app.options('courseList'), [], '산 이름이 비었을 때 코스 후보')
    app.page.fill('#fMountain', '북한산')
    app.page.fill('#fMountain', '설악산')
    same(app.options('courseList'), ['오색 코스'], '설악산으로 바꾼 뒤 코스 후보')
    app.page.fill('#fMountain', '한라산')
    same(app.options('courseList'), [], '처음 가는 산의 코스 후보')
    app.page.fill('#fMountain', '')
    same(app.options('courseList'), [], '산 이름을 지운 뒤 코스 후보')
    # 수정 화면도 열자마자 그 산의 코스 후보가 들어 있다
    app.page.click('#backBtn')
    app.wait_home()
    app.page.click('#list .card >> text=설악산')
    app.wait_form()
    same(app.options('courseList'), ['오색 코스'], '설악산 기록 수정 화면의 코스 후보')


# ---------- 실행 ----------
def main():
    if not (ROOT / 'index.html').exists():
        print(f'index.html을 찾지 못했습니다: {ROOT}')
        return 2
    passed, failed = 0, []
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        for i, (text, fn) in enumerate(TESTS, 1):
            ctx = browser.new_context(**PHONE, accept_downloads=True)
            page = ctx.new_page()
            errors = []
            page.on('pageerror', lambda e: errors.append(str(e)))
            tmp = tempfile.mkdtemp(prefix='hiking-test-')
            app = App(page)
            extra = {'pw': pw, 'tmp': tmp, 'browser': browser}
            names = fn.__code__.co_varnames[1:fn.__code__.co_argcount]
            try:
                fn(app, *[extra[n] for n in names])
                check(not errors, f'페이지 스크립트 오류: {errors}')
                passed += 1
                print(f'  통과  {i:2}. {text}')
            except Exception as e:
                failed.append(text)
                msg = str(e) if isinstance(e, AssertionError) else traceback.format_exc(limit=3)
                print(f'  실패  {i:2}. {text}\n         └ {msg.strip()}')
            finally:
                ctx.close()
                shutil.rmtree(tmp, ignore_errors=True)
        browser.close()
    print(f'\n결과: {len(TESTS)}개 중 {passed}개 통과, {len(failed)}개 실패')
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
