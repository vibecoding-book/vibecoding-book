// 테스트 공용 도구: 대시보드 핵심 로직 불러오기, 엑셀 '정답' 읽기, 헤드리스 브라우저 조종
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { spawn, spawnSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const DASHBOARD = path.join(ROOT, 'dashboard.html');
const BUDGET = path.join(ROOT, 'budget.html');
const FIXTURES = path.join(__dirname, 'fixtures');
// 테스트는 실제 '보고서' 폴더가 아니라 그 복사본(fixtures/원본)을 정답 자료로 씁니다.
const REPORT_DIR = path.join(FIXTURES, '원본');
const REPORTS = [42, 43, 44].map((w) => path.join(REPORT_DIR, `주간보고_${w}주.xlsx`));
const fixture = (name) => path.join(FIXTURES, name);

// HTML 파일 안의 <script id="core"> 블록을 그대로 실행해 핵심 로직 객체를 꺼냅니다.
function loadCore(file = DASHBOARD, name = 'HaneulCore') {
  const html = fs.readFileSync(file, 'utf8');
  const m = /<script id="core">([\s\S]*?)<\/script>/.exec(html);
  if (!m) throw new Error(`${path.basename(file)}에서 core 스크립트를 찾지 못했습니다`);
  vm.runInThisContext(m[1], { filename: path.basename(file) + '#core' });
  return globalThis[name];
}

// Python(표준 라이브러리)으로 엑셀을 따로 읽은 결과 = 정답
function readExcel(files) {
  const py = process.platform === 'win32' ? 'python' : 'python3';
  const r = spawnSync(py, ['-I', path.join(__dirname, 'read_excel.py'), ...files], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('read_excel.py 실패: ' + r.stderr);
  return JSON.parse(r.stdout);
}

function ensureFixtures() {
  const py = process.platform === 'win32' ? 'python' : 'python3';
  const r = spawnSync(py, ['-I', path.join(__dirname, 'make_fixtures.py')], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('make_fixtures.py 실패: ' + r.stderr);
}

// 메모의 "비용 +14.7%, 전환 +31건(+18.3%), 전환당 비용 -3.1% / 채널별 전환당 비용: 네이버 -0.5%, ..." 읽기
function parseMemo(memo) {
  const num = (re) => { const m = re.exec(memo); return m ? Number(m[1]) : null; };
  const channels = {};
  const tail = memo.split('채널별 전환당 비용:')[1] || '';
  for (const m of tail.matchAll(/([가-힣A-Za-z]+)\s*([+-]?\d+(?:\.\d+)?)%/g)) channels[m[1]] = Number(m[2]);
  return {
    costPct: num(/비용\s*([+-]?\d+(?:\.\d+)?)%/),
    convDiff: num(/전환\s*([+-]?\d+)건/),
    convPct: num(/전환\s*[+-]?\d+건\(([+-]?\d+(?:\.\d+)?)%\)/),
    cpaPct: num(/전환당 비용\s*([+-]?\d+(?:\.\d+)?)%/),
    channels,
  };
}

// 화면 글자 "2,443,512원", "▲ +14.7%" 등에서 숫자만 꺼내기
const digits = (s) => Number(String(s).replace(/[^\d.-]/g, ''));

// ---------- 헤드리스 브라우저 (Chrome DevTools Protocol) ----------
const BROWSERS = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
];
const findBrowser = () => BROWSERS.find((p) => fs.existsSync(p));
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function launchBrowser() {
  const exe = findBrowser();
  if (!exe) return null;
  const profile = path.join(__dirname, `.browser-profile-${process.pid}`);
  fs.rmSync(profile, { recursive: true, force: true });
  const proc = spawn(exe, [
    '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
    '--no-first-run', '--no-default-browser-check', '--disable-extensions',
    '--disable-background-networking', '--disable-component-update', '--disable-sync',
    'about:blank',
  ], { stdio: 'ignore' });
  const portFile = path.join(profile, 'DevToolsActivePort');
  for (let i = 0; i < 100 && !fs.existsSync(portFile); i++) await wait(100);
  const port = fs.readFileSync(portFile, 'utf8').split('\n')[0].trim();
  let target;
  for (let i = 0; i < 50 && !target; i++) {
    const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    target = list.find((t) => t.type === 'page');
    if (!target) await wait(100);
  }
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0;
  const pending = new Map();
  const listeners = [];
  ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message)); else resolve(msg.result);
    } else if (msg.method) listeners.forEach((l) => l(msg));
  };
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const n = ++id;
    pending.set(n, { resolve, reject });
    ws.send(JSON.stringify({ id: n, method, params }));
  });
  const once = (method) => new Promise((res) => { const l = (m) => { if (m.method === method) { listeners.splice(listeners.indexOf(l), 1); res(m.params); } }; listeners.push(l); });

  const requests = [];
  const consoleErrors = [];
  listeners.push((m) => {
    if (m.method === 'Network.requestWillBeSent') requests.push(m.params.request.url);
    if (m.method === 'Runtime.exceptionThrown') consoleErrors.push(m.params.exceptionDetails.text + ' ' + (m.params.exceptionDetails.exception?.description || ''));
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') consoleErrors.push(m.params.args.map((a) => a.value ?? a.description).join(' '));
  });
  await Promise.all([send('Network.enable'), send('Page.enable'), send('Runtime.enable'), send('DOM.enable')]);

  async function evaluate(expr) {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error('페이지 실행 오류: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text));
    return r.result.value;
  }

  return {
    exe,
    requests,
    consoleErrors,
    send,
    evaluate,
    async open(width = 1200, file = DASHBOARD) {
      await send('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: false });
      const loaded = once('Page.loadEventFired');
      await send('Page.navigate', { url: 'file:///' + file.replace(/\\/g, '/') });
      await loaded;
    },
    async setWidth(width) {
      await send('Emulation.setDeviceMetricsOverride', { width, height: 900, deviceScaleFactor: 1, mobile: false });
      await evaluate('new Promise(r => setTimeout(r, 400))'); // 다시 그리기 대기
    },
    // 파일 선택 창에 파일을 넣는 것과 같은 동작 (끌어다 놓기와 같은 처리 함수를 탑니다)
    async addFiles(files) {
      const before = Number(await evaluate('document.body.dataset.batch'));
      const { root } = await send('DOM.getDocument', { depth: 0 });
      const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: '#file-input' });
      await send('DOM.setFileInputFiles', { nodeId, files: files.map((f) => path.resolve(f)) });
      for (let i = 0; i < 100; i++) {
        if (Number(await evaluate('document.body.dataset.batch')) > before) return;
        await wait(50);
      }
      throw new Error('파일 처리가 끝나지 않았습니다');
    },
    // 끌어다 놓기(drop) 이벤트로 넣기
    async dropFiles(files) {
      const before = Number(await evaluate('document.body.dataset.batch'));
      const { root } = await send('DOM.getDocument', { depth: 0 });
      const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: '#drop' });
      const { model } = await send('DOM.getBoxModel', { nodeId });
      const [x1, y1, , , x3, y3] = model.content;
      const x = (x1 + x3) / 2, y = (y1 + y3) / 2;
      const data = { items: [], files: files.map((f) => path.resolve(f)), dragOperationsMask: 1 };
      await send('Input.dispatchDragEvent', { type: 'dragEnter', x, y, data });
      await send('Input.dispatchDragEvent', { type: 'dragOver', x, y, data });
      await send('Input.dispatchDragEvent', { type: 'drop', x, y, data });
      for (let i = 0; i < 100; i++) {
        if (Number(await evaluate('document.body.dataset.batch')) > before) return;
        await wait(50);
      }
      throw new Error('끌어다 놓은 파일 처리가 끝나지 않았습니다');
    },
    // 칸을 클릭해 내용을 지우고 키보드로 입력하는 것과 같은 동작
    async type(selector, text) {
      await evaluate(`(() => { const e = document.querySelector(${JSON.stringify(selector)}); e.focus(); e.select(); })()`);
      await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
      await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8 });
      if (text) await send('Input.insertText', { text });
      await evaluate(`document.querySelector(${JSON.stringify(selector)}).blur()`);
    },
    async reset() { await evaluate("document.getElementById('reset').click()"); },
    snapshot() {
      return evaluate(`(() => {
        const q = (s, r = document) => r.querySelector(s);
        const t = (id) => { const e = q('[data-testid="' + id + '"]'); return e ? e.textContent.trim() : null; };
        const pts = (id) => [...q('#' + id).querySelectorAll('circle.point')].map((c) => ({ series: c.dataset.series, week: +c.dataset.week, value: +c.dataset.value, cy: +c.getAttribute('cy') }));
        return {
          contentHidden: q('#content').hidden,
          title: q('#kpi-title').textContent,
          kpi: { cost: t('kpi-cost-value'), conversions: t('kpi-conversions-value'), cpa: t('kpi-cpa-value') },
          change: { cost: t('kpi-cost-change'), conversions: t('kpi-conversions-change'), cpa: t('kpi-cpa-change') },
          delta: { cost: t('kpi-cost-delta'), conversions: t('kpi-conversions-delta'), cpa: t('kpi-cpa-delta') },
          table: [...document.querySelectorAll('#detail-body td[data-field]')].map((td) => ({ week: +td.dataset.week, channel: td.dataset.channel, field: td.dataset.field, text: td.textContent })),
          points: { cost: pts('chart-cost'), cpa: pts('chart-cpa') },
          labels: { cost: [...q('#chart-cost').querySelectorAll('text')].map((e) => e.textContent), cpa: [...q('#chart-cpa').querySelectorAll('text')].map((e) => e.textContent) },
          messages: [...document.querySelectorAll('#messages .msg')].map((m) => ({ type: m.dataset.type, text: m.textContent })),
          files: [...document.querySelectorAll('#file-list li')].map((li) => li.textContent),
          scrollWidth: document.documentElement.scrollWidth,
          innerWidth: window.innerWidth,
        };
      })()`);
    },
    async screenshot(file) {
      const { data } = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, Buffer.from(data, 'base64'));
    },
    async close() {
      try { await send('Browser.close'); } catch {}
      ws.close();
      for (let i = 0; i < 30 && proc.exitCode == null; i++) await wait(100);
      if (proc.exitCode == null) proc.kill();
      for (let i = 0; i < 20; i++) {
        try { fs.rmSync(profile, { recursive: true, force: true }); break; } catch { await wait(200); }
      }
    },
  };
}

module.exports = { ROOT, DASHBOARD, BUDGET, REPORTS, FIXTURES, fixture, loadCore, readExcel, ensureFixtures, parseMemo, digits, launchBrowser, findBrowser };
