"""테스트용 '양식이 다른' 엑셀 파일을 tests/fixtures 에 만듭니다.

원본은 tests/fixtures/원본/주간보고_44주.xlsx ('보고서' 폴더의 44주 파일을 복사해 둔 것)이며,
원본은 건드리지 않고 복사본의 내부 XML만 바꿉니다.
사용법: python -I tests/make_fixtures.py
"""
import os
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "tests", "fixtures")
SRC = os.path.join(OUT, "원본", "주간보고_44주.xlsx")


def variant(name, edits):
    """edits: {zip 내부 경로: (바꿀 문자열, 새 문자열) 목록}"""
    with zipfile.ZipFile(SRC) as src, zipfile.ZipFile(os.path.join(OUT, name), "w", zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            data = src.read(item.filename)
            for old, new in edits.get(item.filename, []):
                text = data.decode("utf-8")
                assert old in text, f"{name}: '{old}' 없음"
                data = text.replace(old, new).encode("utf-8")
            dst.writestr(item, data)


SS = "xl/sharedStrings.xml"
SHEET = "xl/worksheets/sheet1.xml"
WB = "xl/workbook.xml"

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)

    # 1) 머리글 이름이 다름: 비용(원) -> 광고비, 전환 -> 구매
    variant("양식다름_머리글.xlsx", {SS: [("<t>비용(원)</t>", "<t>광고비</t>"), ("<t>전환</t>", "<t>구매</t>")]})

    # 2) 주차를 알 수 없음: 제목·시트 이름에 주차 없음 (파일 이름에도 없음)
    variant("양식다름_주차없음.xlsx", {
        SS: [("주간 광고 보고서 (44주, 10/26~11/1)", "광고 보고서")],
        WB: [('name="44주"', 'name="Sheet1"')],
    })

    # 3) 숫자 칸에 글자: 메타 비용(B5) = '약 82만'
    variant("양식다름_숫자아님.xlsx", {
        SS: [('count="13" uniqueCount="13">', 'count="14" uniqueCount="14">'), ("</sst>", "<si><t>약 82만</t></si></sst>")],
        SHEET: [('<c r="B5"><v>821749</v></c>', '<c r="B5" t="s"><v>13</v></c>')],
    })

    # 4) 아예 다른 표: '채널' 머리글이 없음
    variant("양식다름_다른표.xlsx", {SS: [("<t>채널</t>", "<t>상품</t>")]})

    # 5) 수정본: 44주 네이버 비용 +10,000원 (합계·전환당 비용도 맞춰 수정)
    variant("주간보고_44주_수정본.xlsx", {SHEET: [
        ('<c r="B4"><v>682578</v></c>', '<c r="B4"><v>692578</v></c>'),
        ('<c r="G4"><v>8224</v></c>', '<c r="G4"><v>8344</v></c>'),
        ('<c r="B7"><v>2443512</v></c>', '<c r="B7"><v>2453512</v></c>'),
        ('<c r="G7"><v>12218</v></c>', '<c r="G7"><v>12268</v></c>'),
    ]})

    # 6) 같은 44주를 이름만 바꿔 저장한 사본 (내용 동일)
    variant("주간보고_44주_사본.xlsx", {})

    # 7) 엑셀이 아닌 파일, 예전 .xls 형식
    with open(os.path.join(OUT, "엑셀아님.xlsx"), "w", encoding="utf-8") as f:
        f.write("채널,비용\n네이버,100\n")
    with open(os.path.join(OUT, "예전형식.xls"), "wb") as f:
        f.write(bytes.fromhex("D0CF11E0A1B11AE1") + b"\0" * 504)

    print("fixtures:", sorted(os.listdir(OUT)))
