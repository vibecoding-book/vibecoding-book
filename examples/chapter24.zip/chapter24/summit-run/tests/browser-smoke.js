// Opens the real public/index.html in headless Chrome/Edge (?selftest=50) and checks the page's own report.
// Run: node tests/browser-smoke.js
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');

const candidates = [
  process.env.CHROME_PATH,
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/google-chrome', '/usr/bin/chromium',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
].filter(Boolean);
const browser = candidates.find(p => fs.existsSync(p));
if (!browser) { console.log('SKIP: Chrome/Edge 를 찾지 못함 (CHROME_PATH 로 지정 가능)'); process.exit(0); }

const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'summit-smoke-'));
const url = pathToFileURL(path.join(__dirname, '..', 'public', 'index.html')).href + '?selftest=50';
let dom;
try {
  dom = execFileSync(browser, ['--headless=new', '--disable-gpu', '--no-first-run',
    `--user-data-dir=${profile}`, '--window-size=390,844', '--virtual-time-budget=5000', '--dump-dom', url],
    { encoding: 'utf8', timeout: 60000, stdio: ['ignore', 'pipe', 'ignore'] });
} finally {
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* browser may still hold files */ }
}
const m = dom.match(/SELFTEST (\{.*?\})<\/pre>/s);
if (!m) { console.error('FAIL: selftest output not found'); process.exit(1); }
const out = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
console.log('browser:', path.basename(browser));
console.log(JSON.stringify(out));
const checks = [
  ['스크립트 오류 없음', out.ok],
  ['재현 가능(시드 고정)', out.deterministic === true],
  ['캔버스 렌더링', !!(out.rendered && out.rendered.canvas[0] > 0)],
  ['localStorage 저장/읽기', !!(out.storage && out.storage.alt === 432)],
  ['브라우저에서도 초보 중앙 ≥ 500m', !!(out.novice && out.novice.medianAlt >= 500)],
];
let fail = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`); if (!ok) fail++; }
process.exit(fail ? 1 : 0);
