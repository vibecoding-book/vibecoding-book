// Unit + difficulty tests for the game logic. Run: node --test tests/
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadCore } = require('./load-core');
const S = loadCore();
// core objects come from a vm realm; compare them as plain data
const same = (a, b, msg) => assert.deepEqual(JSON.parse(JSON.stringify(a)), b, msg);

// step until a condition, with a hard cap
function run(g, until, maxSteps = 60 * 400) {
  for (let i = 0; i < maxSteps && !until(g); i++) S.step(g);
  return g;
}
// a mountain with no rocks/bottles unless the test places them
const quiet = { rockFirst: 1e9, bottleFirst: 1e9 };

test('같은 시드 + 같은 봇이면 결과가 완전히 같다 (재현 가능)', () => {
  for (const seed of [1, 42, 999]) {
    assert.deepEqual(S.simulate(seed, 'novice'), S.simulate(seed, 'novice'));
  }
  const a = S.simulate(1, 'novice'), b = S.simulate(2, 'novice');
  assert.notDeepEqual(a, b, '다른 시드는 다른 산이어야 함');
});

test('레인은 0~2 사이에서만 움직인다', () => {
  const g = S.create(1);
  assert.equal(g.lane, 1);
  assert.equal(S.move(g, -1), true); assert.equal(g.lane, 0);
  assert.equal(S.move(g, -1), false); assert.equal(g.lane, 0);
  S.move(g, 1); S.move(g, 1); S.move(g, 1);
  assert.equal(g.lane, 2);
});

test('돌에 맞으면 체력이 줄고, 무적 시간 중에는 다시 안 줄어든다', () => {
  const g = S.create(1, quiet);
  const c = g.cfg;
  g.rocks.push({ id: 1, lane: 1, y: c.playerY - 0.1, done: false, spin: 0 });
  g.rocks.push({ id: 2, lane: 1, y: c.playerY - 0.2, done: false, spin: 0 });
  const before = g.stam;
  run(g, x => x.hits >= 1);
  assert.equal(g.hits, 1);
  assert.ok(before - g.stam >= c.hitDmg && before - g.stam < c.hitDmg + 1);
  run(g, x => x.rocks.every(r => r.y > c.playerY + c.hitHalf), 60 * 2);
  assert.equal(g.hits, 1, '1초 무적 동안 두 번째 돌은 피해 없음');
});

test('다른 레인의 돌은 맞지 않는다', () => {
  const g = S.create(1, quiet);
  g.rocks.push({ id: 1, lane: 0, y: g.cfg.playerY - 0.1, done: false, spin: 0 });
  run(g, x => x.rocks.length === 0);
  assert.equal(g.hits, 0);
});

test('물병을 먹으면 체력이 차지만 최대치를 넘지 않는다', () => {
  const g = S.create(1, quiet);
  g.stam = 50;
  g.bottles.push({ id: 1, lane: 1, y: g.cfg.playerY - 0.05, done: false });
  run(g, x => x.drinks >= 1);
  assert.ok(g.stam > 50 + g.cfg.bottleHeal - 1);
  g.bottles.push({ id: 2, lane: 1, y: g.cfg.playerY - 0.05, done: false });
  run(g, x => x.drinks >= 2);
  assert.ok(g.stam <= g.cfg.stamMax);
});

test('1,000m에 닿으면 성공, 체력 0이면 실패', () => {
  const win = run(S.create(1, Object.assign({ drain: 0 }, quiet)), x => x.state !== 'play');
  assert.equal(win.state, 'win');
  assert.equal(Math.floor(win.alt), 1000);
  assert.ok(win.t >= 60 && win.t <= 120, `정상 도착 시간 ${win.t}s`);

  const lose = S.create(1, quiet);
  lose.stam = 1;
  run(lose, x => x.state !== 'play');
  assert.equal(lose.state, 'lose');
  assert.ok(lose.alt < 1000);
});

test('끝난 판은 더 진행되지 않는다', () => {
  const g = S.create(1, quiet); g.stam = 0.001;
  run(g, x => x.state !== 'play');
  const snap = JSON.stringify([g.t, g.alt, g.lane]);
  S.step(g); S.move(g, -1);
  assert.equal(JSON.stringify([g.t, g.alt, g.lane]), snap);
});

test('돌은 절대 세 레인을 동시에 막지 않는다 (항상 피할 곳이 있다)', () => {
  for (let seed = 1; seed <= 100; seed++) {
    const g = S.create(seed, { drain: 0, hitDmg: 0 });
    while (g.state === 'play') {
      const known = new Set(g.rocks.map(r => r.id));
      S.step(g);
      const fresh = g.rocks.filter(r => !known.has(r.id));
      assert.ok(fresh.length <= 2, `seed ${seed}: 한 번에 ${fresh.length}개`);
      assert.equal(new Set(fresh.map(r => r.lane)).size, fresh.length);
    }
  }
});

test('최고 기록: 이 기기 저장소에만 저장, 더 좋은 기록일 때만 갱신', () => {
  const mem = { d: {}, getItem(k) { return k in this.d ? this.d[k] : null; }, setItem(k, v) { this.d[k] = v; } };
  same(S.loadBest(mem), { alt: 0, time: null });

  let r = S.saveBest(mem, { alt: 400.7, t: 40, state: 'lose' });
  assert.equal(r.isNew, true); same(r.best, { alt: 400, time: null });
  r = S.saveBest(mem, { alt: 300, t: 30, state: 'lose' });
  assert.equal(r.isNew, false); assert.equal(S.loadBest(mem).alt, 400);
  r = S.saveBest(mem, { alt: 1000, t: 84.03, state: 'win' });
  assert.equal(r.isNew, true); same(S.loadBest(mem), { alt: 1000, time: 84 });
  r = S.saveBest(mem, { alt: 900, t: 70, state: 'lose' });
  assert.equal(r.isNew, false, '정상 기록은 실패 기록보다 항상 좋음');
  r = S.saveBest(mem, { alt: 1000, t: 90, state: 'win' });
  assert.equal(r.isNew, false, '더 느린 정상 기록은 갱신 안 함');

  // blocked or corrupt storage must not crash the game
  const broken = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); } };
  same(S.loadBest(broken), { alt: 0, time: null });
  assert.doesNotThrow(() => S.saveBest(broken, { alt: 10, t: 1, state: 'lose' }));
  const corrupt = { getItem: () => '{not json', setItem() {} };
  same(S.loadBest(corrupt), { alt: 0, time: null });
});

test('난이도 기준 (1): 봇 200판 — 초보 중앙값 500m 이상, 한 판 2분 이내', () => {
  const { summarize } = require('./difficulty');
  const [novice, clumsy, expert, idle] = summarize();
  assert.ok(novice.medianAlt >= 500, `초보 중앙 고도 ${novice.medianAlt}m`);
  assert.ok(novice.reached500 >= 0.5, `초보 500m 도달률 ${novice.reached500}`);
  assert.ok(clumsy.medianAlt >= 450, `더 서툰 초보 ${clumsy.medianAlt}m`);
  for (const r of [novice, clumsy, expert, idle]) assert.ok(r.maxTime <= 120, `${r.kind} 최장 ${r.maxTime}s`);
  assert.ok(expert.winTime[0] >= 60 && expert.winTime[2] <= 120, '정상 도착은 1~2분');
  assert.ok(expert.summit >= 0.9, '잘하면 정상에 갈 수 있어야 함');
  assert.ok(idle.medianAlt < 500, '아무것도 안 하면 500m 못 감 (조작이 의미 있음)');
});

test('물병을 먹으면 3초 동안 빨리 오르고, 그 뒤엔 원래 속도로 돌아온다', () => {
  const g = S.create(1, quiet);
  const c = g.cfg;
  const normal = S.climbSpeed(g);
  g.bottles.push({ id: 1, lane: 1, y: c.playerY - 0.05, done: false });
  run(g, x => x.drinks >= 1);
  assert.ok(Math.abs(S.climbSpeed(g) / (c.climbBase + c.climbGain * g.alt) - c.boostMult) < 1e-9);
  assert.ok(S.climbSpeed(g) > normal);
  const t0 = g.t;
  run(g, x => x.boost <= 0);
  assert.ok(Math.abs(g.t - t0 - c.boostTime) < 0.05, `가속 지속 ${(g.t - t0).toFixed(2)}s`);
  assert.equal(S.climbSpeed(g), c.climbBase + c.climbGain * g.alt);
});

test('돌에 맞으면 잠깐 느려진다', () => {
  const g = S.create(1, quiet);
  const c = g.cfg;
  g.rocks.push({ id: 1, lane: 1, y: c.playerY - 0.1, done: false, spin: 0 });
  run(g, x => x.hits >= 1);
  assert.ok(Math.abs(S.climbSpeed(g) / (c.climbBase + c.climbGain * g.alt) - c.slowMult) < 1e-9);
  const t0 = g.t;
  run(g, x => x.slow <= 0);
  assert.ok(Math.abs(g.t - t0 - c.slowTime) < 0.05, `감속 지속 ${(g.t - t0).toFixed(2)}s`);
});

test('잘할수록 정상에 빨리 닿는다: 물병 많이·돌 적게 → 더 빠른 기록', () => {
  const free = Object.assign({ drain: 0 }, quiet);
  const time = setup => { const g = S.create(1, free); setup(g); return run(g, x => x.state !== 'play').t; };
  const base = time(() => {});
  const withBottle = time(g => g.bottles.push({ id: 1, lane: 1, y: g.cfg.playerY - 0.05, done: false }));
  const withRock = time(g => g.rocks.push({ id: 1, lane: 1, y: g.cfg.playerY - 0.05, done: false, spin: 0 }));
  assert.ok(withBottle < base - 1, `물병 1개: ${base.toFixed(1)}s → ${withBottle.toFixed(1)}s`);
  assert.ok(withRock > base, `돌 1번: ${base.toFixed(1)}s → ${withRock.toFixed(1)}s`);

  // across many seeds the summit times now differ, and the expert is faster than the novice
  const wins = k => Array.from({ length: 60 }, (_, i) => S.simulate(i + 1, k)).filter(r => r.result === 'win').map(r => r.time);
  const ex = wins('expert'), nv = wins('novice');
  assert.ok(new Set(ex.map(t => t.toFixed(1))).size > 10, '정상 시간이 판마다 달라야 함');
  const med = a => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)];
  assert.ok(med(ex) < med(nv), `숙련 ${med(ex)}s < 초보 ${med(nv)}s`);
});

test('가속·감속을 끄면(배율 1) 예전처럼 정상 시간이 항상 같다', () => {
  const times = [1, 2, 3, 4, 5].map(s => S.simulate(s, 'expert', { boostMult: 1, slowMult: 1 }).time);
  assert.equal(new Set(times).size, 1);
});
