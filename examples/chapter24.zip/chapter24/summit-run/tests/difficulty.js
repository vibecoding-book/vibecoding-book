// Difficulty report: plays many fixed seeds with simulated players and prints the numbers.
// Usage: node tests/difficulty.js [runs=200]
const { loadCore } = require('./load-core');
const S = loadCore();

const N = parseInt(process.argv[2] || '200', 10) || 200;
const pct = v => (v * 100).toFixed(1) + '%';
const quant = (arr, q) => { const s = [...arr].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(q * s.length))]; };

// the game before bottle boost / hit slowdown existed: same mountain, fixed climb speed
const BEFORE = { boostMult: 1, slowMult: 1 };

function report(kind, overrides = {}) {
  const rs = Array.from({ length: N }, (_, i) => S.simulate(i + 1, kind, overrides));
  const alts = rs.map(r => r.alt), times = rs.map(r => r.time);
  const wins = rs.filter(r => r.result === 'win');
  const winTimes = wins.map(r => r.time);
  return {
    kind, n: N,
    medianAlt: quant(alts, 0.5), p25Alt: quant(alts, 0.25),
    reached500: rs.filter(r => r.alt >= 500).length / N,
    summit: wins.length / N,
    medianTime: quant(times, 0.5), maxTime: Math.max(...times),
    winTime: wins.length ? [Math.min(...winTimes), quant(winTimes, 0.5), Math.max(...winTimes)] : null,
    avgHits: rs.reduce((a, r) => a + r.hits, 0) / N,
    avgDrinks: rs.reduce((a, r) => a + r.drinks, 0) / N,
  };
}

const KINDS = ['novice', 'clumsy', 'expert', 'idle'];
function summarize(overrides = {}) { return KINDS.map(k => report(k, overrides)); }
module.exports = { summarize, BEFORE };

function table(title, rows) {
  console.log(`\n[${title}]`);
  console.log('플레이어 | 중앙 고도 | 하위25% | 500m 도달 | 정상 성공 | 한 판 중앙 | 가장 긴 판 | 정상 시간(최소/중앙/최대) | 평균 피격 | 평균 물병');
  for (const r of rows) {
    console.log([
      r.kind.padEnd(8), (r.medianAlt + 'm').padStart(8), (r.p25Alt + 'm').padStart(7),
      pct(r.reached500).padStart(9), pct(r.summit).padStart(9),
      (r.medianTime.toFixed(0) + 's').padStart(10), (r.maxTime.toFixed(0) + 's').padStart(10),
      (r.winTime ? r.winTime.map(t => t.toFixed(0) + 's').join('/') : '-').padStart(24),
      r.avgHits.toFixed(1).padStart(9), r.avgDrinks.toFixed(1).padStart(9),
    ].join(' | '));
  }
}

if (require.main === module) {
  const before = summarize(BEFORE);
  const rows = summarize();
  console.log(`\n정상까지 달려라 — 난이도 리포트 (시드 1..${N}, 시드 고정이라 매번 같은 결과)`);
  table('변경 전: 오르는 속도 고정', before);
  table('변경 후: 물병 = 3초 가속, 돌 = 잠깐 감속', rows);

  console.log('\n[전후 비교] 중앙 고도 / 500m 도달 / 정상 성공 / 정상 시간 중앙');
  for (let i = 0; i < KINDS.length; i++) {
    const b = before[i], a = rows[i];
    const wt = r => r.winTime ? r.winTime[1].toFixed(0) + 's' : '-';
    console.log(`  ${a.kind.padEnd(7)} ${String(b.medianAlt).padStart(4)}m → ${String(a.medianAlt).padStart(4)}m | ` +
      `${pct(b.reached500).padStart(6)} → ${pct(a.reached500).padStart(6)} | ` +
      `${pct(b.summit).padStart(6)} → ${pct(a.summit).padStart(6)} | ${wt(b).padStart(4)} → ${wt(a).padStart(4)}`);
  }

  const nv = rows[0];
  const win = rows.filter(r => r.winTime);
  console.log('\n기준 (1) 체크 (변경 후)');
  console.log(`  초보 중앙 고도 ≥ 500m      : ${nv.medianAlt}m  ${nv.medianAlt >= 500 ? 'PASS' : 'FAIL'}`);
  console.log(`  (여유 확인) 더 서툰 초보     : ${rows[1].medianAlt}m  ${rows[1].medianAlt >= 500 ? 'PASS' : '경계'}`);
  console.log(`  한 판 길이 ≤ 120s           : 가장 긴 판 ${Math.max(...rows.map(r => r.maxTime)).toFixed(0)}s  ${rows.every(r => r.maxTime <= 120) ? 'PASS' : 'FAIL'}`);
  console.log(`  정상 시간이 60~120s         : ${Math.min(...win.map(r => r.winTime[0])).toFixed(0)}~${Math.max(...win.map(r => r.winTime[2])).toFixed(0)}s  ${win.every(r => r.winTime[0] >= 60 && r.winTime[2] <= 120) ? 'PASS' : 'FAIL'}`);
  console.log(`  숙련자는 정상 가능          : ${pct(rows[2].summit)}  ${rows[2].summit >= 0.5 ? 'PASS' : 'FAIL'}`);
  console.log(`  잘할수록 빨리 도착          : 초보 중앙 ${nv.winTime ? nv.winTime[1].toFixed(0) : '-'}s vs 숙련 중앙 ${rows[2].winTime[1].toFixed(0)}s  ${nv.winTime && rows[2].winTime[1] < nv.winTime[1] ? 'PASS' : 'FAIL'}`);
  console.log(`  가만히 있으면 500m 못 감    : idle 중앙 ${rows[3].medianAlt}m  ${rows[3].medianAlt < 500 ? 'PASS' : 'FAIL'}`);
}
