// Loads the <script id="core"> block from public/index.html into Node, so tests run the exact shipped code.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function loadCore() {
  const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
  const m = html.match(/<script id="core">([\s\S]*?)<\/script>/);
  if (!m) throw new Error('core script block not found in index.html');
  const ctx = vm.createContext({});
  vm.runInContext(m[1], ctx, { filename: 'index.html#core' });
  return ctx.SummitCore;
}

module.exports = { loadCore };
