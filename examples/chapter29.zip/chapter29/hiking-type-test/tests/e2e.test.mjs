// 실제 브라우저를 휴대폰 화면 크기로 띄워 테스트를 끝까지 해 본다.
// SCREENSHOT_DIR 환경 변수를 주면 화면을 PNG로 저장한다.
import { after, before, describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { launchBrowser } from '../scripts/browser.mjs';
import { startServer } from '../scripts/serve.mjs';
import { SITE_URL } from '../scripts/config.mjs';
import { QUESTIONS, TYPES } from '../public/assets/questions.js';
import { RESULTS } from '../public/assets/results.js';

const PHONE = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true };
const SMALL_PHONE = { viewport: { width: 360, height: 640 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true };
const SHOTS = process.env.SCREENSHOT_DIR;
if (SHOTS) mkdirSync(SHOTS, { recursive: true });

let server;
let base;
let browser;

before(async () => {
  ({ server, url: base } = await startServer());
  browser = await launchBrowser();
});

after(async () => {
  await browser?.close();
  server?.close();
});

// 외부로 나가는 요청이나 스크립트 오류(보안 정책 위반 포함)가 있으면 실패로 기록한다.
async function openPage(device = PHONE, { initScript } = {}) {
  const context = await browser.newContext(device);
  if (initScript) await context.addInitScript(initScript);
  const page = await context.newPage();
  const problems = [];
  page.on('request', (req) => {
    if (!req.url().startsWith(base) && !req.url().startsWith('data:')) problems.push(`외부 요청: ${req.url()}`);
  });
  page.on('pageerror', (err) => problems.push(`스크립트 오류: ${err.message}`));
  page.on('console', (msg) => {
    if (msg.type() === 'error') problems.push(`콘솔 오류: ${msg.text()}`);
  });
  return { context, page, problems };
}

async function shot(page, name) {
  if (SHOTS) await page.screenshot({ path: join(SHOTS, `${name}.png`), fullPage: true });
}

async function assertMobileLayout(page, label) {
  const info = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    width: window.innerWidth,
    small: [...document.querySelectorAll('button, a.btn')]
      .filter((el) => el.offsetParent !== null)
      .map((el) => ({ text: el.textContent.trim(), h: el.getBoundingClientRect().height }))
      .filter((b) => b.h < 44),
  }));
  assert.ok(info.scrollWidth <= info.width, `${label}: 가로 스크롤 생김 (${info.scrollWidth} > ${info.width})`);
  assert.deepEqual(info.small, [], `${label}: 너무 작은 버튼`);
}

// 질문마다 원하는 유형의 선택지를 눌러 끝까지 진행한다.
async function answerAll(page, types) {
  for (let i = 0; i < types.length; i += 1) {
    await page.locator('#progress-text').filter({ hasText: `${i + 1} / ${QUESTIONS.length}` }).waitFor();
    await page.locator(`.option[data-type="${types[i]}"]`).tap();
  }
}

describe('휴대폰에서 테스트하기', () => {
  for (const type of TYPES) {
    test(`모두 ${RESULTS[type].name} 답을 고르면 /result/${type}/ 로 간다`, async () => {
      const { context, page, problems } = await openPage();
      await page.goto(`${base}/`);
      await page.locator('#start-button').tap();
      await answerAll(page, Array(8).fill(type));
      await page.waitForURL(`${base}/result/${type}/`);

      // 주소창에는 공유용 깨끗한 주소만 남는다.
      assert.equal(new URL(page.url()).search, '');
      await assert.doesNotReject(page.locator('.mine-only', { hasText: '나의 주말 등산 유형은' }).waitFor());
      assert.equal(await page.locator('h1').textContent(), `${RESULTS[type].emoji} ${RESULTS[type].name}`);
      assert.ok(await page.locator('#share-button').isVisible());
      assert.ok(!(await page.locator('a.friend-only').isVisible()));
      await assertMobileLayout(page, `결과 ${type}`);
      await shot(page, `result-${type}-mine`);
      assert.deepEqual(problems, []);
      await context.close();
    });
  }

  test('동점이면 8번 답의 유형이 나온다 (화면에서 확인)', async () => {
    const { context, page, problems } = await openPage();
    await page.goto(`${base}/`);
    await page.locator('#start-button').tap();
    await answerAll(page, ['summit', 'summit', 'summit', 'summit', 'picnic', 'picnic', 'picnic', 'picnic']);
    await page.waitForURL(`${base}/result/picnic/`);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test('시작 화면과 질문 화면이 한 손으로 쓰기 좋게 배치된다', async () => {
    for (const [label, device] of [['일반 폰', PHONE], ['작은 폰', SMALL_PHONE]]) {
      const { context, page, problems } = await openPage(device);
      await page.goto(`${base}/`);
      await assertMobileLayout(page, `${label} 시작`);
      // 시작 버튼이 스크롤 없이 화면 아래쪽 절반에 보인다.
      const start = await page.locator('#start-button').boundingBox();
      const h = device.viewport.height;
      assert.ok(start.y > h / 2 && start.y + start.height <= h, `${label}: 시작 버튼 위치 ${start.y}`);
      await shot(page, `${label}-start`);

      await page.locator('#start-button').tap();
      for (let i = 0; i < QUESTIONS.length; i += 1) {
        await page.locator('#progress-text').filter({ hasText: `${i + 1} / 8` }).waitFor();
        assert.equal(await page.locator('#question-text').textContent(), QUESTIONS[i].text);
        // 선택지 4개가 스크롤 없이 모두 보이고, 마지막 선택지가 화면 아래쪽에 있다.
        const boxes = await page.locator('.option').evaluateAll((els) =>
          els.map((el) => el.getBoundingClientRect().toJSON()),
        );
        assert.equal(boxes.length, 4);
        for (const b of boxes) assert.ok(b.bottom <= h, `${label} Q${i + 1}: 선택지가 화면 밖 (${b.bottom} > ${h})`);
        assert.ok(boxes[3].bottom > h * 0.75, `${label} Q${i + 1}: 선택지가 너무 위에 있음`);
        await assertMobileLayout(page, `${label} Q${i + 1}`);
        if (i === 0 || i === 5) await shot(page, `${label}-q${i + 1}`);
        await page.locator('.option').first().tap();
      }
      await page.waitForURL(/\/result\/\w+\/$/);
      assert.deepEqual(problems, []);
      await context.close();
    }
  });

  test('이전 버튼으로 앞 질문에 돌아가 답을 바꿀 수 있다', async () => {
    const { context, page, problems } = await openPage();
    await page.goto(`${base}/`);
    await page.locator('#start-button').tap();
    await page.locator('.option[data-type="cafe"]').tap();
    await page.locator('#progress-text').filter({ hasText: '2 / 8' }).waitFor();
    await page.locator('#back-button').tap();
    await page.locator('#progress-text').filter({ hasText: '1 / 8' }).waitFor();
    assert.ok(await page.locator('.option[data-type="cafe"]').evaluate((el) => el.classList.contains('is-selected')));

    // 첫 질문에서 이전을 누르면 시작 화면으로 돌아간다.
    await page.locator('#back-button').tap();
    assert.ok(await page.locator('#start-button').isVisible());
    assert.deepEqual(problems, []);
    await context.close();
  });
});

describe('결과 공유', () => {
  test('공유 버튼은 휴대폰 공유창에 결과 주소·제목·설명을 넘긴다', async () => {
    const { context, page, problems } = await openPage(PHONE, {
      initScript: () => {
        window.__shared = [];
        navigator.share = async (data) => {
          window.__shared.push(data);
        };
      },
    });
    await page.goto(`${base}/result/scenery/?from=quiz`);
    await page.locator('#share-button').tap();
    const shared = await page.evaluate(() => window.__shared);
    assert.deepEqual(shared, [
      {
        title: '나는 📸 풍경 감성형!',
        text: '정상보다 중요한 건 오늘의 빛. 너의 등산 유형은?',
        url: `${SITE_URL}/result/scenery/`,
      },
    ]);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test('공유창을 닫으면(취소) 아무 일도 일어나지 않는다', async () => {
    const { context, page, problems } = await openPage(PHONE, {
      initScript: () => {
        navigator.share = async () => {
          throw new DOMException('cancel', 'AbortError');
        };
      },
    });
    await page.goto(`${base}/result/summit/?from=quiz`);
    await page.locator('#share-button').tap();
    await page.waitForTimeout(300);
    assert.ok(!(await page.locator('#toast').evaluate((el) => el.classList.contains('is-visible'))));
    assert.deepEqual(problems, []);
    await context.close();
  });

  for (const [label, initScript] of [
    ['공유창이 없는 브라우저(카톡 인앱 등)', () => { delete Navigator.prototype.share; }],
    ['공유창이 오류를 내는 경우', () => { navigator.share = async () => { throw new Error('not allowed'); }; }],
  ]) {
    test(`${label}에서는 공유 버튼이 링크를 복사한다`, async () => {
      const { context, page, problems } = await openPage(PHONE, { initScript });
      await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: base });
      await page.goto(`${base}/result/picnic/?from=quiz`);
      await page.locator('#share-button').tap();
      await page.locator('#toast.is-visible').waitFor();
      assert.match(await page.locator('#toast').textContent(), /링크를 복사했어요/);
      assert.equal(await page.evaluate(() => navigator.clipboard.readText()), `${SITE_URL}/result/picnic/`);
      await shot(page, 'share-copied');
      assert.deepEqual(problems, []);
      await context.close();
    });
  }

  test('링크 복사 버튼은 결과 주소를 복사한다', async () => {
    const { context, page, problems } = await openPage();
    await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: base });
    await page.goto(`${base}/result/cafe/`);
    await page.locator('#copy-button').tap();
    await page.locator('#toast.is-visible').waitFor();
    assert.equal(await page.evaluate(() => navigator.clipboard.readText()), `${SITE_URL}/result/cafe/`);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test('친구가 공유 링크를 열면 "친구의 결과"와 "나도 테스트하기"가 보인다', async () => {
    for (const r of Object.values(RESULTS)) {
      const { context, page, problems } = await openPage();
      await page.goto(`${base}/result/${r.id}/`);
      assert.ok(await page.locator('.friend-only', { hasText: '친구의 주말 등산 유형은' }).isVisible());
      assert.ok(!(await page.locator('#share-button').isVisible()));
      // 고정된 하단 버튼 영역이 스크롤 없이 화면 안에 있다.
      const cta = await page.locator('a.friend-only').boundingBox();
      assert.ok(cta.y + cta.height <= PHONE.viewport.height, `${r.id}: 하단 버튼이 화면 밖`);
      await assertMobileLayout(page, `친구 화면 ${r.id}`);
      if (r.id === 'summit') {
        await page.screenshot({ path: SHOTS ? join(SHOTS, 'result-friend-viewport.png') : undefined });
        await shot(page, 'result-summit-friend');
      }
      await page.locator('a.friend-only').tap();
      await page.waitForURL(`${base}/`);
      assert.ok(await page.locator('#start-button').isVisible());
      assert.deepEqual(problems, []);
      await context.close();
    }
  });
});

test('없는 주소는 안내 페이지를 보여 준다', async () => {
  const { context, page } = await openPage();
  const res = await page.goto(`${base}/result/nope/`);
  assert.equal(res.status(), 404);
  assert.ok(await page.locator('a.btn', { hasText: '테스트 하러 가기' }).isVisible());
  await context.close();
});
