// public/ 폴더 결과물을 정적으로 검사한다: 카카오톡 미리보기 태그, 이미지, 개인정보·외부 코드.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { CSP, OG_HEIGHT, OG_WIDTH, SITE_URL } from '../scripts/config.mjs';
import { PUBLIC_DIR } from '../scripts/serve.mjs';
import { RESULTS } from '../public/assets/results.js';

const PAGES = [
  { file: 'index.html', path: '/', image: 'home' },
  ...Object.keys(RESULTS).map((id) => ({ file: `result/${id}/index.html`, path: `/result/${id}/`, image: id })),
];

function allFiles(dir) {
  return readdirSync(dir).flatMap((name) => {
    const full = join(dir, name);
    return statSync(full).isDirectory() ? allFiles(full) : [full];
  });
}

const read = (file) => readFileSync(join(PUBLIC_DIR, file), 'utf8');

function meta(html, key) {
  const re = new RegExp(`<meta (?:property|name)="${key.replace(/[:]/g, '\\:')}" content="([^"]*)"`);
  return html.match(re)?.[1];
}

function pngSize(file) {
  const buf = readFileSync(file);
  assert.equal(buf.toString('ascii', 1, 4), 'PNG', `${file}은 PNG여야 함`);
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20), bytes: buf.length };
}

for (const page of PAGES) {
  test(`${page.path} 미리보기 태그가 모두 있고 올바르다`, () => {
    const html = read(page.file);
    const url = `${SITE_URL}${page.path}`;

    assert.match(html, /<html lang="ko">/);
    assert.match(html, /<meta name="viewport" content="width=device-width, initial-scale=1/);
    assert.ok(html.includes(`<link rel="canonical" href="${url}">`), 'canonical');
    assert.equal(meta(html, 'og:url'), url);
    assert.equal(meta(html, 'og:type'), 'website');
    assert.ok(meta(html, 'og:title')?.length > 0, 'og:title');
    assert.ok(meta(html, 'og:description')?.length > 0, 'og:description');
    assert.equal(meta(html, 'og:title'), html.match(/<title>([^<]*)<\/title>/)[1], '<title>과 og:title 일치');
    assert.equal(meta(html, 'og:image:width'), String(OG_WIDTH));
    assert.equal(meta(html, 'og:image:height'), String(OG_HEIGHT));
    assert.equal(meta(html, 'twitter:card'), 'summary_large_image');

    // 카카오톡은 이미지 주소가 https 전체 주소여야 한다.
    const image = meta(html, 'og:image');
    assert.ok(image.startsWith(`${SITE_URL}/og/${page.image}.png?v=`), `og:image 절대 주소: ${image}`);
    const imageFile = join(PUBLIC_DIR, new URL(image).pathname);
    assert.ok(existsSync(imageFile), `${imageFile} 파일 존재`);
  });
}

test('결과마다 미리보기 제목·설명·이미지가 서로 다르다', () => {
  const htmls = PAGES.map((p) => read(p.file));
  for (const key of ['og:title', 'og:description', 'og:image', 'og:url']) {
    const values = htmls.map((h) => meta(h, key));
    assert.equal(new Set(values).size, PAGES.length, `${key} 중복`);
  }
});

test('결과 페이지 미리보기 문구가 기획안과 같다', () => {
  for (const r of Object.values(RESULTS)) {
    const html = read(`result/${r.id}/index.html`);
    assert.equal(meta(html, 'og:title'), `나는 ${r.emoji} ${r.name}!`);
    assert.equal(meta(html, 'og:description'), `${r.tagline}. 너의 등산 유형은?`);
  }
  const home = read('index.html');
  assert.equal(meta(home, 'og:title'), '나의 주말 등산 유형 테스트 ⛰️');
  assert.equal(meta(home, 'og:description'), '질문 8개로 알아보는 나의 등산 스타일. 1분이면 끝나요!');
});

test('미리보기 이미지는 1200×630 PNG이고 용량이 충분히 작다', () => {
  for (const name of ['home', ...Object.keys(RESULTS)]) {
    const { width, height, bytes } = pngSize(join(PUBLIC_DIR, 'og', `${name}.png`));
    assert.equal(width, OG_WIDTH, `${name} 너비`);
    assert.equal(height, OG_HEIGHT, `${name} 높이`);
    assert.ok(bytes < 1024 * 1024, `${name} 용량 ${bytes}바이트 (1MB 미만)`);
  }
});

test('페이지 안의 링크와 리소스가 모두 사이트 내부를 가리킨다', () => {
  for (const page of [...PAGES, { file: '404.html' }]) {
    const html = read(page.file);
    for (const [, attr, value] of html.matchAll(/\s(src|href)="([^"]*)"/g)) {
      const ok = value.startsWith('/') || value.startsWith('#') || value.startsWith(`${SITE_URL}/`);
      assert.ok(ok, `${page.file}: 외부 ${attr} → ${value}`);
      if (value.startsWith('/')) {
        const target = join(PUBLIC_DIR, value.split('?')[0]);
        const exists = existsSync(target) && (statSync(target).isFile() || existsSync(join(target, 'index.html')));
        assert.ok(exists, `${page.file}: 깨진 링크 ${value}`);
      }
    }
  }
});

test('개인정보 입력 칸, 외부 추적·광고 코드, 저장소 사용이 없다', () => {
  const forbidden = [
    /<form/i, /<input/i, /<select/i, /<iframe/i,
    /googletagmanager|google-analytics|gtag\(|\bga\(/i,
    /adsbygoogle|doubleclick|googlesyndication/i,
    /fbq\(|connect\.facebook\.net/i,
    /hotjar|clarity\.ms|mixpanel|amplitude|segment\.io/i,
    /kakao_js_sdk|developers\.kakao\.com|Kakao\.init|t1\.kakaocdn/i,
    /document\.cookie|localStorage|sessionStorage|indexedDB/,
    /fetch\(|XMLHttpRequest|sendBeacon|WebSocket/,
    /fonts\.googleapis|cdn\.jsdelivr|unpkg\.com|cdnjs/i,
  ];
  const files = allFiles(PUBLIC_DIR).filter((f) => /\.(html|js|css)$/.test(f));
  assert.ok(files.length >= 10);
  for (const file of files) {
    const text = readFileSync(file, 'utf8');
    for (const re of forbidden) {
      assert.ok(!re.test(text), `${relative(PUBLIC_DIR, file)}에 금지된 패턴 ${re}`);
    }
  }
});

test('모든 페이지에 외부 요청을 막는 보안 정책이 있고 _headers와 같다', () => {
  for (const page of [...PAGES, { file: '404.html' }]) {
    assert.ok(read(page.file).includes(`<meta http-equiv="Content-Security-Policy" content="${CSP}">`), page.file);
  }
  const headers = read('_headers');
  assert.ok(headers.includes(`Content-Security-Policy: ${CSP}; frame-ancestors 'none'`), '_headers CSP');
});

test('Netlify Drop에 올릴 폴더에 개발용 파일이 섞여 있지 않다', () => {
  const names = allFiles(PUBLIC_DIR).map((f) => relative(PUBLIC_DIR, f).replaceAll('\\', '/'));
  for (const n of names) {
    assert.ok(!/node_modules|package\.json|\.mjs$|tests\//.test(n), `불필요한 파일: ${n}`);
  }
  for (const required of ['index.html', '404.html', '_headers', 'favicon.svg', 'assets/app.js', 'assets/style.css']) {
    assert.ok(names.includes(required), `필수 파일 없음: ${required}`);
  }
});
