import { test } from 'node:test';
import assert from 'node:assert/strict';
import { QUESTIONS, TYPES } from '../public/assets/questions.js';
import { RESULTS } from '../public/assets/results.js';
import { computeResult } from '../public/assets/scoring.js';

test('질문은 8개이고, 각 질문은 네 유형을 하나씩 가진 선택지 4개다', () => {
  assert.equal(QUESTIONS.length, 8);
  for (const q of QUESTIONS) {
    assert.ok(q.text.length > 0);
    assert.equal(q.options.length, 4);
    assert.deepEqual(q.options.map((o) => o.type).sort(), [...TYPES].sort());
  }
});

test('결과는 4가지이고 유형 목록과 일치한다', () => {
  assert.deepEqual(Object.keys(RESULTS).sort(), [...TYPES].sort());
  for (const [id, r] of Object.entries(RESULTS)) {
    assert.equal(r.id, id);
    assert.ok(RESULTS[r.mate.id], `${id}의 메이트 유형이 존재해야 함`);
    assert.notEqual(r.mate.id, id);
  }
});

test('선택지 순서가 질문마다 섞여 있다 (같은 자리에 같은 유형이 반복되지 않음)', () => {
  for (let slot = 0; slot < 4; slot += 1) {
    const types = new Set(QUESTIONS.map((q) => q.options[slot].type));
    assert.ok(types.size > 1, `${slot + 1}번째 자리가 항상 같은 유형`);
  }
});

test('한 유형만 고르면 그 유형이 나온다 (4가지 결과 모두 나올 수 있음)', () => {
  for (const type of TYPES) {
    assert.equal(computeResult(Array(8).fill(type)), type);
  }
});

test('가장 많이 고른 유형이 결과가 된다', () => {
  const answers = ['picnic', 'picnic', 'picnic', 'summit', 'scenery', 'cafe', 'summit', 'picnic'];
  assert.equal(computeResult(answers), 'picnic');
});

test('동점이면 8번 질문의 답을 따른다', () => {
  const base = ['summit', 'summit', 'summit', 'summit', 'picnic', 'picnic', 'picnic'];
  assert.equal(computeResult([...base, 'picnic']), 'picnic'); // 4:4, 8번 = picnic
  const base2 = ['scenery', 'scenery', 'scenery', 'scenery', 'cafe', 'cafe', 'cafe'];
  assert.equal(computeResult([...base2, 'cafe']), 'cafe'); // 4:4, 8번 = cafe
});

test('8번 답이 동점 유형이 아니면 그 앞 질문부터 거꾸로 따진다', () => {
  // summit 3, picnic 3, scenery 1, cafe 1 / 8번 = cafe(동점 아님) → 7번 = picnic
  const answers = ['summit', 'summit', 'summit', 'picnic', 'picnic', 'scenery', 'picnic', 'cafe'];
  assert.equal(computeResult(answers), 'picnic');
});

test('네 유형이 2점씩 똑같으면 8번 답이 결과가 된다', () => {
  const answers = ['summit', 'picnic', 'scenery', 'cafe', 'summit', 'picnic', 'cafe', 'scenery'];
  assert.equal(computeResult(answers), 'scenery');
});

test('모든 답 조합(4^8 = 65,536가지)에서 항상 유효한 결과가 나오고 4가지가 고르게 분포한다', () => {
  const counts = Object.fromEntries(TYPES.map((t) => [t, 0]));
  const answers = new Array(8);
  for (let n = 0; n < 4 ** 8; n += 1) {
    let x = n;
    for (let i = 0; i < 8; i += 1) {
      answers[i] = TYPES[x % 4];
      x = Math.floor(x / 4);
    }
    counts[computeResult(answers)] += 1;
  }
  for (const t of TYPES) assert.equal(counts[t], 4 ** 8 / 4, `${t} 분포`);
});

test('알 수 없는 유형이 들어오면 오류를 낸다', () => {
  assert.throws(() => computeResult(['summit', 'unknown']));
});
