# 나의 주말 등산 유형 테스트

질문 8개 → 결과 4가지(정상 정복형 / 먹방 소풍형 / 풍경 감성형 / 입구 컷형) 심리테스트.
서버 없이 정적 파일만으로 동작하고, 개인정보 입력·외부 추적·광고 코드가 없습니다.

## 배포 (Netlify Drop)

1. https://app.netlify.com/drop 에 **`public` 폴더**를 통째로 끌어다 놓습니다. (프로젝트 폴더 전체가 아니라 `public`만)
2. 생성된 사이트의 **Site configuration → Change site name**에서 이름을 `hiking-type-test`로 바꿉니다.
   → 주소가 `https://hiking-type-test.netlify.app` 이 되어야 카카오톡 미리보기 이미지가 나옵니다.
3. 나중에 수정본을 올릴 때는 같은 사이트의 **Deploys** 탭에 `public` 폴더를 다시 끌어다 놓습니다.
   (Drop 첫 화면에 올리면 새 사이트가 따로 생깁니다.)

이름이 이미 사용 중이면 다른 이름을 정한 뒤 `scripts/config.mjs`의 `SITE_URL`을 고치고 `npm run check`를 실행해 다시 올리세요.

## 카카오톡 미리보기 확인

- 첫 화면 링크: `https://hiking-type-test.netlify.app/`
- 결과 링크: `/result/summit/`, `/result/picnic/`, `/result/scenery/`, `/result/cafe/` — 결과마다 제목·설명·이미지가 다릅니다.
- 카카오톡은 미리보기를 한동안 저장해 둡니다. 배포 전에 링크를 먼저 보내 봤다면 예전 미리보기가 남을 수 있으니,
  [카카오 공유 디버거](https://developers.kakao.com/tool/debugger/sharing)(카카오 로그인 필요)에서 주소를 넣고 캐시를 지우세요.

## 수정하기

| 바꿀 것 | 파일 |
|---|---|
| 질문·선택지 | `public/assets/questions.js` |
| 결과 설명·추천 코스 등 | `public/assets/results.js` |
| 사이트 주소, 미리보기 문구 형식 | `scripts/config.mjs` |
| 디자인 | `public/assets/style.css` |

수정 후에는 반드시 `npm run check`로 페이지와 미리보기 이미지를 다시 만들고 테스트하세요.

## 명령어

```
npm install       # 처음 한 번 (테스트·이미지 생성용 도구 설치)
npm run build     # public/ 의 HTML과 미리보기 이미지(og/*.png) 생성
npm test          # 점수 계산 + 미리보기 태그·개인정보 검사 + 휴대폰 화면 브라우저 테스트
npm run check     # build + test
npm run preview   # http://127.0.0.1:8080 에서 미리 보기
```

이미지 생성과 브라우저 테스트에는 PC에 설치된 Chrome이나 Edge를 사용합니다. 찾지 못하면 `CHROME_PATH` 환경 변수로 경로를 지정하세요.
