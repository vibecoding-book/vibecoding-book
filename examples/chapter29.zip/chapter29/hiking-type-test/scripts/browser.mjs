import { existsSync } from 'node:fs';
import { chromium } from 'playwright-core';

// 이미 설치된 Chrome이나 Edge를 쓴다. 다른 위치라면 CHROME_PATH 환경 변수로 지정한다.
const CANDIDATES = [
  process.env.CHROME_PATH,
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
].filter(Boolean);

export function findBrowser() {
  const found = CANDIDATES.find((p) => existsSync(p));
  if (!found) {
    throw new Error('Chrome 또는 Edge를 찾지 못했습니다. CHROME_PATH 환경 변수로 경로를 지정해 주세요.');
  }
  return found;
}

export function launchBrowser() {
  return chromium.launch({ executablePath: findBrowser(), headless: true });
}
