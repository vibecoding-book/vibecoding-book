// public/ 안의 HTML 페이지와 카카오톡 미리보기 이미지(og/*.png)를 만든다.
// 질문은 public/assets/questions.js, 결과는 public/assets/results.js, 주소는 scripts/config.mjs에서 고친다.
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { launchBrowser } from './browser.mjs';
import { PUBLIC_DIR } from './serve.mjs';
import {
  CSP,
  HOME_OG_DESCRIPTION,
  HOME_OG_TITLE,
  OG_HEIGHT,
  OG_WIDTH,
  SITE_TITLE,
  SITE_URL,
  resultOgDescription,
  resultOgTitle,
} from './config.mjs';
import { QUESTIONS } from '../public/assets/questions.js';
import { RESULTS } from '../public/assets/results.js';

const esc = (s) =>
  String(s)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');

// ---------- 미리보기 이미지 ----------

const FONT = "'Malgun Gothic', 'Apple SD Gothic Neo', 'Noto Sans KR', sans-serif";
const EMOJI_FONT = "'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif";

function mountains(color) {
  return `
  <svg class="mt" viewBox="0 0 1200 260" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 260V150l140-90 110 70 170-120 150 110 120-60 160 100 140-90 210 120v170z" fill="${color}" opacity=".22"/>
    <path d="M0 260V200l180-80 130 60 190-110 170 120 150-70 170 90 210-60v110z" fill="${color}" opacity=".45"/>
    <path d="M0 260v-30l220-50 200 40 240-70 220 60 320-40v90z" fill="${color}"/>
  </svg>`;
}

function cardHtml(inner, color) {
  return `<!doctype html><html><head><meta charset="utf-8"><style>
    * { margin: 0; box-sizing: border-box; }
    body { width: ${OG_WIDTH}px; height: ${OG_HEIGHT}px; overflow: hidden; background: #f7f3ea;
      font-family: ${FONT}; color: #1f2a24; position: relative; word-break: keep-all; }
    .mt { position: absolute; left: 0; bottom: 0; width: 100%; height: 260px; }
    .label { position: absolute; top: 56px; left: 80px; font-size: 30px; font-weight: 700; color: ${color};
      letter-spacing: -0.01em; }
    .text { position: absolute; left: 80px; top: 130px; width: 700px; }
    .emoji { position: absolute; font-family: ${EMOJI_FONT}; line-height: 1; }
    .site { position: absolute; right: 48px; bottom: 28px; font-size: 24px; color: #fff; font-weight: 700; opacity: .9; }
  </style></head><body>${inner}${mountains(color)}</body></html>`;
}

function resultCard(r) {
  return cardHtml(
    `
    <div class="label">나의 주말 등산 유형 테스트</div>
    <div class="text">
      <div style="font-size:48px;font-weight:700;color:#55625a">나는</div>
      <div style="font-size:112px;font-weight:800;line-height:1.15;color:${r.color};letter-spacing:-0.03em">${esc(r.name)}</div>
      <div style="margin-top:18px;font-size:40px;font-weight:700;line-height:1.35">${esc(r.tagline)}</div>
    </div>
    <div class="emoji" style="right:110px;top:90px;font-size:230px">${r.emoji}</div>
    <div class="site">hiking-type-test</div>`,
    r.color,
  );
}

function homeCard() {
  const emojis = Object.values(RESULTS).map((r) => `<span>${r.emoji}</span>`).join('');
  return cardHtml(
    `
    <div class="label">⛰️ 주말 심리테스트</div>
    <div class="text" style="width:1040px">
      <div style="font-size:100px;font-weight:800;line-height:1.2;letter-spacing:-0.03em">나의 주말<br><span style="color:#2f6b4f">등산 유형</span> 테스트</div>
      <div style="margin-top:20px;font-size:38px;font-weight:700;color:#55625a">질문 8개 · 1분 · 결과 4가지</div>
    </div>
    <div class="emoji" style="right:70px;top:120px;font-size:96px;display:grid;grid-template-columns:repeat(2,1fr);gap:20px 28px">${emojis}</div>
    <div class="site">hiking-type-test</div>`,
    '#2f6b4f',
  );
}

async function renderImages() {
  await mkdir(join(PUBLIC_DIR, 'og'), { recursive: true });
  const browser = await launchBrowser();
  try {
    const page = await browser.newPage({ viewport: { width: OG_WIDTH, height: OG_HEIGHT } });
    const cards = [['home', homeCard()], ...Object.values(RESULTS).map((r) => [r.id, resultCard(r)])];
    for (const [name, html] of cards) {
      await page.setContent(html);
      await page.screenshot({ path: join(PUBLIC_DIR, 'og', `${name}.png`) });
    }
  } finally {
    await browser.close();
  }
}

// 이미지가 바뀌면 주소도 바뀌게 해서 카카오톡이 예전 이미지를 계속 쓰지 않도록 한다.
async function imageUrl(name) {
  const data = await readFile(join(PUBLIC_DIR, 'og', `${name}.png`));
  const hash = createHash('sha256').update(data).digest('hex').slice(0, 10);
  return `${SITE_URL}/og/${name}.png?v=${hash}`;
}

// ---------- 페이지 ----------

function head({ title, description, path, image, imageAlt, themeColor }) {
  const url = `${SITE_URL}${path}`;
  return `<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta http-equiv="Content-Security-Policy" content="${CSP}">
<meta name="referrer" content="no-referrer">
<title>${esc(title)}</title>
<meta name="description" content="${esc(description)}">
<link rel="canonical" href="${url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${esc(SITE_TITLE)}">
<meta property="og:locale" content="ko_KR">
<meta property="og:url" content="${url}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:image" content="${image}">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="${OG_WIDTH}">
<meta property="og:image:height" content="${OG_HEIGHT}">
<meta property="og:image:alt" content="${esc(imageAlt)}">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="${themeColor}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/assets/style.css">
</head>`;
}

function homePage(image) {
  return `${head({
    title: HOME_OG_TITLE,
    description: HOME_OG_DESCRIPTION,
    path: '/',
    image,
    imageAlt: '나의 주말 등산 유형 테스트',
    themeColor: '#2f6b4f',
  })}
<body>
<main>
  <section id="start" class="screen">
    <img class="hero-img" src="/og/home.png" width="1200" height="630" alt="">
    <h1 class="start-title">나의 주말 등산 유형 테스트</h1>
    <p class="start-desc">주말 산행, 나는 어떤 스타일일까? 질문에 답하면 4가지 유형 중 하나를 알려 드려요.</p>
    <ul class="meta-list">
      <li>질문 ${QUESTIONS.length}개</li>
      <li>약 1분</li>
      <li>결과 ${Object.keys(RESULTS).length}가지</li>
    </ul>
    <div class="bottom">
      <button id="start-button" class="btn btn-primary" type="button">테스트 시작하기</button>
      <p class="privacy-note">이름이나 연락처를 묻지 않아요. 답은 어디에도 저장되지 않아요.</p>
    </div>
  </section>

  <section id="quiz" class="screen" hidden>
    <div class="quiz-top">
      <button id="back-button" class="back" type="button" aria-label="이전 질문">← 이전</button>
      <div class="progress" aria-hidden="true"><div id="progress-bar" class="progress-bar"></div></div>
      <span id="progress-text" class="progress-text" aria-live="polite"></span>
    </div>
    <h2 id="question-text" class="question" tabindex="-1"></h2>
    <div id="options" class="options"></div>
  </section>
</main>
<noscript><p class="screen">이 테스트는 JavaScript를 켜야 할 수 있어요.</p></noscript>
<script type="module" src="/assets/app.js"></script>
</body>
</html>
`;
}

function resultPage(r, image) {
  const mate = RESULTS[r.mate.id];
  const others = Object.values(RESULTS).filter((o) => o.id !== r.id);
  const title = resultOgTitle(r);
  return `${head({
    title,
    description: resultOgDescription(r),
    path: `/result/${r.id}/`,
    image,
    imageAlt: `나는 ${r.name} — ${r.tagline}`,
    themeColor: r.color,
  })}
<body class="theme-${r.id}" data-result="${r.id}">
<main class="screen result-page">
  <p class="eyebrow"><span class="mine-only">나의 주말 등산 유형은…</span><span class="friend-only">친구의 주말 등산 유형은…</span></p>
  <img class="hero-img" src="/og/${r.id}.png" width="1200" height="630" alt="">
  <h1 class="result-name">${r.emoji} ${esc(r.name)}</h1>
  <p class="result-tagline">"${esc(r.tagline)}"</p>
  <p class="result-desc">${esc(r.description)}</p>

  <section class="card">
    <h2>잘 맞는 등산 메이트</h2>
    <p><a href="/result/${mate.id}/">${mate.emoji} ${esc(mate.name)}</a> — ${esc(r.mate.reason)}</p>
  </section>
  <section class="card">
    <h2>추천 코스</h2>
    <ul>${r.courses.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>
  </section>
  <section class="card">
    <h2>챙길 것</h2>
    <p>${r.items.map(esc).join(', ')}</p>
  </section>

  <p class="others">다른 유형 보기: ${others
    .map((o) => `<a href="/result/${o.id}/">${o.emoji} ${esc(o.name)}</a>`)
    .join(' · ')}</p>

  <div class="actions">
    <div class="mine-only">
      <button id="share-button" class="btn btn-primary" type="button">친구에게 결과 공유하기</button>
    </div>
    <a class="btn btn-primary friend-only" href="/">나도 테스트하기</a>
    <div class="actions-row">
      <button id="copy-button" class="btn btn-secondary" type="button">링크 복사</button>
      <a class="btn btn-secondary" href="/">다시 하기</a>
    </div>
  </div>
</main>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<script type="module" src="/assets/result.js"></script>
</body>
</html>
`;
}

function notFoundPage(image) {
  return `${head({
    title: HOME_OG_TITLE,
    description: HOME_OG_DESCRIPTION,
    path: '/',
    image,
    imageAlt: '나의 주말 등산 유형 테스트',
    themeColor: '#2f6b4f',
  })}
<body>
<main class="screen">
  <h1 class="start-title">길을 잃었어요 🧭</h1>
  <p class="start-desc">찾는 페이지가 없어요. 등산로 입구로 돌아가 볼까요?</p>
  <div class="bottom"><a class="btn btn-primary" href="/">테스트 하러 가기</a></div>
</main>
</body>
</html>
`;
}

async function write(path, content) {
  const full = join(PUBLIC_DIR, path);
  await mkdir(join(full, '..'), { recursive: true });
  await writeFile(full, content);
}

await renderImages();
const homeImage = await imageUrl('home');
await write('index.html', homePage(homeImage));
await write('404.html', notFoundPage(homeImage));
for (const r of Object.values(RESULTS)) {
  await write(`result/${r.id}/index.html`, resultPage(r, await imageUrl(r.id)));
}
console.log(`완료: public/ 에 페이지 ${Object.keys(RESULTS).length + 2}개, 미리보기 이미지 ${Object.keys(RESULTS).length + 1}장`);
