// 사이트 주소가 바뀌면 여기만 고친 뒤 `npm run build`를 다시 실행한다.
export const SITE_URL = 'https://hiking-type-test.netlify.app';

export const SITE_TITLE = '나의 주말 등산 유형 테스트';
export const HOME_OG_TITLE = '나의 주말 등산 유형 테스트 ⛰️';
export const HOME_OG_DESCRIPTION = '질문 8개로 알아보는 나의 등산 스타일. 1분이면 끝나요!';

export const resultOgTitle = (r) => `나는 ${r.emoji} ${r.name}!`;
export const resultOgDescription = (r) => `${r.tagline}. 너의 등산 유형은?`;

export const OG_WIDTH = 1200;
export const OG_HEIGHT = 630;

// 외부 요청을 막는 보안 정책. public/_headers와 같은 내용을 유지한다.
export const CSP =
  "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; " +
  "connect-src 'none'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'";
