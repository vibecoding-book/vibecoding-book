import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const PUBLIC_DIR = resolve(fileURLToPath(new URL('../public', import.meta.url)));

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};

// Netlify처럼 /result/summit/ 요청에 index.html을 돌려주는 간단한 정적 서버
export function startServer(port = 0) {
  const server = createServer(async (req, res) => {
    const path = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    let file = normalize(join(PUBLIC_DIR, path));
    if (!file.startsWith(PUBLIC_DIR)) {
      res.writeHead(403).end();
      return;
    }
    try {
      if ((await stat(file)).isDirectory()) file = join(file, 'index.html');
      const body = await readFile(file);
      res.writeHead(200, { 'Content-Type': TYPES[extname(file)] ?? 'application/octet-stream' });
      res.end(body);
    } catch {
      const body = await readFile(join(PUBLIC_DIR, '404.html'));
      res.writeHead(404, { 'Content-Type': TYPES['.html'] }).end(body);
    }
  });
  return new Promise((done) => {
    server.listen(port, '127.0.0.1', () => {
      done({ server, url: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { url } = await startServer(Number(process.env.PORT) || 8080);
  console.log(`미리보기: ${url}  (휴대폰 화면은 브라우저 개발자 도구의 기기 모드로 확인)`);
}
