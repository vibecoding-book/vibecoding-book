// 질문 8개. 각 선택지는 한 유형에 1점을 준다.
// 유형이 티 나지 않도록 선택지 순서는 질문마다 다르게 적어 둔다.
// summit = 정상 정복형, picnic = 먹방 소풍형, scenery = 풍경 감성형, cafe = 입구 컷형

export const TYPES = ['summit', 'picnic', 'scenery', 'cafe'];

export const QUESTIONS = [
  {
    text: '토요일 아침, 알람이 울렸다. 나는?',
    options: [
      { type: 'scenery', text: '날씨 앱부터 본다. 하늘이 예뻐야 나간다' },
      { type: 'summit', text: '알람보다 먼저 일어나 있었다. 새벽 5시 출발!' },
      { type: 'cafe', text: '알람을 끈다… 오후에 등산로 입구 카페 가면 되지' },
      { type: 'picnic', text: '김밥집 문 여는 시간에 맞춰 일어난다' },
    ],
  },
  {
    text: '배낭에 꼭 챙기는 것은?',
    options: [
      { type: 'picnic', text: '김밥, 보온병, 컵라면, 과일 도시락' },
      { type: 'cafe', text: '지갑. 나머지는 가서 사면 된다' },
      { type: 'summit', text: '물 2리터와 에너지바. 가볍고 효율적으로' },
      { type: 'scenery', text: '보조배터리. 사진 찍다 폰이 꺼지면 안 되니까' },
    ],
  },
  {
    text: '산 입구 갈림길에 섰다. 어느 길로?',
    options: [
      { type: 'cafe', text: '갈림길 옆 매점 벤치에 일단 앉는다' },
      { type: 'scenery', text: '조금 돌아가도 계곡을 따라 걷는 길' },
      { type: 'picnic', text: '중간에 평상 있는 쉼터를 지나는 길' },
      { type: 'summit', text: '정상까지 가장 빠른 급경사 길' },
    ],
  },
  {
    text: '등산하면서 가장 행복한 순간은?',
    options: [
      { type: 'summit', text: '정상석 옆에서 인증샷 찍을 때' },
      { type: 'scenery', text: '나무 사이로 햇살이 쏟아질 때' },
      { type: 'picnic', text: '돗자리 펴고 도시락 뚜껑 열 때' },
      { type: 'cafe', text: '하산해서 등산화 벗을 때' },
    ],
  },
  {
    text: '친구가 "힘들어, 좀 쉬었다 가자" 한다면?',
    options: [
      { type: 'picnic', text: '"그럼 간식 타임!" 가방에서 귤을 꺼낸다' },
      { type: 'summit', text: '"5분만 더! 정상까지 30분 남았어"' },
      { type: 'cafe', text: '"그럼… 내려갈까?" (속으로 반가움)' },
      { type: 'scenery', text: '"좋아, 저기 경치 좋은 바위에 앉자"' },
    ],
  },
  {
    text: '내 등산 기록은 어디에 남아 있을까?',
    options: [
      { type: 'scenery', text: '사진첩. 오늘만 200장 찍었다' },
      { type: 'cafe', text: '만보기. 5천 보 넘으면 오늘 운동은 끝' },
      { type: 'summit', text: '앱에 거리·고도·속도까지. 지난번보다 빨라졌는지 비교한다' },
      { type: 'picnic', text: "기록은 없지만 '하산 맛집' 저장 목록은 꽉 찼다" },
    ],
  },
  {
    text: '하산하고 나서 나는?',
    options: [
      { type: 'cafe', text: '집에 가서 씻고 눕는다. 침대가 진짜 정상이다' },
      { type: 'picnic', text: '파전에 막걸리. 여기까지 해야 등산이다' },
      { type: 'summit', text: '다음 주에 갈 산을 검색한다' },
      { type: 'scenery', text: '오늘 찍은 사진 고르고 보정한다' },
    ],
  },
  {
    text: '나에게 등산이란?',
    options: [
      { type: 'scenery', text: '계절이 바뀌는 걸 가장 먼저 보는 일' },
      { type: 'picnic', text: '맛있는 걸 더 맛있게 먹는 방법' },
      { type: 'cafe', text: '산은 멀리서 볼 때 가장 아름답다' },
      { type: 'summit', text: '나와의 싸움. 오늘도 한계를 넘는다' },
    ],
  },
];
