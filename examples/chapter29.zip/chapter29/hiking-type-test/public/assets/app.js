import { QUESTIONS } from './questions.js';
import { computeResult } from './scoring.js';

const startScreen = document.getElementById('start');
const quizScreen = document.getElementById('quiz');
const startButton = document.getElementById('start-button');
const backButton = document.getElementById('back-button');
const progressBar = document.getElementById('progress-bar');
const progressText = document.getElementById('progress-text');
const questionText = document.getElementById('question-text');
const optionList = document.getElementById('options');

let answers = [];
let index = 0;
let locked = false;

function show(screen) {
  startScreen.hidden = screen !== startScreen;
  quizScreen.hidden = screen !== quizScreen;
  window.scrollTo(0, 0);
}

function renderQuestion() {
  const q = QUESTIONS[index];
  const step = index + 1;
  progressBar.style.width = `${(step / QUESTIONS.length) * 100}%`;
  progressText.textContent = `${step} / ${QUESTIONS.length}`;
  questionText.textContent = q.text;

  optionList.replaceChildren(
    ...q.options.map((option) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'option';
      button.textContent = option.text;
      button.dataset.type = option.type;
      if (answers[index] === option.type) button.classList.add('is-selected');
      button.addEventListener('click', () => choose(button, option.type));
      return button;
    }),
  );

  questionText.focus({ preventScroll: true });
  locked = false;
}

function choose(button, type) {
  if (locked) return;
  locked = true;
  button.classList.add('is-selected');
  answers[index] = type;

  // 누른 버튼이 잠깐 강조된 뒤 넘어가도록 짧게 기다린다.
  setTimeout(() => {
    if (index < QUESTIONS.length - 1) {
      index += 1;
      renderQuestion();
    } else {
      const id = computeResult(answers.slice(0, QUESTIONS.length));
      window.location.assign(`/result/${id}/?from=quiz`);
    }
  }, 180);
}

startButton.addEventListener('click', () => {
  answers = [];
  index = 0;
  show(quizScreen);
  renderQuestion();
});

backButton.addEventListener('click', () => {
  if (locked) return;
  if (index === 0) {
    show(startScreen);
    return;
  }
  index -= 1;
  renderQuestion();
});
