import { TYPES } from './questions.js';

// answers: 질문 순서대로 고른 유형 배열 (예: ['summit', 'picnic', ...])
// 가장 점수가 높은 유형을 돌려준다. 동점이면 마지막 질문부터 거꾸로 보며
// 동점 유형 중 가장 나중에 고른 답을 따른다 (보통 8번 질문에서 결정된다).
export function computeResult(answers) {
  const scores = Object.fromEntries(TYPES.map((t) => [t, 0]));
  for (const type of answers) {
    if (!(type in scores)) throw new Error(`알 수 없는 유형: ${type}`);
    scores[type] += 1;
  }

  const max = Math.max(...Object.values(scores));
  const tied = TYPES.filter((t) => scores[t] === max);
  if (tied.length === 1) return tied[0];

  for (let i = answers.length - 1; i >= 0; i -= 1) {
    if (tied.includes(answers[i])) return answers[i];
  }
  return tied[0];
}
