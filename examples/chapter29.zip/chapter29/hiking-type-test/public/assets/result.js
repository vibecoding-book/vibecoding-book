const shareUrl = document.querySelector('link[rel="canonical"]').href;
const shareTitle = document.querySelector('meta[property="og:title"]').content;
const shareText = document.querySelector('meta[property="og:description"]').content;
const toast = document.getElementById('toast');

// 테스트를 막 끝내고 온 경우 "나의 결과"로 보여 주고, 주소창에서 표시용 파라미터를 지운다.
const params = new URLSearchParams(window.location.search);
if (params.get('from') === 'quiz') {
  document.body.classList.add('is-mine');
  window.history.replaceState(null, '', window.location.pathname);
}

let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2600);
}

async function copyLink() {
  try {
    await navigator.clipboard.writeText(shareUrl);
  } catch {
    // 일부 인앱 브라우저는 clipboard API를 막아 두므로 예전 방식으로 한 번 더 시도한다.
    const temp = document.createElement('textarea');
    temp.value = shareUrl;
    temp.setAttribute('readonly', '');
    temp.className = 'offscreen';
    document.body.append(temp);
    temp.select();
    const ok = document.execCommand('copy');
    temp.remove();
    if (!ok) {
      showToast(`복사가 안 되면 이 주소를 길게 눌러 복사해 주세요: ${shareUrl}`);
      return;
    }
  }
  showToast('링크를 복사했어요. 카톡 대화방에 붙여 넣어 주세요!');
}

async function share() {
  if (navigator.share) {
    try {
      await navigator.share({ title: shareTitle, text: shareText, url: shareUrl });
      return;
    } catch (error) {
      if (error && error.name === 'AbortError') return; // 사용자가 공유창을 닫음
    }
  }
  await copyLink();
}

document.getElementById('share-button').addEventListener('click', share);
document.getElementById('copy-button').addEventListener('click', copyLink);
