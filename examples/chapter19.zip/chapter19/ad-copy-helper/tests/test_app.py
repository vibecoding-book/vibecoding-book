"""가짜 응답으로만 도는 테스트. 실제 API를 부르지 않고, 진짜 .env도 읽지 않는다.

실행: .venv\\Scripts\\python.exe -m unittest discover -s tests -v
"""

import datetime
import io
import json
import logging
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import adcopy  # noqa: E402
import server  # noqa: E402

FAKE_KEY = "sk-ant-api03-FAKE-TEST-KEY-1234567890abcdef"

CFG = {
    "model": "claude-haiku-5-5",
    "max_output_tokens": 1024,
    "daily_request_limit": 30,
    "candidate_count": 5,
    "title_max_chars": 15,
    "description_max_chars": 45,
    "retry_over_limit": True,
    "price_per_million_input_tokens_usd": None,
    "price_per_million_output_tokens_usd": None,
}

GOOD = [
    ("목 결림엔 넥케어", "온열 기능과 15분 자동 꺼짐으로 사무실에서도 편하게 쓰세요"),
    ("180g 가벼운 마사지기", "하루 종일 앉아 있는 직장인을 위한 무선 목 마사지기"),
    ("퇴근길 목 피로 해소", "USB-C로 간편하게 충전하고 어디서나 따뜻하게 풀어 주세요"),
    ("책상 위 작은 휴식", "점심시간 15분, 따뜻한 온열로 굳은 목을 부드럽게"),
    ("무선이라 더 편하게", "선 걱정 없이 목에 걸기만 하면 끝, 가벼운 180g"),
]
TOO_LONG = ("이 제목은 열다섯 글자를 훨씬 넘어가는 아주 긴 제목입니다", "짧은 설명")


def fake_response(pairs, stop_reason="end_turn", input_tokens=100, output_tokens=200):
    text = json.dumps({"candidates": [{"title": t, "description": d} for t, d in pairs]}, ensure_ascii=False)
    return SimpleNamespace(
        content=[SimpleNamespace(type="text", text=text)],
        usage=SimpleNamespace(input_tokens=input_tokens, output_tokens=output_tokens),
        stop_reason=stop_reason,
    )


class FakeClient:
    """messages.create(**kwargs)를 흉내 낸다. 미리 넣어 둔 응답(또는 예외)을 차례로 돌려준다."""

    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def make_gen(client, tmp, cfg=CFG, limit=None):
    limiter = adcopy.DailyLimiter(Path(tmp) / "usage.json", limit or cfg["daily_request_limit"])
    return adcopy.CopyGenerator(client, cfg, limiter)


ARGS = ("넥케어", "온열, 15분 자동 꺼짐, 180g, USB-C", "30~40대 직장인")


class CountTests(unittest.TestCase):
    def test_spaces_count(self):
        self.assertEqual(adcopy.count_chars("가 나"), 3)

    def test_decomposed_hangul_counts_as_one(self):
        decomposed = "가"  # ㄱ + ㅏ 따로 들어온 '가'
        self.assertEqual(adcopy.count_chars(decomposed), 1)

    def test_boundaries(self):
        ok = adcopy.check_candidate("가" * 15, "나" * 45, CFG)
        self.assertTrue(adcopy.is_ok(ok))
        over = adcopy.check_candidate("가" * 16, "나" * 46, CFG)
        self.assertFalse(over["title_ok"])
        self.assertFalse(over["description_ok"])

    def test_trims_outer_spaces_and_rejects_empty(self):
        c = adcopy.check_candidate("  넥케어  ", "", CFG)
        self.assertEqual(c["title"], "넥케어")
        self.assertFalse(c["description_ok"])


class GenerateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_good_response_single_call(self):
        client = FakeClient(fake_response(GOOD))
        result = make_gen(client, self.tmp).generate(*ARGS)
        self.assertEqual(len(client.calls), 1)
        self.assertEqual(len(result["candidates"]), 5)
        self.assertTrue(all(adcopy.is_ok(c) for c in result["candidates"]))
        self.assertEqual(result["usage"], {"input_tokens": 100, "output_tokens": 200, "requests": 1})
        self.assertEqual(result["notes"], [])

    def test_request_shape_has_output_cap_and_model(self):
        client = FakeClient(fake_response(GOOD))
        make_gen(client, self.tmp).generate(*ARGS)
        call = client.calls[0]
        self.assertEqual(call["model"], "claude-haiku-5-5")
        self.assertEqual(call["max_tokens"], 1024)
        self.assertNotIn(FAKE_KEY, json.dumps(call, ensure_ascii=False))

    def test_over_limit_is_retried_once_and_replaced(self):
        first = GOOD[:3] + [TOO_LONG, TOO_LONG]
        client = FakeClient(fake_response(first), fake_response(GOOD[3:], input_tokens=50, output_tokens=60))
        result = make_gen(client, self.tmp).generate(*ARGS)
        self.assertEqual(len(client.calls), 2)
        self.assertIn("정확히 4개", client.calls[1]["messages"][0]["content"])  # 넘친 2개 + 여유분 2개
        cands = result["candidates"]
        self.assertTrue(all(adcopy.is_ok(c) for c in cands))
        self.assertEqual([c["retried"] for c in cands], [False, False, False, True, True])
        self.assertEqual(result["usage"], {"input_tokens": 150, "output_tokens": 260, "requests": 2})
        self.assertEqual(result["daily"]["used"], 2)  # 다시 받기도 하루 횟수에 포함

    def test_still_over_after_retry_is_marked_not_retried_again(self):
        client = FakeClient(fake_response(GOOD[:4] + [TOO_LONG]), fake_response([TOO_LONG]))
        result = make_gen(client, self.tmp).generate(*ARGS)
        self.assertEqual(len(client.calls), 2)  # 딱 1번만 다시 받는다
        last = result["candidates"][4]
        self.assertFalse(last["title_ok"])
        self.assertTrue(last["retried"])
        self.assertTrue(any("여전히" in n for n in result["notes"]))

    def test_retry_disabled_only_marks(self):
        cfg = dict(CFG, retry_over_limit=False)
        client = FakeClient(fake_response(GOOD[:4] + [TOO_LONG]))
        result = make_gen(client, self.tmp, cfg=cfg).generate(*ARGS)
        self.assertEqual(len(client.calls), 1)
        self.assertFalse(adcopy.is_ok(result["candidates"][4]))

    def test_too_few_candidates_noted(self):
        client = FakeClient(fake_response(GOOD[:3]))
        result = make_gen(client, self.tmp).generate(*ARGS)
        self.assertEqual(len(result["candidates"]), 3)
        self.assertTrue(any("3개만" in n for n in result["notes"]))

    def test_truncated_output_reports_error(self):
        client = FakeClient(fake_response(GOOD, stop_reason="max_tokens"))
        with self.assertRaises(adcopy.UserFacingError) as cm:
            make_gen(client, self.tmp).generate(*ARGS)
        self.assertIn("출력 길이 제한", cm.exception.message)

    def test_broken_json_reports_error(self):
        bad = SimpleNamespace(content=[SimpleNamespace(type="text", text="not json")],
                              usage=SimpleNamespace(input_tokens=1, output_tokens=1), stop_reason="end_turn")
        with self.assertRaises(adcopy.UserFacingError):
            make_gen(FakeClient(bad), self.tmp).generate(*ARGS)

    def test_input_validation_does_not_call_api(self):
        client = FakeClient()
        gen = make_gen(client, self.tmp)
        with self.assertRaises(adcopy.UserFacingError):
            gen.generate("", "특징", "고객")
        with self.assertRaises(adcopy.UserFacingError):
            gen.generate("상품", "가" * 501, "고객")
        self.assertEqual(client.calls, [])

    def test_cost_blank_without_prices(self):
        self.assertIsNone(adcopy.estimate_cost({"input_tokens": 10, "output_tokens": 10}, CFG))
        cfg = dict(CFG, price_per_million_input_tokens_usd=1.0, price_per_million_output_tokens_usd=2.0)
        self.assertEqual(adcopy.estimate_cost({"input_tokens": 1_000_000, "output_tokens": 500_000}, cfg), 2.0)


class DuplicateRetryTests(unittest.TestCase):
    """사용자 제보 재현: 제목 8자로 줄였더니 다시 받은 문구가 기존 후보와 제목이 똑같았다."""

    CFG8 = dict(CFG, title_max_chars=8)
    ARGS = ("가을 경량 등산화 트레일핏", "무게 290g, 방수 원단, 미끄럼 방지 밑창, 발볼 넓은 디자인",
            "주말마다 근교 산을 오르는 30대 등산 입문자")
    FIRST = [
        ("가벼운 등산화", "무게 290g으로 근교 산행도 가볍게 시작하세요"),
        ("방수 등산화", "방수 원단으로 젖은 산길에서도 발이 보송하게"),
        ("미끄럼 걱정 끝", "미끄럼 방지 밑창으로 내리막도 안심하고 걸으세요"),
        ("주말 산행 입문자용 등산화", "처음 산에 오르는 30대를 위한 가벼운 트레일화"),  # 제목 초과
        ("발볼 넓은 편안한 트레일핏", "발볼 넓은 디자인으로 오래 걸어도 편안하게"),    # 제목 초과
    ]

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    @staticmethod
    def norm(title):
        return "".join(title.split())

    def test_retry_skips_titles_that_already_exist(self):
        retry = [
            ("가벼운 등산화", "가볍게 신고 주말 근교 산을 올라 보세요"),   # 기존 후보와 같음
            ("방수 등산화", "비 온 뒤 산길도 걱정 없는 방수 원단"),        # 기존 후보와 같음
            ("발볼 넓은 핏", "발볼 넓은 디자인으로 오래 걸어도 편안하게"),
            ("290g 경량화", "가벼운 290g, 등산 입문자의 첫 등산화"),
        ]
        client = FakeClient(fake_response(self.FIRST), fake_response(retry))
        result = make_gen(client, self.tmp, cfg=self.CFG8).generate(*self.ARGS)

        titles = [c["title"] for c in result["candidates"]]
        self.assertEqual(len({self.norm(t) for t in titles}), 5, titles)  # 제목 5개가 모두 달라야 한다
        self.assertTrue(all(adcopy.is_ok(c) for c in result["candidates"]))
        self.assertEqual(titles[3:], ["발볼 넓은 핏", "290g 경량화"])
        self.assertEqual(len(client.calls), 2)  # 다시 받기는 여전히 1번

        prompt = client.calls[1]["messages"][0]["content"]
        for kept in ("가벼운 등산화", "방수 등산화", "미끄럼 걱정 끝"):
            self.assertIn(kept, prompt)  # 겹치면 안 되는 기존 제목을 AI에게 알려 준다

    def test_duplicates_rejected_even_if_ai_only_returns_duplicates(self):
        retry = [
            ("가벼운 등산화", "가볍게 신고 주말 근교 산을 올라 보세요"),
            ("방수등산화", "비 온 뒤 산길도 걱정 없는 방수 원단"),  # 띄어쓰기만 다른 같은 제목
        ]
        client = FakeClient(fake_response(self.FIRST), fake_response(retry))
        result = make_gen(client, self.tmp, cfg=self.CFG8).generate(*self.ARGS)

        titles = [c["title"] for c in result["candidates"]]
        self.assertEqual(len({self.norm(t) for t in titles}), 5, titles)
        self.assertEqual(titles[3:], [self.FIRST[3][0], self.FIRST[4][0]])  # 원래 문구를 빨간 표시로 남긴다
        self.assertFalse(any(adcopy.is_ok(c) for c in result["candidates"][3:]))
        self.assertTrue(any("겹" in n for n in result["notes"]), result["notes"])

    def test_duplicate_titles_are_flagged(self):
        pairs = GOOD[:4] + [("목 결림엔 넥케어", "같은 제목이 또 나온 경우를 흉내 낸 설명입니다")]
        result = make_gen(FakeClient(fake_response(pairs)), self.tmp).generate(*ARGS)
        flags = [c["duplicate"] for c in result["candidates"]]
        self.assertEqual(flags, [False, False, False, False, True])
        self.assertTrue(any("겹" in n for n in result["notes"]), result["notes"])


class DailyLimitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def test_limit_30_blocks_31st(self):
        limiter = adcopy.DailyLimiter(Path(self.tmp) / "u.json", 30)
        self.assertTrue(all(limiter.try_consume() for _ in range(30)))
        self.assertFalse(limiter.try_consume())
        self.assertEqual(limiter.used(), 30)

    def test_resets_next_day(self):
        day = [datetime.date(2026, 10, 26)]
        limiter = adcopy.DailyLimiter(Path(self.tmp) / "u.json", 1, today=lambda: day[0])
        self.assertTrue(limiter.try_consume())
        self.assertFalse(limiter.try_consume())
        day[0] = datetime.date(2026, 10, 27)
        self.assertTrue(limiter.try_consume())

    def test_limit_reached_blocks_api_call(self):
        client = FakeClient(fake_response(GOOD))
        gen = make_gen(client, self.tmp, limit=1)
        gen.limiter.try_consume()
        with self.assertRaises(adcopy.UserFacingError) as cm:
            gen.generate(*ARGS)
        self.assertEqual(cm.exception.status, 429)
        self.assertEqual(client.calls, [])

    def test_retry_skipped_when_limit_hit(self):
        client = FakeClient(fake_response(GOOD[:4] + [TOO_LONG]))
        result = make_gen(client, self.tmp, limit=1).generate(*ARGS)
        self.assertEqual(len(client.calls), 1)
        self.assertFalse(adcopy.is_ok(result["candidates"][4]))
        self.assertTrue(any("다시 받지 못했습니다" in n for n in result["notes"]))


class EnvTests(unittest.TestCase):
    def test_reads_key_from_given_file(self):
        p = Path(tempfile.mkdtemp()) / ".env"
        p.write_text(f'OTHER=1\nANTHROPIC_API_KEY="{FAKE_KEY}"\n', encoding="utf-8")
        self.assertEqual(adcopy.load_api_key(p), FAKE_KEY)

    def test_missing_file(self):
        self.assertIsNone(adcopy.load_api_key(Path(tempfile.mkdtemp()) / "none.env"))


class KeyLeakServerTests(unittest.TestCase):
    """서버를 실제로 띄워서, 브라우저가 받을 수 있는 모든 것과 로그에 키가 없는지 확인한다."""

    def setUp(self):
        self.log = io.StringIO()
        adcopy.setup_logging(self.log)
        adcopy.redact.add(FAKE_KEY)
        self.tmp = tempfile.mkdtemp()
        self.client = FakeClient()
        self.factory_keys = []

        def factory(key):
            self.factory_keys.append(key)
            return self.client

        self.app = server.App(CFG, FAKE_KEY, Path(self.tmp) / "usage.json", client_factory=factory)
        self.srv = server.make_server(self.app, 0)
        self.base = f"http://127.0.0.1:{self.srv.server_address[1]}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.seen = []  # 브라우저가 받은 모든 응답(헤더+본문)

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()
        logging.getLogger().handlers[:] = []

    def req(self, path, body=None, headers=None, method=None):
        data = None if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
        h = {"Content-Type": "application/json"} if body is not None else {}
        h.update(headers or {})
        r = urllib.request.Request(self.base + path, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(r) as resp:
                status, hdrs, raw = resp.status, str(resp.headers), resp.read()
        except urllib.error.HTTPError as e:
            status, hdrs, raw = e.code, str(e.headers), e.read()
        text = raw.decode("utf-8")
        self.seen.append(hdrs + text)
        return status, text

    def assert_no_key_anywhere(self):
        everything = "\n".join(self.seen)
        self.assertNotIn(FAKE_KEY, everything)
        self.assertNotIn("FAKE-TEST-KEY", everything)
        self.assertNotIn(FAKE_KEY, self.log.getvalue())
        self.assertNotIn("FAKE-TEST-KEY", self.log.getvalue())

    def test_pages_status_and_success(self):
        for path in ("/", "/index.html", "/app.js", "/style.css", "/api/status"):
            status, _ = self.req(path)
            self.assertEqual(status, 200, path)
        self.client.responses.append(fake_response(GOOD))
        status, text = self.req("/api/generate", {"product": ARGS[0], "features": ARGS[1], "audience": ARGS[2]})
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(text)["candidates"]), 5)
        self.assertEqual(self.factory_keys, [FAKE_KEY])  # 키는 서버 안의 클라이언트로만 간다
        self.assert_no_key_anywhere()

    def test_static_files_never_mention_key(self):
        for name in ("index.html", "app.js", "style.css"):
            text = (ROOT / "app" / "static" / name).read_text(encoding="utf-8")
            self.assertNotIn("ANTHROPIC_API_KEY", text)
            self.assertNotIn("sk-ant", text)

    def test_env_and_source_files_not_served(self):
        for path in ("/.env", "/../.env", "/%2e%2e/.env", "/config.json", "/app/server.py",
                     "/static/../../.env", "/usage.json"):
            status, _ = self.req(path)
            self.assertEqual(status, 404, path)
        self.assert_no_key_anywhere()

    def test_error_containing_key_is_hidden(self):
        # SDK 오류 메시지에 키가 섞여 있는 최악의 경우를 흉내 낸다
        self.client.responses.append(RuntimeError(f"boom with key {FAKE_KEY} and header x-api-key: {FAKE_KEY}"))
        status, text = self.req("/api/generate", {"product": "a", "features": "b", "audience": "c"})
        self.assertEqual(status, 502)
        self.assertIn("error", json.loads(text))
        self.assertIn("RuntimeError", self.log.getvalue())  # 로그에는 남되
        self.assert_no_key_anywhere()                        # 키는 가려진다

    def test_sdk_auth_error_message(self):
        import anthropic
        import httpx2 as httpx  # anthropic SDK 2.x가 쓰는 HTTP 라이브러리
        resp = httpx.Response(401, request=httpx.Request("POST", "https://api.anthropic.com/v1/messages"),
                              json={"error": {"message": f"invalid x-api-key {FAKE_KEY}"}})
        self.client.responses.append(anthropic.AuthenticationError(f"invalid {FAKE_KEY}", response=resp, body=None))
        status, text = self.req("/api/generate", {"product": "a", "features": "b", "audience": "c"})
        self.assertEqual(status, 502)
        self.assertIn("API 키가 올바르지 않습니다", json.loads(text)["error"])
        self.assert_no_key_anywhere()

    def test_bad_requests(self):
        cases = [
            self.req("/api/generate", b"not json"),
            self.req("/api/generate", {"product": "", "features": "b", "audience": "c"}),
            self.req("/api/generate", b"x", headers={"Content-Type": "text/plain"}),
            self.req("/api/nope", {"a": 1}),
        ]
        self.assertEqual([c[0] for c in cases], [400, 400, 415, 404])
        self.assertEqual(self.client.calls, [])
        self.assert_no_key_anywhere()

    def test_deeply_nested_json_rejected_with_message(self):
        # 길이 제한(MAX_BODY) 안에서도 아주 깊게 중첩된 JSON은 파이썬 재귀 한도를 넘긴다
        for body in (b"[" * 5000, b'{"a":' * 2000):
            status, text = self.req("/api/generate", body)
            self.assertEqual(status, 400)
            self.assertEqual(json.loads(text), {"error": "요청을 읽지 못했습니다."})
        self.assertEqual(self.client.calls, [])
        self.assert_no_key_anywhere()

    def test_daily_limit_over_http(self):
        for _ in range(CFG["daily_request_limit"]):
            self.app.limiter.try_consume()
        status, text = self.req("/api/generate", {"product": "a", "features": "b", "audience": "c"})
        self.assertEqual(status, 429)
        self.assertEqual(json.loads(text)["daily"], {"used": 30, "limit": 30})
        self.assertEqual(self.client.calls, [])

    def test_other_sites_blocked(self):
        status, _ = self.req("/api/generate", {"product": "a", "features": "b", "audience": "c"},
                             headers={"Origin": "https://evil.example"})
        self.assertEqual(status, 403)
        status, _ = self.req("/api/status", headers={"Host": "evil.example"})
        self.assertEqual(status, 403)
        self.assertEqual(self.client.calls, [])

    def test_missing_key_message(self):
        app = server.App(CFG, None, Path(self.tmp) / "u2.json", client_factory=lambda k: self.client)
        with self.assertRaises(adcopy.UserFacingError) as cm:
            app.generator()
        self.assertIn(".env", cm.exception.message)


if __name__ == "__main__":
    unittest.main()
