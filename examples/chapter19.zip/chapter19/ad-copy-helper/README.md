> **⚠️ 나눠 주기 전에 / 받은 뒤에**
> - **나눠 주는 사람:** 이 폴더를 압축하거나 복사해서 건네기 전에 **`.env` 파일을 반드시 지우세요.** 여기에 내 API 키가 들어 있습니다. (`.gitignore`는 git을 쓸 때만 효과가 있고, 폴더째 압축하면 `.env`도 그대로 들어갑니다.)
> - **받은 사람:** `.env.example`을 복사해 이름을 `.env`로 바꾸고, `ANTHROPIC_API_KEY=` 뒤에 **자기 API 키**를 넣으세요.

# 광고 문구 도우미

상품 이름·특징·대상 고객을 넣으면 Claude(Haiku 5.5)가 검색광고 문구 후보 5개를 써 줍니다.

## 실행
`run.bat`을 더블클릭하세요. 처음 한 번은 준비(패키지 설치)에 1분쯤 걸리고, 그다음엔 바로 브라우저가 열립니다.
검은 창을 닫으면 프로그램이 꺼집니다.

## 설정 (`config.json`)
| 항목 | 뜻 |
|---|---|
| `max_output_tokens` | 한 번 요청할 때 AI가 쓸 수 있는 최대 출력 길이(토큰). 기본 1024 |
| `daily_request_limit` | 하루 요청 횟수 한도. 기본 30 (넘친 문구 다시 받기도 1회로 셈) |
| `title_max_chars` / `description_max_chars` | 제목 15자 / 설명 45자 (공백 포함) |
| `retry_over_limit` | 글자 수를 넘은 문구를 1번 다시 받을지 (`true`/`false`) |
| `price_per_million_input_tokens_usd` / `price_per_million_output_tokens_usd` | 100만 토큰당 단가(달러). 비워 두면(`null`) 화면에 "단가 미설정"으로 나옵니다. Anthropic 요금표에서 확인한 값을 직접 넣으세요 |

하루 사용 횟수는 `usage.json`에 기록되고, PC 날짜가 바뀌면 0으로 돌아갑니다.

## 안전장치
- API 키는 `.env`에서 서버(내 PC)만 읽고, 브라우저에는 보내지 않습니다. 로그·오류 문구에서도 가립니다.
- 서버는 `127.0.0.1`(내 PC)에서만 열리고, 다른 웹사이트에서 오는 요청은 막습니다.
- SDK의 자동 재시도는 꺼 두었습니다(하루 횟수 밖에서 요금이 나가지 않도록).

## 테스트 (실제 API를 부르지 않음)
```
.venv\Scripts\python.exe -m unittest discover -s tests -v
```
