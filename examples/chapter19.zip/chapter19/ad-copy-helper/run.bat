@echo off
rem Ad Copy Helper - double-click to start
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
chcp 65001 >nul

if not exist ".venv\setup.ok" (
  echo [1/2] First run: preparing Python environment...
  if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv 2>nul || python -m venv .venv
  )
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
  if errorlevel 1 (
    echo Package install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
  echo ok> ".venv\setup.ok"
)

echo [2/2] Starting...
".venv\Scripts\python.exe" app\server.py
pause
