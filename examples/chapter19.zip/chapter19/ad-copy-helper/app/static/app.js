// 화면 동작. AI가 쓴 글은 textContent로만 넣는다(HTML로 해석하지 않음).
const $ = (id) => document.getElementById(id);
let limits = { title: 15, description: 45 };

function showMessage(text, kind) {
  const el = $("message");
  el.textContent = text;
  el.className = "message " + (kind || "");
  el.hidden = !text;
}

function showDaily(daily) {
  if (!daily) return;
  $("daily").textContent = `오늘 사용: ${daily.used} / ${daily.limit}회`;
  $("submit").disabled = daily.used >= daily.limit;
}

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function line(label, text, len, max, ok) {
  const row = el("div", "line" + (ok ? "" : " over"));
  row.append(el("span", "label", label), el("span", "text", text || "(비어 있음)"));
  row.append(el("span", "count", `${len}/${max}자${ok ? "" : " 초과"}`));
  return row;
}

async function copy(text, button) {
  try {
    await navigator.clipboard.writeText(text);
    button.textContent = "복사됨";
    setTimeout(() => (button.textContent = "복사"), 1200);
  } catch {
    button.textContent = "복사 실패";
  }
}

function render(data) {
  const list = $("list");
  list.replaceChildren();
  for (const c of data.candidates) {
    const item = el("li", "card" + (c.title_ok && c.description_ok && !c.duplicate ? "" : " bad"));
    item.append(line("제목", c.title, c.title_len, limits.title, c.title_ok));
    item.append(line("설명", c.description, c.description_len, limits.description, c.description_ok));
    const foot = el("div", "foot");
    if (c.retried) foot.append(el("span", "tag", "다시 받은 문구"));
    if (c.duplicate) foot.append(el("span", "tag dup", "제목 중복"));
    const btn = el("button", "copy", "복사");
    btn.type = "button";
    btn.addEventListener("click", () => copy(`${c.title}\n${c.description}`, btn));
    foot.append(btn);
    item.append(foot);
    list.append(item);
  }

  const u = data.usage;
  const total = u.input_tokens + u.output_tokens;
  let costText = "예상 비용: 단가 미설정 (config.json에서 입력)";
  if (data.cost_usd !== null && data.cost_usd !== undefined) costText = `예상 비용: 약 $${data.cost_usd}`;
  $("usage").replaceChildren(
    el("strong", null, `이번에 쓴 토큰: ${total.toLocaleString()}개`),
    el("span", null, ` (입력 ${u.input_tokens.toLocaleString()} · 출력 ${u.output_tokens.toLocaleString()} · API 요청 ${u.requests}회)`),
    el("div", "muted", costText),
  );

  const notes = $("notes");
  notes.replaceChildren(...data.notes.map((n) => el("li", null, n)));
  $("result").hidden = false;
}

async function loadStatus() {
  try {
    const res = await fetch("/api/status");
    const s = await res.json();
    limits = { title: s.title_max_chars, description: s.description_max_chars };
    $("rules").textContent = `제목 ${s.title_max_chars}자 · 설명 ${s.description_max_chars}자 이내(공백 포함), 후보 ${s.candidate_count}개`;
    showDaily(s.daily);
    if (!s.key_configured) showMessage("API 키가 없습니다. 이 폴더의 .env 파일을 확인해 주세요.", "error");
  } catch {
    showMessage("서버에 연결하지 못했습니다. 실행 창이 켜져 있는지 확인해 주세요.", "error");
  }
}

$("form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const btn = $("submit");
  btn.disabled = true;
  btn.textContent = "만드는 중…";
  showMessage("");
  try {
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product: $("product").value,
        features: $("features").value,
        audience: $("audience").value,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      showMessage(data.error || "오류가 났습니다.", "error");
      showDaily(data.daily);
      return;
    }
    render(data);
    showDaily(data.daily);
  } catch {
    showMessage("서버에 연결하지 못했습니다. 실행 창이 켜져 있는지 확인해 주세요.", "error");
  } finally {
    btn.textContent = "문구 만들기";
    btn.disabled = false;
    loadStatus(); // 하루 한도에 닿았으면 여기서 다시 버튼을 잠근다
  }
});

loadStatus();
