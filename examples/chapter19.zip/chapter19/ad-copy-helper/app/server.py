"""광고 문구 도우미 로컬 웹 서버.

내 PC(127.0.0.1)에서만 열리고, 브라우저에는 화면 파일 3개와 결과 JSON만 보낸다.
API 키는 서버 메모리에만 있고 응답·로그로 나가지 않는다.
"""

import json
import logging
import socket
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import adcopy  # noqa: E402

log = logging.getLogger("server")

STATIC_DIR = Path(__file__).resolve().parent / "static"
# 이 목록에 있는 파일만 내보낸다. 다른 경로(.env 등)는 모두 404.
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
}
MAX_BODY = 10_000


def make_real_client(api_key):
    import anthropic
    # max_retries=0: SDK가 몰래 재시도하면 하루 횟수 밖에서 요금이 나가므로 끈다.
    return anthropic.Anthropic(api_key=api_key, max_retries=0, timeout=60)


def explain_api_error(exc):
    """SDK 오류를 화면용 고정 문구로 바꾼다. 원래 오류 문자열은 화면에 내보내지 않는다."""
    try:
        import anthropic
    except ImportError:
        return "AI 호출 중 오류가 났습니다.", 502
    if isinstance(exc, anthropic.AuthenticationError):
        return "API 키가 올바르지 않습니다. .env 파일의 ANTHROPIC_API_KEY를 확인해 주세요.", 502
    if isinstance(exc, anthropic.PermissionDeniedError):
        return "이 API 키로는 해당 모델을 쓸 권한이 없습니다.", 502
    if isinstance(exc, anthropic.NotFoundError):
        return "설정된 모델을 찾을 수 없습니다. config.json의 model 값을 확인해 주세요.", 502
    if isinstance(exc, anthropic.RateLimitError):
        return "API 요청이 너무 잦습니다. 잠시 후 다시 시도해 주세요.", 503
    if isinstance(exc, anthropic.BadRequestError):
        return "AI 요청 형식에 문제가 있습니다. 창에 찍힌 로그를 확인해 주세요.", 502
    if isinstance(exc, anthropic.APIStatusError):
        return "AI 서버 쪽 오류입니다. 잠시 후 다시 시도해 주세요.", 502
    if isinstance(exc, anthropic.APIConnectionError):
        return "인터넷 연결을 확인해 주세요.", 502
    return "AI 호출 중 오류가 났습니다.", 502


class App:
    def __init__(self, cfg, api_key, usage_path, client_factory=make_real_client):
        self.cfg = cfg
        self._api_key = api_key
        self._client_factory = client_factory
        self._client = None
        self._lock = threading.Lock()
        self.limiter = adcopy.DailyLimiter(usage_path, cfg["daily_request_limit"])

    def generator(self):
        if not self._api_key:
            raise adcopy.UserFacingError(
                "API 키가 없습니다. 이 폴더의 .env 파일에 ANTHROPIC_API_KEY를 넣어 주세요.", 500)
        with self._lock:
            if self._client is None:
                self._client = self._client_factory(self._api_key)
        return adcopy.CopyGenerator(self._client, self.cfg, self.limiter)

    def status(self):
        cfg = self.cfg
        return {
            "model": cfg["model"],
            "max_output_tokens": cfg["max_output_tokens"],
            "title_max_chars": cfg["title_max_chars"],
            "description_max_chars": cfg["description_max_chars"],
            "candidate_count": cfg["candidate_count"],
            "daily": {"used": self.limiter.used(), "limit": self.limiter.limit},
            "price_configured": adcopy.estimate_cost({"input_tokens": 0, "output_tokens": 0}, cfg) is not None,
            "key_configured": bool(self._api_key),
            "input_limits": adcopy.INPUT_LIMITS,
        }


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = "AdCopyHelper"
        sys_version = ""

        def log_message(self, fmt, *args):
            log.info("%s %s", self.command, self.path.split("?")[0])

        def _send(self, status, body, content_type):
            data = body if isinstance(body, bytes) else body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)

        def _json(self, status, obj):
            # 마지막 방어선: 어떤 응답에도 키가 섞이지 않도록 한 번 더 가린다.
            self._send(status, adcopy.redact(json.dumps(obj, ensure_ascii=False)), "application/json; charset=utf-8")

        def _host_ok(self):
            # 다른 웹사이트가 이 서버를 부르는 것(DNS 리바인딩·CSRF)을 막는다.
            port = self.server.server_address[1]
            allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
            if self.headers.get("Host") not in allowed:
                return False
            origin = self.headers.get("Origin")
            return origin is None or origin in {f"http://{h}" for h in allowed}

        def do_GET(self):
            if not self._host_ok():
                return self._json(403, {"error": "허용되지 않은 접근입니다."})
            path = self.path.split("?")[0]
            if path == "/api/status":
                return self._json(200, app.status())
            if path in STATIC_FILES:
                name, ctype = STATIC_FILES[path]
                return self._send(200, (STATIC_DIR / name).read_bytes(), ctype)
            self._json(404, {"error": "없는 주소입니다."})

        def do_POST(self):
            if not self._host_ok():
                return self._json(403, {"error": "허용되지 않은 접근입니다."})
            if self.path != "/api/generate":
                return self._json(404, {"error": "없는 주소입니다."})
            if not (self.headers.get("Content-Type") or "").startswith("application/json"):
                return self._json(415, {"error": "JSON으로 보내 주세요."})
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            if length <= 0 or length > MAX_BODY:
                return self._json(413, {"error": "입력이 너무 길거나 비어 있습니다."})
            try:
                body = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(body, dict):
                    raise ValueError
            except (ValueError, UnicodeDecodeError, RecursionError):  # RecursionError: 아주 깊게 중첩된 JSON
                return self._json(400, {"error": "요청을 읽지 못했습니다."})

            try:
                result = app.generator().generate(body.get("product"), body.get("features"), body.get("audience"))
                return self._json(200, result)
            except adcopy.UserFacingError as e:
                return self._json(e.status, {"error": e.message, "daily": app.status()["daily"]})
            except Exception as e:  # SDK 오류 등: 자세한 내용은 (키를 가린) 로그로만
                log.error("API 호출 실패: %s: %s", type(e).__name__, e)
                message, status = explain_api_error(e)
                return self._json(status, {"error": message, "daily": app.status()["daily"]})

    return Handler


def make_server(app, port):
    try:
        return ThreadingHTTPServer(("127.0.0.1", port), make_handler(app))
    except OSError:
        return ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app))  # 포트가 쓰이고 있으면 빈 포트


def main():
    adcopy.setup_logging(sys.stdout)
    cfg = adcopy.load_config()
    api_key = adcopy.load_api_key()
    app = App(cfg, api_key, adcopy.DEFAULT_USAGE_PATH)
    server = make_server(app, cfg.get("port", 8765))
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    print("=" * 50)
    print(" 광고 문구 도우미가 켜졌습니다.")
    print(f" 브라우저 주소: {url}")
    print(f" API 키: {'읽음' if api_key else '없음 (.env 확인)'}")
    print(" 끝내려면 이 창을 닫거나 Ctrl+C를 누르세요.")
    print("=" * 50)
    threading.Timer(0.5, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
