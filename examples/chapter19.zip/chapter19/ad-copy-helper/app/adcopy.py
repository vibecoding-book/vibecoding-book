"""광고 문구 도우미의 핵심 로직.

- 설정/키 읽기, 글자 수 검사, 하루 요청 횟수 제한, Claude 호출과 '넘친 문구 다시 받기'.
- API 키는 이 모듈과 server.py의 서버 쪽 메모리에만 머문다. 브라우저로 가는 값에는 절대 넣지 않는다.
"""

import datetime
import json
import logging
import re
import threading
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = ROOT / "config.json"
DEFAULT_ENV_PATH = ROOT / ".env"
DEFAULT_USAGE_PATH = ROOT / "usage.json"

log = logging.getLogger("adcopy")

# 입력 길이 제한 (입력 토큰 비용도 묶어 두기 위해)
INPUT_LIMITS = {"product": 50, "features": 500, "audience": 200}
# 다시 받을 때 겹치는 후보를 걸러 낼 여유분
RETRY_EXTRA = 2


# ---------------------------------------------------------------- 키 가리기

_KEY_PATTERN = re.compile(r"sk-ant-[A-Za-z0-9_\-]+")


class Redactor:
    """로그·오류 문구에서 API 키를 지운다. 키 원문과 'sk-ant-...' 모양을 모두 가린다."""

    def __init__(self):
        self._secrets = []

    def add(self, secret):
        if secret:
            self._secrets.append(secret)

    def __call__(self, text):
        text = str(text)
        for s in self._secrets:
            text = text.replace(s, "[숨김]")
        return _KEY_PATTERN.sub("[숨김]", text)


redact = Redactor()


class RedactingFilter(logging.Filter):
    def filter(self, record):
        record.msg = redact(record.getMessage())
        record.args = ()
        return True


def setup_logging(stream=None):
    handler = logging.StreamHandler(stream)
    handler.addFilter(RedactingFilter())
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S"))
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(logging.INFO)
    return handler


# ---------------------------------------------------------------- 설정과 키

def load_config(path=DEFAULT_CONFIG_PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def load_api_key(path=DEFAULT_ENV_PATH):
    """.env에서 ANTHROPIC_API_KEY만 읽는다. 값은 어디에도 출력하지 않는다."""
    try:
        text = Path(path).read_text(encoding="utf-8-sig")
    except FileNotFoundError:
        return None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("export "):
            line = line[len("export "):].strip()
        name, sep, value = line.partition("=")
        if sep and name.strip() == "ANTHROPIC_API_KEY":
            value = value.strip().strip('"').strip("'")
            if value:
                redact.add(value)
                return value
    return None


# ---------------------------------------------------------------- 글자 수

def count_chars(text):
    """공백 포함 글자 수. 한글 자모가 분리돼 들어와도 한 글자로 세도록 NFC로 맞춘다."""
    return len(unicodedata.normalize("NFC", text))


def check_candidate(title, description, cfg):
    title = (title or "").strip()
    description = (description or "").strip()
    t, d = count_chars(title), count_chars(description)
    return {
        "title": title,
        "description": description,
        "title_len": t,
        "description_len": d,
        "title_ok": 0 < t <= cfg["title_max_chars"],
        "description_ok": 0 < d <= cfg["description_max_chars"],
    }


def is_ok(c):
    return c["title_ok"] and c["description_ok"]


def title_key(title):
    """제목 중복 비교용. 띄어쓰기·대소문자만 다른 제목은 같은 것으로 본다."""
    return "".join(unicodedata.normalize("NFC", title).split()).casefold()


def mark_duplicates(candidates):
    """앞에 같은 제목이 이미 있으면 duplicate=True. 겹친 개수를 돌려준다."""
    seen = set()
    for c in candidates:
        key = title_key(c["title"])
        c["duplicate"] = key in seen
        seen.add(key)
    return sum(c["duplicate"] for c in candidates)


# ---------------------------------------------------------------- 하루 요청 횟수

class DailyLimiter:
    """하루(내 PC 날짜 기준) 요청 횟수를 파일에 기록한다. 보내기 '전에' 한 칸을 차지한다."""

    def __init__(self, path, limit, today=datetime.date.today):
        self.path = Path(path)
        self.limit = limit
        self.today = today
        self._lock = threading.Lock()

    def _read(self):
        today = self.today().isoformat()
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if data.get("date") == today:
                return today, int(data.get("count", 0))
        except (FileNotFoundError, ValueError, TypeError):
            pass
        return today, 0

    def used(self):
        with self._lock:
            return self._read()[1]

    def try_consume(self):
        with self._lock:
            today, count = self._read()
            if count >= self.limit:
                return False
            self.path.write_text(json.dumps({"date": today, "count": count + 1}), encoding="utf-8")
            return True


# ---------------------------------------------------------------- Claude 호출

class UserFacingError(Exception):
    """화면에 그대로 보여 줘도 되는 오류 (키나 내부 정보가 들어가지 않는 고정 문구)."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


SYSTEM_PROMPT = (
    "당신은 한국어 검색광고 카피라이터입니다. "
    "검색광고 문구는 제목과 설명으로 이루어집니다. "
    "제목은 공백 포함 {title}자 이내, 설명은 공백 포함 {desc}자 이내여야 합니다. 이 글자 수는 절대 넘기지 마세요. "
    "과장·최상급 표현(최고, 1위, 100% 등)과 확인할 수 없는 사실은 쓰지 마세요. "
    "후보끼리 서로 다른 각도(혜택, 문제 해결, 대상 고객, 신뢰 등)로 쓰세요."
)


def _schema():
    return {
        "type": "object",
        "properties": {
            "candidates": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "description": {"type": "string"},
                    },
                    "required": ["title", "description"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["candidates"],
        "additionalProperties": False,
    }


def validate_inputs(product, features, audience):
    values = {"product": product, "features": features, "audience": audience}
    names = {"product": "상품 이름", "features": "특징", "audience": "대상 고객"}
    cleaned = {}
    for key, value in values.items():
        value = (value or "").strip() if isinstance(value, str) else ""
        if not value:
            raise UserFacingError(f"{names[key]}을(를) 입력해 주세요.")
        if count_chars(value) > INPUT_LIMITS[key]:
            raise UserFacingError(f"{names[key]}은(는) {INPUT_LIMITS[key]}자 이내로 입력해 주세요.")
        cleaned[key] = value
    return cleaned


class CopyGenerator:
    def __init__(self, client, cfg, limiter):
        self.client = client
        self.cfg = cfg
        self.limiter = limiter

    def _call(self, user_text, usage):
        """API 한 번 호출. 하루 횟수를 먼저 차지하고, 토큰 사용량을 usage에 더한다."""
        if not self.limiter.try_consume():
            raise UserFacingError(
                f"오늘 요청 한도({self.limiter.limit}회)를 다 썼습니다. 내일 다시 사용해 주세요.", status=429
            )
        usage["requests"] += 1
        system = SYSTEM_PROMPT.format(title=self.cfg["title_max_chars"], desc=self.cfg["description_max_chars"])
        response = self.client.messages.create(
            model=self.cfg["model"],
            max_tokens=self.cfg["max_output_tokens"],
            thinking={"type": "disabled"},
            system=system,
            messages=[{"role": "user", "content": user_text}],
            output_config={"format": {"type": "json_schema", "schema": _schema()}},
        )
        u = getattr(response, "usage", None)
        usage["input_tokens"] += getattr(u, "input_tokens", 0) or 0
        usage["output_tokens"] += getattr(u, "output_tokens", 0) or 0
        log.info("API 호출 완료: stop_reason=%s 입력 %s / 출력 %s 토큰",
                 response.stop_reason, getattr(u, "input_tokens", "?"), getattr(u, "output_tokens", "?"))

        if response.stop_reason == "max_tokens":
            raise UserFacingError("응답이 출력 길이 제한에 걸려 잘렸습니다. 특징을 조금 줄여서 다시 시도해 주세요.", 502)
        if response.stop_reason == "refusal":
            raise UserFacingError("AI가 이 요청에 대한 문구 작성을 거절했습니다. 입력 내용을 바꿔 보세요.", 502)
        text = "".join(b.text for b in response.content if getattr(b, "type", None) == "text")
        try:
            items = json.loads(text)["candidates"]
            return [(str(i.get("title", "")), str(i.get("description", ""))) for i in items if isinstance(i, dict)]
        except (ValueError, KeyError, TypeError, AttributeError):
            raise UserFacingError("AI 응답을 읽지 못했습니다. 다시 시도해 주세요.", 502)

    def generate(self, product, features, audience):
        inputs = validate_inputs(product, features, audience)
        cfg = self.cfg
        n = cfg["candidate_count"]
        usage = {"input_tokens": 0, "output_tokens": 0, "requests": 0}
        notes = []

        first = (
            f"다음 상품의 검색광고 문구 후보를 정확히 {n}개 써 주세요.\n\n"
            f"<상품이름>{inputs['product']}</상품이름>\n"
            f"<특징>{inputs['features']}</특징>\n"
            f"<대상고객>{inputs['audience']}</대상고객>"
        )
        pairs = self._call(first, usage)[:n]
        if len(pairs) < n:
            notes.append(f"AI가 후보를 {len(pairs)}개만 보냈습니다.")
        candidates = [dict(check_candidate(t, d, cfg), retried=False) for t, d in pairs]

        bad = [i for i, c in enumerate(candidates) if not is_ok(c)]
        if bad and cfg.get("retry_over_limit", True):
            kept = [c["title"] for i, c in enumerate(candidates) if i not in bad]
            lines = "\n".join(
                f"- 제목 \"{candidates[i]['title']}\"({candidates[i]['title_len']}자), "
                f"설명 \"{candidates[i]['description']}\"({candidates[i]['description_len']}자)"
                for i in bad
            )
            kept_lines = "\n".join(f"- {t}" for t in kept) or "- (없음)"
            # 겹치는 후보를 걸러 내고도 채울 수 있게 몇 개 더 받는다 (요청은 여전히 1번).
            want = len(bad) + RETRY_EXTRA
            retry = (
                f"{first}\n\n아래 문구는 글자 수 규칙(제목 {cfg['title_max_chars']}자, "
                f"설명 {cfg['description_max_chars']}자, 공백 포함)을 어겼습니다.\n{lines}\n\n"
                f"이미 확정된 후보의 제목은 다음과 같습니다. 이 제목들과 같거나 비슷한 제목은 쓰지 마세요.\n"
                f"{kept_lines}\n\n"
                f"규칙을 지키면서 위 제목들과 겹치지 않고 서로도 다른 새 후보를 정확히 {want}개 써 주세요. 더 짧게 쓰세요."
            )
            try:
                new_pairs = self._call(retry, usage)
            except UserFacingError as e:
                notes.append(f"넘친 문구를 다시 받지 못했습니다: {e.message}")
                new_pairs = []

            # 프로그램이 직접 겹침을 걸러 낸다. 규칙을 지킨 후보를 먼저, 그다음 넘친 후보 순으로 쓴다.
            taken = {title_key(t) for t in kept}
            pool = []
            for t, d in new_pairs:
                c = check_candidate(t, d, cfg)
                if c["title"] and title_key(c["title"]) not in taken:
                    taken.add(title_key(c["title"]))
                    pool.append(dict(c, retried=True))
            dropped = len(new_pairs) - len(pool)
            pool.sort(key=lambda c: not is_ok(c))
            for i, c in zip(bad, pool):
                candidates[i] = c
            if len(pool) < len(bad) and dropped:
                notes.append("다시 받은 문구가 기존 후보와 제목이 겹쳐서, 원래 문구를 그대로 두었습니다.")

        dup = mark_duplicates(candidates)
        if dup:
            notes.append(f"{dup}개 문구의 제목이 다른 후보와 겹칩니다('제목 중복' 표시).")
        still_bad = sum(1 for c in candidates if not is_ok(c))
        if still_bad:
            notes.append(f"{still_bad}개 문구가 여전히 글자 수를 넘습니다(빨간색 표시). 직접 다듬어 주세요.")

        return {
            "candidates": candidates,
            "usage": usage,
            "cost_usd": estimate_cost(usage, cfg),
            "daily": {"used": self.limiter.used(), "limit": self.limiter.limit},
            "notes": notes,
        }


def estimate_cost(usage, cfg):
    """단가가 설정돼 있을 때만 계산한다. 비어 있으면(null) None을 돌려준다."""
    pin = cfg.get("price_per_million_input_tokens_usd")
    pout = cfg.get("price_per_million_output_tokens_usd")
    if pin is None or pout is None:
        return None
    return round(usage["input_tokens"] / 1e6 * pin + usage["output_tokens"] / 1e6 * pout, 6)
