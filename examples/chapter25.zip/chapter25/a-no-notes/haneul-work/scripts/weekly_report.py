"""주간 광고 보고서 자동 생성

'다운로드/광고리포트' 폴더의 네이버·메타·구글 원본 파일을 읽어
'보고서/주간보고_NN주.xlsx' 를 만든다. 양식은 '다운로드/문서/주간보고_42주.xlsx' 를 그대로 복사해 쓴다.

- 원본 파일은 읽기만 한다 (실행 전후 해시로 확인).
- 폴더에 여러 주 파일이 쌓여 있으면 가장 최근 주를 고른다. 특정 주는 `--week 43` 처럼 지정.
- 같은 이름의 보고서가 이미 있으면 덮어쓰지 않고 멈춘다.
- 외부 라이브러리 없이 Python 기본 기능만 쓴다.
"""

import csv
import datetime as dt
import hashlib
import os
import re
import sys
import zipfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from xml.sax.saxutils import escape

BASE = Path(__file__).resolve().parent.parent
SRC_DIR = BASE / "다운로드" / "광고리포트"
TEMPLATE = BASE / "다운로드" / "문서" / "주간보고_42주.xlsx"
OUT_DIR = BASE / "보고서"
PREV_DIRS = [OUT_DIR, BASE / "다운로드" / "문서"]

CHANNEL_ORDER = ["네이버", "메타", "구글"]
METRICS = ["cost", "impr", "clicks", "conv"]

# 채널별 원본 칸 이름. 헤더 줄에 이 이름들이 모두 있으면 그 채널 파일로 본다.
# conv_campaign: (캠페인 칸 이름, 캠페인 이름) — 전환은 이 캠페인 줄만 센다. 비용·노출·클릭은 전체 캠페인.
# 메타는 2026-10-26(44주 이후 보고서)부터 '가을신상_리타겟팅' Results만 전환으로 세기로 했다.
CHANNEL_SPECS = {
    "메타": {"date": "Day", "cost": "Amount spent (KRW)", "impr": "Impressions",
             "clicks": "Link clicks", "conv": "Results", "total_label": None,
             "conv_campaign": ("Campaign name", "가을신상_리타겟팅")},
    "네이버": {"date": "일자", "cost": "총비용(원)", "impr": "노출수",
              "clicks": "클릭수", "conv": "전환수", "total_label": "합계"},
    "구글": {"date": "일", "cost": "비용", "impr": "노출수",
             "clicks": "클릭수", "conv": "전환수", "total_label": "총계"},
}

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"


class ReportError(Exception):
    pass


# ---------- 파일 읽기 ----------

def col_index(ref):
    letters = re.match(r"[A-Z]+", ref).group(0)
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def read_xlsx_rows(path):
    """첫 번째 시트를 문자열 리스트의 리스트로 읽는다."""
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            x = z.read("xl/sharedStrings.xml").decode("utf-8")
            for si in re.findall(r"<si>(.*?)</si>", x, re.S):
                shared.append(unescape_xml("".join(re.findall(r"<t[^>]*>(.*?)</t>", si, re.S))))
        sheet = sorted(n for n in z.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n))[0]
        x = z.read(sheet).decode("utf-8")
    rows = []
    for row in re.findall(r"<row[^>]*>(.*?)</row>", x, re.S):
        cells = {}
        for ref, attrs, inner in re.findall(r'<c r="([A-Z]+\d+)"([^>]*?)(?:/>|>(.*?)</c>)', row, re.S):
            t = re.search(r't="(\w+)"', attrs)
            v = re.search(r"<v>(.*?)</v>", inner or "", re.S)
            if t and t.group(1) == "inlineStr":
                val = unescape_xml("".join(re.findall(r"<t[^>]*>(.*?)</t>", inner, re.S)))
            elif v is None:
                val = ""
            elif t and t.group(1) == "s":
                val = shared[int(v.group(1))]
            else:
                val = unescape_xml(v.group(1))
            cells[col_index(ref)] = val
        rows.append([cells.get(i, "") for i in range(max(cells) + 1)] if cells else [])
    return rows


def unescape_xml(s):
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
             .replace("&apos;", "'").replace("&amp;", "&"))


def read_csv_rows(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [row for row in csv.reader(f)]


def read_rows(path):
    if path.suffix.lower() == ".xlsx":
        return read_xlsx_rows(path)
    if path.suffix.lower() == ".csv":
        return read_csv_rows(path)
    return None


def parse_date(s):
    m = re.match(r"^\s*(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})\.?\s*$", s or "")
    return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


def parse_num(s, where):
    t = (s or "").replace(",", "").replace('"', "").strip()
    if t in ("", "-"):
        return Decimal(0)
    try:
        return Decimal(t)
    except Exception:
        raise ReportError(f"{where}: 숫자로 읽을 수 없는 값 '{s}'")


def parse_source(path):
    """채널을 알아내고 일별 데이터와 (있으면) 원본 합계 줄을 돌려준다. 광고 파일이 아니면 None."""
    rows = read_rows(path)
    if not rows:
        return None
    for channel, spec in CHANNEL_SPECS.items():
        names = [spec[k] for k in ["date"] + METRICS]
        if spec.get("conv_campaign"):
            names.append(spec["conv_campaign"][0])
        for hi, row in enumerate(rows):
            stripped = [c.strip() for c in row]
            if all(n in stripped for n in names):
                idx = {k: stripped.index(spec[k]) for k in ["date"] + METRICS}
                if spec.get("conv_campaign"):
                    idx["campaign"] = stripped.index(spec["conv_campaign"][0])
                return channel, *collect(path, rows[hi + 1:], hi + 1, idx, spec)
    return None


def collect(path, rows, offset, idx, spec):
    daily, total = [], None
    conv_campaign = spec.get("conv_campaign")
    conv_found = False
    for i, row in enumerate(rows, start=offset + 1):
        if not any(c.strip() for c in row):
            continue
        where = f"{path.name} {i}번째 줄"
        first = row[0].strip() if row else ""
        cell = lambda k: row[idx[k]] if idx[k] < len(row) else ""
        d = parse_date(cell("date"))
        if d:
            r = {"date": d, **{k: parse_num(cell(k), where) for k in METRICS}}
            if conv_campaign:
                if cell("campaign").strip() == conv_campaign[1]:
                    conv_found = True
                else:
                    r["conv"] = Decimal(0)
            daily.append(r)
        elif spec["total_label"] and first.startswith(spec["total_label"]):
            total = {k: parse_num(cell(k), where) for k in METRICS}
        else:
            raise ReportError(f"{where}: 날짜도 합계도 아닌 줄이 있어요 → {row}")
    if not daily:
        raise ReportError(f"{path.name}: 일별 데이터가 없어요")
    if conv_campaign and not conv_found:
        raise ReportError(f"{path.name}: 전환을 셀 캠페인 '{conv_campaign[1]}' 줄이 없어요. 캠페인 이름이 바뀌었는지 확인해 주세요.")
    return daily, total


# ---------- 주차 계산 ----------

def week_key(d):
    y, w, _ = d.isocalendar()
    return (y, w)


def week_monday(key):
    return dt.date.fromisocalendar(key[0], key[1], 1)


# ---------- 숫자 계산 ----------

def round_half_up(x):
    return int(x.quantize(Decimal(1), rounding=ROUND_HALF_UP))


def ratio(a, b):
    return round_half_up(a / b) if b else None


def summarize(daily):
    s = {k: sum((r[k] for r in daily), Decimal(0)) for k in METRICS}
    s["cpc"] = ratio(s["cost"], s["clicks"])
    s["cpa"] = ratio(s["cost"], s["conv"])
    return s


def num_out(x):
    if x is None:
        return None
    return int(x) if x == x.to_integral_value() else float(x)


# ---------- 지난주 보고서 & 메모 ----------

def read_report(path):
    data = {}
    for row in read_xlsx_rows(path):
        if row and row[0] in CHANNEL_ORDER + ["합계"] and len(row) >= 7:
            vals = [Decimal(v) if re.match(r"^-?\d+(\.\d+)?$", v or "") else None for v in row[1:7]]
            data[row[0]] = dict(zip(["cost", "impr", "clicks", "conv", "cpc", "cpa"], vals))
    return data


def pct(new, old):
    if new is None or old in (None, 0):
        return "-"
    p = (Decimal(new) - old) / old * 100
    return f"{p:+.1f}%"


def build_memo(cur, prev, prev_week):
    if prev is None:
        return f"메모: [자동] 지난주({prev_week}주) 보고서가 없어 비교하지 못했어요."
    t, pt = cur["합계"], prev.get("합계", {})
    conv_diff = t["conv"] - pt["conv"] if pt.get("conv") is not None else None
    parts = [f"메모: [자동] 지난주({prev_week}주) 대비 비용 {pct(t['cost'], pt.get('cost'))}",
             f"전환 {int(conv_diff):+d}건({pct(t['conv'], pt.get('conv'))})" if conv_diff is not None else "전환 -",
             f"전환당 비용 {pct(t['cpa'], pt.get('cpa'))}"]
    chans = ", ".join(f"{c} {pct(cur[c]['cpa'], prev.get(c, {}).get('cpa'))}" for c in CHANNEL_ORDER)
    return ", ".join(parts) + f" / 채널별 전환당 비용: {chans}"


# ---------- 엑셀 쓰기 ----------

def write_report(out_path, sheet_name, title, table, memo):
    strings = []

    def s(text):
        if text not in strings:
            strings.append(text)
        return strings.index(text)

    def str_cell(ref, text, style=None):
        st = f' s="{style}"' if style else ""
        return f'<c r="{ref}"{st} t="s"><v>{s(text)}</v></c>'

    def val_cell(ref, v):
        if v is None:
            return str_cell(ref, "-")
        return f'<c r="{ref}"><v>{v}</v></c>'

    dy = 'x14ac:dyDescent="0.25"'
    rows = [f'<row r="1" spans="1:1" s="1" customFormat="1" {dy}>{str_cell("A1", title, 1)}</row>']
    headers = ["채널", "비용(원)", "노출", "클릭", "전환", "CPC(원)", "전환당 비용(원)"]
    rows.append(f'<row r="3" spans="1:7" s="2" customFormat="1" {dy}>'
                + "".join(str_cell(f"{'ABCDEFG'[i]}3", h, 2) for i, h in enumerate(headers)) + "</row>")
    for r, name in enumerate(CHANNEL_ORDER + ["합계"], start=4):
        t = table[name]
        vals = [num_out(t["cost"]), num_out(t["impr"]), num_out(t["clicks"]), num_out(t["conv"]), t["cpc"], t["cpa"]]
        rows.append(f'<row r="{r}" spans="1:7" {dy}>' + str_cell(f"A{r}", name)
                    + "".join(val_cell(f"{'BCDEFG'[i]}{r}", v) for i, v in enumerate(vals)) + "</row>")
    rows.append(f'<row r="9" spans="1:1" {dy}>{str_cell("A9", memo)}</row>')

    with zipfile.ZipFile(TEMPLATE) as z:
        sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8")
        sheet = re.sub(r"<sheetData>.*</sheetData>", lambda _: "<sheetData>" + "".join(rows) + "</sheetData>", sheet, flags=re.S)
        sst = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="{NS}" '
               f'count="{len(strings)}" uniqueCount="{len(strings)}">'
               + "".join(f"<si><t>{escape(x)}</t></si>" for x in strings) + "</sst>")
        workbook = re.sub(r'(<sheet [^>]*name=")[^"]*(")', lambda m: m.group(1) + escape(sheet_name) + m.group(2),
                          z.read("xl/workbook.xml").decode("utf-8"))
        app = re.sub(r"(<TitlesOfParts>.*?<vt:lpstr>)[^<]*(</vt:lpstr>)", lambda m: m.group(1) + escape(sheet_name) + m.group(2),
                     z.read("docProps/app.xml").decode("utf-8"), flags=re.S)
        replaced = {"xl/worksheets/sheet1.xml": sheet, "xl/sharedStrings.xml": sst,
                    "xl/workbook.xml": workbook, "docProps/app.xml": app}
        tmp = out_path.with_suffix(".tmp")
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as out:
            for info in z.infolist():
                data = replaced[info.filename].encode("utf-8") if info.filename in replaced else z.read(info.filename)
                out.writestr(info, data)
    os.replace(tmp, out_path)


# ---------- 메인 ----------

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fmt(x):
    return "-" if x is None else f"{int(x):,}" if Decimal(x) == Decimal(x).to_integral_value() else f"{x:,}"


def main(argv):
    want_week = None
    if len(argv) >= 2 and argv[0] == "--week":
        want_week = int(argv[1])

    if not SRC_DIR.is_dir():
        raise ReportError(f"원본 폴더가 없어요: {SRC_DIR}")
    if not TEMPLATE.is_file():
        raise ReportError(f"양식 파일이 없어요: {TEMPLATE}")

    files = sorted(p for p in SRC_DIR.iterdir() if p.is_file() and p.suffix.lower() in (".csv", ".xlsx")
                   and not p.name.startswith("~$"))
    hashes_before = {p: sha256(p) for p in files}

    # 1) 파일마다 채널·주차 파악
    parsed = []
    for p in files:
        res = parse_source(p)
        if res is None:
            print(f"  (건너뜀) 광고 원본으로 보이지 않는 파일: {p.name}")
            continue
        channel, daily, total = res
        weeks = {week_key(r["date"]) for r in daily}
        if len(weeks) > 1:
            raise ReportError(f"{p.name}: 한 파일에 여러 주 데이터가 섞여 있어요 ({sorted(weeks)})")
        parsed.append({"path": p, "channel": channel, "daily": daily, "total": total, "week": weeks.pop()})
    if not parsed:
        raise ReportError("광고리포트 폴더에서 광고 원본 파일을 찾지 못했어요.")

    # 2) 대상 주 고르기
    all_weeks = sorted({x["week"] for x in parsed})
    if want_week:
        cands = [w for w in all_weeks if w[1] == want_week]
        if not cands:
            raise ReportError(f"{want_week}주 원본 파일이 없어요. 있는 주: {[w[1] for w in all_weeks]}")
        target = cands[-1]
    else:
        target = all_weeks[-1]
    mon = week_monday(target)
    sun = mon + dt.timedelta(days=6)
    week_no = target[1]
    print(f"\n대상 주: {week_no}주 ({mon:%Y-%m-%d} ~ {sun:%Y-%m-%d})")

    # 3) 채널별 파일 하나씩
    chosen = {}
    for ch in CHANNEL_ORDER:
        # 중복본이 있으면 '(1)' 같은 꼬리표 없는 짧은 이름을 대표로 쓴다
        cands = sorted((x for x in parsed if x["channel"] == ch and x["week"] == target),
                       key=lambda x: (len(x["path"].name), x["path"].name))
        if not cands:
            raise ReportError(f"{week_no}주 {ch} 원본 파일이 광고리포트 폴더에 없어요.")
        first = cands[0]
        for other in cands[1:]:
            if other["daily"] != first["daily"]:
                raise ReportError(f"{week_no}주 {ch} 파일이 여러 개인데 내용이 달라요: "
                                  + ", ".join(x["path"].name for x in cands) + " → 하나만 남겨 주세요.")
            print(f"  (참고) {other['path'].name} 은 {first['path'].name} 과 내용이 같아 한 번만 셌어요.")
        days = {r["date"] for r in first["daily"]}
        if len(days) != 7:
            print(f"  (주의) {first['path'].name}: 7일 중 {len(days)}일치 데이터만 있어요.")
        chosen[ch] = first
        print(f"  {ch}: {first['path'].name}")

    # 4) 집계
    table = {ch: summarize(chosen[ch]["daily"]) for ch in CHANNEL_ORDER}
    table["합계"] = summarize([r for ch in CHANNEL_ORDER for r in chosen[ch]["daily"]])

    # 5) 지난주 비교 메모
    prev_key = week_key(mon - dt.timedelta(days=7))
    prev_path = next((d / f"주간보고_{prev_key[1]}주.xlsx" for d in PREV_DIRS
                      if (d / f"주간보고_{prev_key[1]}주.xlsx").is_file()), None)
    prev = read_report(prev_path) if prev_path else None
    memo = build_memo(table, prev, prev_key[1])

    # 6) 저장
    OUT_DIR.mkdir(exist_ok=True)
    out_path = OUT_DIR / f"주간보고_{week_no}주.xlsx"
    if out_path.exists():
        raise ReportError(f"{out_path.name} 이 이미 있어요. 다시 만들려면 기존 파일 이름을 바꾸거나 다른 곳으로 옮긴 뒤 실행해 주세요.")
    title = f"주간 광고 보고서 ({week_no}주, {mon.month}/{mon.day}~{sun.month}/{sun.day})"
    write_report(out_path, f"{week_no}주", title, table, memo)

    # 7) 검산
    print("\n[검산] 원본 → 보고서")
    print(f"  {'채널':<4} {'항목':<4} {'원본 일별 합':>12} {'원본 합계줄':>12} {'보고서':>12}  결과")
    written = read_report(out_path)
    ok = True
    labels = {"cost": "비용", "impr": "노출", "clicks": "클릭", "conv": "전환"}
    for ch in CHANNEL_ORDER + ["합계"]:
        for k in METRICS:
            src_sum = table[ch][k]
            src_total = chosen[ch]["total"][k] if ch in chosen and chosen[ch]["total"] else None
            if ch == "합계":
                src_total = sum((table[c][k] for c in CHANNEL_ORDER), Decimal(0))
            rep = written[ch][k]
            good = rep == src_sum and (src_total is None or src_total == src_sum)
            ok &= good
            print(f"  {ch:<4} {labels[k]:<4} {fmt(src_sum):>12} {fmt(src_total) if src_total is not None else '(없음)':>12} "
                  f"{fmt(rep):>12}  {'OK' if good else '불일치!'}")
        for k, a, b in (("cpc", "cost", "clicks"), ("cpa", "cost", "conv")):
            expect = ratio(table[ch][a], table[ch][b])
            good = written[ch][k] == (Decimal(expect) if expect is not None else None)
            ok &= good
            if not good:
                print(f"  {ch} {k} 계산 불일치: 보고서 {written[ch][k]} / 기대 {expect}")
    unchanged = all(sha256(p) == h for p, h in hashes_before.items())
    ok &= unchanged
    print(f"  원본 파일 변경 여부: {'변경 없음' if unchanged else '변경됨!'}")
    print(f"  보고서 {memo}")
    print(f"\n{'완료' if ok else '검산에서 문제가 발견됐어요. 보고서를 확인해 주세요'}: {out_path}")
    return 0 if ok else 2


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except ReportError as e:
        print(f"\n[중단] {e}")
        sys.exit(1)
