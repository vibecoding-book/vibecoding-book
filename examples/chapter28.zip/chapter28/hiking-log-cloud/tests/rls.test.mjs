// 실제 Supabase에서 "자기 기록만 보고 고칠 수 있는지"를 시험 계정 두 개로 확인한다.
// 사용법: npm test
//
// .env에 필요한 값
//   SUPABASE_URL, SUPABASE_ANON_KEY   (공개용 키만. 관리자 키는 쓰지 않음)
//   TEST_A_PASSWORD, TEST_B_PASSWORD  (대시보드에서 만든 시험 계정의 비밀번호)
//   TEST_A_EMAIL, TEST_B_EMAIL        (없으면 test-a@example.com, test-b@example.com)
import { createClient } from "@supabase/supabase-js";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
process.loadEnvFile(path.join(root, ".env"));

const URL = process.env.SUPABASE_URL;
const KEY = process.env.SUPABASE_ANON_KEY;
const A = { label: "A", email: process.env.TEST_A_EMAIL || "test-a@example.com", password: process.env.TEST_A_PASSWORD };
const B = { label: "B", email: process.env.TEST_B_EMAIL || "test-b@example.com", password: process.env.TEST_B_PASSWORD };
const TAG = "[rls-test]";

for (const [name, value] of Object.entries({ SUPABASE_URL: URL, SUPABASE_ANON_KEY: KEY, TEST_A_PASSWORD: A.password, TEST_B_PASSWORD: B.password })) {
  if (!value) {
    console.error(`.env에 ${name}가 없습니다.`);
    process.exit(2);
  }
}
if (KEY.startsWith("sb_secret_")) {
  console.error("관리자 키로는 RLS를 시험할 수 없습니다. 공개용 키를 쓰세요.");
  process.exit(2);
}

// ---------- 작은 검사 도구 ----------
let passed = 0;
const failures = [];
function check(name, ok, detail = "") {
  if (ok) {
    passed++;
    console.log(`  통과  ${name}`);
  } else {
    failures.push(name);
    console.log(`  실패  ${name}${detail ? `\n         ${detail}` : ""}`);
  }
}
const show = (r) => JSON.stringify({ error: r.error?.message ?? null, data: r.data });
// 거부됨 = 오류가 났거나, 아무 행도 돌려받지 못함
const denied = (r) => !!r.error || !r.data || r.data.length === 0;

function newClient() {
  return createClient(URL, KEY, { auth: { persistSession: false, autoRefreshToken: false } });
}

async function signIn(who) {
  const client = newClient();
  const { data, error } = await client.auth.signInWithPassword({ email: who.email, password: who.password });
  if (error) {
    console.error(`${who.email} 로그인 실패: ${error.message}`);
    console.error("대시보드 Authentication → Users에서 계정이 있고 확인(Confirmed)됐는지, .env 비밀번호가 맞는지 보세요.");
    process.exit(2);
  }
  who.client = client;
  who.id = data.user.id;
  return who;
}

// 주인 본인 눈으로 행을 다시 읽는다 (상대방의 공격이 실제로 아무것도 바꾸지 못했는지 확인용)
async function readOwn(who, id) {
  const { data, error } = await who.client.from("hikes").select("*").eq("id", id).maybeSingle();
  if (error) throw new Error(`${who.label} 본인 행 읽기 실패: ${error.message}`);
  return data;
}

async function cleanup(who) {
  await who.client.from("hikes").delete().like("memo", `${TAG}%`);
}

// ---------- 시나리오 ----------
// attacker가 victim의 행(victimRow)에 할 수 있는 모든 방법을 시도한다
async function attackOther(attacker, victim, victimRow) {
  const db = attacker.client;
  const who = `${attacker.label}가 ${victim.label}의 기록을`;

  let r = await db.from("hikes").select("*");
  check(`${attacker.label}의 전체 조회에는 자기 기록만 나온다`,
    !r.error && r.data.length > 0 && r.data.every((h) => h.user_id === attacker.id), show(r));

  r = await db.from("hikes").select("*").eq("id", victimRow.id);
  check(`${who} id로 조회할 수 없다`, denied(r), show(r));

  r = await db.from("hikes").select("*").eq("user_id", victim.id);
  check(`${who} user_id로 조회할 수 없다`, denied(r), show(r));

  r = await db.from("hikes").select("*", { count: "exact", head: true }).eq("id", victimRow.id);
  check(`${who} 개수 세기로도 알아낼 수 없다`, !!r.error || r.count === 0, JSON.stringify({ error: r.error?.message, count: r.count }));

  r = await db.from("hikes").update({ mountain: "해킹됨" }).eq("id", victimRow.id).select();
  check(`${who} 수정할 수 없다`, denied(r), show(r));

  r = await db.from("hikes").delete().eq("id", victimRow.id).select();
  check(`${who} 삭제할 수 없다`, denied(r), show(r));

  r = await db.from("hikes")
    .upsert({ id: victimRow.id, hiked_on: "2000-01-01", mountain: "해킹됨", companions: "", memo: `${TAG} upsert` })
    .select();
  check(`${who} upsert(같은 id로 덮어쓰기)로 바꿀 수 없다`, denied(r), show(r));

  r = await db.from("hikes")
    .insert({ user_id: victim.id, hiked_on: "2000-01-01", mountain: "남의 이름으로", memo: `${TAG} 위장` })
    .select();
  check(`${attacker.label}가 ${victim.label} 명의로 기록을 만들 수 없다`, !!r.error, show(r));

  const after = await readOwn(victim, victimRow.id);
  check(`공격 뒤에도 ${victim.label}의 기록은 그대로다`,
    after && after.mountain === victimRow.mountain && after.hiked_on === victimRow.hiked_on &&
    after.memo === victimRow.memo && after.user_id === victim.id,
    JSON.stringify(after));
}

async function main() {
  console.log("시험 계정으로 로그인");
  await signIn(A);
  await signIn(B);
  check("두 시험 계정은 서로 다른 사용자다", A.id !== B.id);
  await cleanup(A);
  await cleanup(B);

  console.log("\n자기 기록 추가·수정·삭제");
  const insA = await A.client.from("hikes")
    .insert({ hiked_on: "2026-10-01", mountain: "북한산", companions: "B", memo: `${TAG} A의 기록` })
    .select().single();
  check("A가 자기 기록을 추가할 수 있다", !insA.error && insA.data.user_id === A.id, show(insA));
  const insB = await B.client.from("hikes")
    .insert({ hiked_on: "2026-10-02", mountain: "관악산", companions: "", memo: `${TAG} B의 기록` })
    .select().single();
  check("B가 자기 기록을 추가할 수 있다", !insB.error && insB.data.user_id === B.id, show(insB));
  if (insA.error || insB.error) throw new Error("기록을 추가하지 못해 이후 시험을 진행할 수 없습니다. schema.sql을 실행했는지 확인하세요.");
  const rowA = insA.data;
  const rowB = insB.data;

  let r = await A.client.from("hikes").update({ memo: `${TAG} A의 기록 (수정)` }).eq("id", rowA.id).select().single();
  check("A가 자기 기록을 수정할 수 있다", !r.error && r.data.memo === `${TAG} A의 기록 (수정)`, show(r));
  rowA.memo = r.data?.memo ?? rowA.memo;

  r = await A.client.from("hikes").update({ user_id: B.id }).eq("id", rowA.id).select();
  check("A가 자기 기록의 주인을 B로 바꿀 수 없다", denied(r), show(r));
  const stillA = await readOwn(A, rowA.id);
  check("주인 바꾸기 시도 뒤에도 기록은 A의 것이다", stillA?.user_id === A.id, JSON.stringify(stillA));

  const tmp = await A.client.from("hikes")
    .insert({ hiked_on: "2026-10-03", mountain: "지울 산", memo: `${TAG} 삭제용` }).select().single();
  r = await A.client.from("hikes").delete().eq("id", tmp.data?.id).select();
  check("A가 자기 기록을 삭제할 수 있다", !r.error && r.data.length === 1, show(r));

  console.log("\nA → B의 기록");
  await attackOther(A, B, rowB);

  console.log("\nB → A의 기록");
  await attackOther(B, A, rowA);

  console.log("\n로그인하지 않은 사람");
  const anon = newClient();
  r = await anon.from("hikes").select("*");
  check("로그인하지 않으면 기록이 하나도 보이지 않는다", denied(r), show(r));
  r = await anon.from("hikes").select("*").eq("id", rowA.id);
  check("로그인하지 않으면 id로도 조회할 수 없다", denied(r), show(r));
  r = await anon.from("hikes").select("*", { count: "exact", head: true });
  check("로그인하지 않으면 개수도 알 수 없다", !!r.error || r.count === 0, JSON.stringify({ error: r.error?.message, count: r.count }));
  r = await anon.from("hikes").insert({ hiked_on: "2000-01-01", mountain: "익명", memo: `${TAG} 익명` }).select();
  check("로그인하지 않으면 기록을 추가할 수 없다", !!r.error, show(r));
  r = await anon.from("hikes").insert({ user_id: A.id, hiked_on: "2000-01-01", mountain: "익명", memo: `${TAG} 익명` }).select();
  check("로그인하지 않으면 남의 명의로도 추가할 수 없다", !!r.error, show(r));
  r = await anon.from("hikes").update({ mountain: "해킹됨" }).eq("id", rowA.id).select();
  check("로그인하지 않으면 수정할 수 없다", denied(r), show(r));
  r = await anon.from("hikes").delete().eq("id", rowB.id).select();
  check("로그인하지 않으면 삭제할 수 없다", denied(r), show(r));
  const afterA = await readOwn(A, rowA.id);
  const afterB = await readOwn(B, rowB.id);
  check("익명 시도 뒤에도 A, B의 기록은 그대로다",
    afterA?.mountain === rowA.mountain && afterB?.mountain === rowB.mountain,
    JSON.stringify({ afterA, afterB }));

  console.log("\n로그아웃 뒤");
  await A.client.auth.signOut();
  r = await A.client.from("hikes").select("*");
  check("로그아웃한 A는 자기 기록도 보이지 않는다", denied(r), show(r));
  await signIn(A); // 정리용으로 다시 로그인
}

try {
  await main();
} catch (e) {
  failures.push(e.message);
  console.error(`\n중단됨: ${e.message}`);
} finally {
  if (A.client) await cleanup(A);
  if (B.client) await cleanup(B);
}

console.log(`\n결과: 통과 ${passed}개, 실패 ${failures.length}개`);
process.exit(failures.length ? 1 : 0);
