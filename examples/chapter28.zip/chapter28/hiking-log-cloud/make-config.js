// .env의 SUPABASE_URL, SUPABASE_ANON_KEY를 읽어 public/index.html이 쓰는 public/config.js를 만든다.
// 사용법: node make-config.js
const fs = require("node:fs");
const path = require("node:path");

process.loadEnvFile(path.join(__dirname, ".env"));
const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_ANON_KEY;

if (!url || !key) {
  console.error(".env에 SUPABASE_URL과 SUPABASE_ANON_KEY가 있어야 합니다.");
  process.exit(1);
}
// 브라우저에는 공개용 키만 내보낸다. 관리자 키가 들어 있으면 멈춘다.
function isAdminKey(k) {
  if (k.startsWith("sb_secret_")) return true;
  if (k.startsWith("eyJ")) {
    // 예전 형식(JWT) 키: 안쪽의 role이 service_role이면 관리자 키
    try {
      const payload = JSON.parse(Buffer.from(k.split(".")[1], "base64url").toString());
      return payload.role === "service_role";
    } catch {
      return false;
    }
  }
  return false;
}
if (isAdminKey(key)) {
  console.error("SUPABASE_ANON_KEY에 관리자 키가 들어 있습니다. publishable(anon) 키로 바꿔 주세요.");
  process.exit(1);
}

const out = `// node make-config.js 로 자동 생성된 파일입니다. 직접 고치지 마세요.
window.HIKING_CONFIG = ${JSON.stringify({ url, key }, null, 2)};
`;
fs.writeFileSync(path.join(__dirname, "public", "config.js"), out);
console.log("public/config.js를 만들었습니다.");
