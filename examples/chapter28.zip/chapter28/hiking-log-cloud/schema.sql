-- 등산 기록장 (hiking-log-cloud) 표 만들기
-- Supabase 대시보드 → SQL Editor에 전체를 붙여 넣고 Run 하세요.
-- 여러 번 실행해도 안전합니다(기존 기록은 지워지지 않음).

-- 1. 표 ---------------------------------------------------------------
create table if not exists public.hikes (
  id          uuid        primary key default gen_random_uuid(),
  -- 기록 주인. 앱이 따로 보내지 않아도 로그인한 사람의 id가 자동으로 들어감
  user_id     uuid        not null default auth.uid()
                          references auth.users (id) on delete cascade,
  hiked_on    date        not null,                         -- 날짜
  mountain    text        not null
              check (char_length(btrim(mountain)) between 1 and 100), -- 산 이름
  companions  text        not null default ''
              check (char_length(companions) <= 200),       -- 함께 간 사람
  memo        text        not null default ''
              check (char_length(memo) <= 2000),            -- 메모
  created_at  timestamptz not null default now()
);

create index if not exists hikes_user_id_hiked_on_idx
  on public.hikes (user_id, hiked_on desc);

-- 2. 권한 --------------------------------------------------------------
-- Supabase는 새 표에 anon(로그인 안 한 사람)과 authenticated(로그인한 사람)
-- 모두에게 넓은 권한을 기본으로 줍니다. 전부 거둔 뒤 필요한 것만 다시 줍니다.
-- (TRUNCATE 같은 권한은 RLS를 거치지 않으므로 반드시 거둬야 함)
revoke all on table public.hikes from anon, authenticated, public;

-- 로그인하지 않은 사람: 아무 권한 없음
-- 로그인한 사람: 조회·추가·삭제, 그리고 내용 칸만 수정 가능(주인 바꾸기 불가)
grant select, insert, delete on table public.hikes to authenticated;
grant update (hiked_on, mountain, companions, memo) on table public.hikes to authenticated;

-- 3. 행 수준 보안(RLS): 자기 기록만 -------------------------------------
alter table public.hikes enable row level security;

drop policy if exists "hikes_select_own" on public.hikes;
drop policy if exists "hikes_insert_own" on public.hikes;
drop policy if exists "hikes_update_own" on public.hikes;
drop policy if exists "hikes_delete_own" on public.hikes;

create policy "hikes_select_own" on public.hikes
  for select to authenticated
  using ((select auth.uid()) = user_id);

create policy "hikes_insert_own" on public.hikes
  for insert to authenticated
  with check ((select auth.uid()) = user_id);

create policy "hikes_update_own" on public.hikes
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy "hikes_delete_own" on public.hikes
  for delete to authenticated
  using ((select auth.uid()) = user_id);
