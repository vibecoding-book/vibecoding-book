# 등산 기록장 (클라우드 버전)

로그인해서 쓰는 등산 기록장입니다. 기록은 Supabase에 저장되고, 각자 자기 기록만 볼 수 있습니다.

## 파일

| 파일 | 하는 일 |
|---|---|
| `public/index.html` | 앱. 더블클릭해서 브라우저로 엽니다 |
| `public/config.js` | 브라우저용 접속 정보(주소·공개 키). `make-config.js`가 만듭니다 |
| `schema.sql` | 표와 보안 규칙(RLS). Supabase SQL Editor에 붙여 넣어 실행합니다 |
| `make-config.js` | `.env`를 읽어 `public/config.js`를 만듭니다 |
| `tests/rls.test.mjs` | 시험 계정 두 개로 "남의 기록은 보이지도 바뀌지도 않는지" 확인합니다 |

브라우저에 필요한 파일은 `public` 폴더에만 있습니다. 나머지(`.env`, `schema.sql`, `make-config.js`, `tests/` 등)는 내 컴퓨터에서만 쓰는 파일입니다.

## 처음 한 번 준비

1. **표 만들기**: Supabase 대시보드 → SQL Editor → `schema.sql` 내용을 전부 붙여 넣고 Run.
2. **이메일 인증 끄기**: Authentication → Sign In / Providers → Email → *Confirm email* 끄기.
3. **설정 파일 만들기**: 이 폴더에서
   ```
   npm install
   node make-config.js
   ```
4. `public/index.html`을 더블클릭해서 엽니다. 처음이면 이메일과 비밀번호를 넣고 **가입하기**를 누릅니다.

`.env`의 접속 정보를 바꿨다면 `node make-config.js`를 다시 실행하세요.
supabase-js를 CDN에서 불러오므로 인터넷 연결이 필요합니다.

## 인터넷에 올릴 때 (Netlify Drop 등)

**올릴 때는 `public` 폴더만 올립니다.** 프로젝트 폴더째 올리면 `.env`(시험 계정 비밀번호 포함)와 서버용 파일까지 누구나 내려받을 수 있게 됩니다.

1. `node make-config.js`를 실행해 `public/config.js`를 최신으로 만듭니다.
2. Netlify Drop 화면에 `public` 폴더를 끌어다 놓습니다.

`public/config.js`에는 공개용 키만 들어 있어 올려도 됩니다(관리자 키면 `make-config.js`가 멈춥니다). 기록 보호는 `schema.sql`의 보안 규칙(RLS)이 맡습니다.

## 보안 시험 (npm test)

시험 계정 두 개를 대시보드 Authentication → Users → Add user → Create new user에서
*Auto Confirm User*를 체크하고 만든 뒤, `.env`에 비밀번호를 적습니다.

```
TEST_A_PASSWORD=...
TEST_B_PASSWORD=...
# 주소가 다르면 지정 (기본: test-a@example.com, test-b@example.com)
# TEST_A_EMAIL=...
# TEST_B_EMAIL=...
```

그다음 `npm test`를 실행합니다. 시험하는 내용:

- 각자 자기 기록을 추가·수정·삭제할 수 있는지
- A가 B의 기록을 (그리고 B가 A의 기록을) 조회, id·user_id로 조회, 개수 세기, 수정, 삭제, upsert로 덮어쓰기, 상대 명의로 추가하는 것을 모두 막는지
- 자기 기록의 주인을 남으로 바꿀 수 없는지
- 로그인하지 않은 사람은 아무것도 보거나 바꿀 수 없는지, 로그아웃하면 다시 안 보이는지

시험이 만든 기록(메모가 `[rls-test]`로 시작)은 끝나면 지웁니다.
관리자 키(service_role, secret)는 쓰지 않습니다. 모든 시험은 브라우저와 똑같은 공개 키로 진행됩니다.

## 공개 전에 되돌릴 것 (실습용으로 바꾼 설정)

- Supabase → Authentication → Sign In / Providers → **Confirm email**: 실습 중 꺼 두었음. 공개 전에 다시 켜기
- Supabase → Authentication → Users: 시험 계정 test-a@example.com, test-b@example.com 삭제
- .env의 TEST_A_PASSWORD, TEST_B_PASSWORD 줄 삭제
- 올릴 때는 public 폴더만
