# CLAUDE.md

## 김하늘의 작업 규칙 (항상 지킬 것)

1. 기능을 추가하거나 바꾸면 plan.md도 같이 고친다. '나중에' 목록에서 이번에 만든 것은 '이번에 만들 것'으로 옮기고, '7. 완성의 기준'에 확인할 문장을 한 줄 이상 더한다.
2. 저장 이름(hikingRecords.v1)과 기록 항목 이름은 바꾸지 않는다. 이미 휴대폰에 쌓인 기록이 사라지면 안 된다.
3. 요청한 것만 고친다. 더 넣고 싶은 기능이 있으면 만들지 말고 끝에 제안만 한다.
4. 일을 마치면 아래 세 가지를 한국어로, 쉬운 말로 알려 준다.
   - 바꾼 파일과 바꾼 내용
   - 내가 휴대폰에서 직접 눌러 확인할 방법 (단계별)
   - 확인하지 못한 것

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

주말 등산 기록장 (weekend hiking log): a personal, phone-first, single-user app for logging a hike right after descending and seeing this year's hike count and total time. `plan.md` is the spec (in Korean): features, screens, data schema, explicit non-goals, and the acceptance checklist (§7 완성의 기준). Read it before changing behavior, and check changes against §7.

## Running

No build, package manager, lint, or test suite. Open `index.html` directly in a browser (it works over `file://`). Test at phone portrait width; the home screen must not scroll horizontally. All UI text is Korean.

## Hard constraints (from plan.md §6)

- Everything stays in **one HTML file**: inline CSS and JS, no external libraries, no CDN, no extra files.
- No server, login, sync, sharing, photos/GPX/maps, charts, or auto-backup. Export happens only when the user taps it.
- Only four fields need typing (mountain, course, memo, companions). Date, duration, and rating are picked by tapping, so keep it that way.

## Architecture (`index.html`)

- **Views:** three `<section>`s (`vHome`, `vForm`, `vBackup`) plus two fixed bottom bars (`bHome`, `bForm`). `show(view)` toggles the `.hidden` class on them. The form view handles both new and edit, and shows `delBtn` only in edit mode.
- **Routing:** hash-based (`#/`, `#/new`, `#/edit/<id>`, `#/backup`), handled by `route()` on `hashchange`. In-app navigation uses `go()`, which sets `fromApp` so that `goHome()` can call `history.back()` and keep history clean. On a direct load it uses `location.replace('#/')` instead.
- **State:** a single in-memory `records` array, the source of truth while the page is open. Every mutation follows the same pattern: keep `prev`, assign the new array, call `persist()`, and roll back to `prev` if persisting fails.
- **Storage:** localStorage key `hikingRecords.v1` holds the records array. `hikingLastExport.v1` holds the last export date. The export file (`hiking-backup-YYYY-MM-DD.json`) has exactly the same shape as the stored array.
- **Validation:** `isValidRecord` / `validateList` / `normalize` are shared by `load()` and import. Import rejects the entire file (malformed JSON, a bad record, or duplicate ids), and existing records are only replaced after a `confirm`. If you add or change a field, update all three functions and the schema in plan.md §5.
- **Record schema:** `id` (`"h_<timestamp>"`), `date` (`YYYY-MM-DD` string, compared as a string), `mountain`, `course`, `durationMin` (integer minutes, > 0), `rating` (1–5), `memo`, `companions` (`''` when empty).
- **Sorting:** newest date first. When dates tie, the newer id comes first. The yearly summary filters on `date.slice(0,4)` equal to the current year.
- **Rendering:** the home list is built as an HTML string, so all user text must go through `esc()`.
