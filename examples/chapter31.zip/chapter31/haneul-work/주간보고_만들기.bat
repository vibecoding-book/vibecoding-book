@echo off
rem Weekly ad report: double-click to run. Optional argument: --week 43
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 -I "%~dp0scripts\weekly_report.py" %*
) else (
    python -I "%~dp0scripts\weekly_report.py" %*
)
echo.
pause
