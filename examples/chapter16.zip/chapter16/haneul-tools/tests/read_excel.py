"""대시보드와 별개로 엑셀을 직접 읽어 '정답' 숫자를 JSON으로 출력합니다.

대시보드 코드를 전혀 쓰지 않고 Python 표준 라이브러리(zipfile, ElementTree)만 사용하므로,
대시보드의 엑셀 해석이 틀리면 테스트에서 드러납니다.

사용법: python -I tests/read_excel.py 파일1.xlsx 파일2.xlsx ...
"""
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def read(path):
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % NS["m"])))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        sheet_name = wb.find("m:sheets/m:sheet", NS).get("name")
        sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))

    cells = {}
    for c in sheet.iter("{%s}c" % NS["m"]):
        v = c.find("m:v", NS)
        if v is None:
            continue
        cells[c.get("r")] = shared[int(v.text)] if c.get("t") == "s" else float(v.text)

    # 3행이 머리글, A열 이름이 있는 4행부터가 데이터
    headers = {re.match(r"[A-Z]+", ref).group(): val for ref, val in cells.items() if ref.endswith("3") and re.fullmatch(r"[A-Z]+3", ref)}
    rows = {}
    r = 4
    while f"A{r}" in cells:
        rows[cells[f"A{r}"]] = {headers[col]: cells.get(f"{col}{r}") for col in headers if col != "A"}
        r += 1
    title = cells["A1"]
    return {
        "file": path,
        "sheet": sheet_name,
        "title": title,
        "week": int(re.search(r"(\d+)주", title).group(1)),
        "rows": rows,
        "memo": cells.get(f"A{r + 1}", ""),
    }


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps([read(p) for p in sys.argv[1:]], ensure_ascii=False))
