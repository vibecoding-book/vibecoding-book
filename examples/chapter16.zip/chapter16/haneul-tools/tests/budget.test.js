// 광고 예산 계산기(budget.html) 테스트: 계산 로직 + 실제 브라우저 화면
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { BUDGET, REPORTS, loadCore, readExcel, digits, launchBrowser, findBrowser } = require('./helpers');

const Core = loadCore(BUDGET, 'BudgetCore');
const SHOTS = path.join(__dirname, 'screenshots');
const NAMES = ['네이버', '메타', '구글'];
const ch = (ratios, cpas = [8224, 14417, 15653]) => NAMES.map((name, i) => ({ name, ratio: ratios[i], cpa: cpas[i] }));

// 정답: Python 분수(Fraction)로 오차 없이 따로 계산한 값
//   전체 = 반올림(목표 ÷ Σ(비율/전환당비용)),  채널 = 반올림(전체 × 비율, 0.5는 올림),  예상 전환 = 채널 ÷ 전환당비용
const CASES = [
  { title: '기본 비율 28/34/38, 목표 200건', target: 200, ratios: [28, 34, 38], cpas: [8224, 14417, 15653],
    rounded: 2441810, budgets: [683707, 830215, 927888], total: 2441810, conv: ['83.1', '57.6', '59.3'] },
  { title: '30/30/40, 목표 200건', target: 200, ratios: [30, 30, 40], cpas: [8224, 14417, 15653],
    rounded: 2414247, budgets: [724274, 724274, 965699], total: 2414247, conv: ['88.1', '50.2', '61.7'] },
  { title: '50/25/25, 목표 250건 (반올림으로 1원 차이)', target: 250, ratios: [50, 25, 25], cpas: [8224, 14417, 15653],
    rounded: 2656475, budgets: [1328238, 664119, 664119], total: 2656476, conv: ['161.5', '46.1', '42.4'] },
  { title: '네이버 전환당 비용을 9,000원으로 고침, 30/30/40, 목표 200건', target: 200, ratios: [30, 30, 40], cpas: [9000, 14417, 15653],
    rounded: 2509527, budgets: [752858, 752858, 1003811], total: 2509527, conv: ['83.7', '52.2', '64.1'] },
  { title: '소수 비율 33.3/33.3/33.4, 목표 1,000건 (반올림으로 1원 차이)', target: 1000, ratios: [33.3, 33.3, 33.4], cpas: [8224, 14417, 15653],
    rounded: 11774854, budgets: [3921026, 3921026, 3932801], total: 11774853, conv: ['476.8', '272.0', '251.2'] },
];

// ---------- 계산 로직 ----------
test('전환당 비용 기본값이 44주 보고서 엑셀 값과 같다', () => {
  const t44 = readExcel([REPORTS[2]])[0];
  assert.equal(t44.week, 44);
  for (const c of Core.DEFAULT_CHANNELS) assert.equal(c.cpa, t44.rows[c.name]['전환당 비용(원)'], c.name);
  assert.deepEqual(Core.DEFAULT_CHANNELS.map((c) => c.cpa), [8224, 14417, 15653]);
  assert.equal(Core.DEFAULT_CHANNELS.reduce((a, c) => a + c.ratio, 0), 100, '기본 비율 합 100%');
});

for (const c of CASES) {
  test(`계산: ${c.title}`, () => {
    const r = Core.calculate({ target: c.target, channels: ch(c.ratios, c.cpas) });
    assert.equal(r.ok, true);
    assert.equal(r.roundedTotal, c.rounded);
    assert.deepEqual(r.rows.map((x) => x.budget), c.budgets);
    assert.equal(r.totalBudget, c.total);
    assert.deepEqual(r.rows.map((x) => x.conversions.toFixed(1)), c.conv);
    // 예상 전환의 합은 목표와 같아야 함 (원 단위 반올림 오차만 허용)
    assert.ok(Math.abs(r.totalConversions - c.target) < 0.01, `예상 전환 합 ${r.totalConversions}`);
    // 채널 예산 비중은 넣은 비율과 같아야 함
    r.rows.forEach((x, i) => assert.ok(Math.abs((x.budget / r.roundedTotal) * 100 - c.ratios[i]) < 0.001));
  });
}

test('비율 합이 100%가 아니면 계산하지 않고 얼마나 모자라거나 넘치는지 알려 준다', () => {
  const short = Core.calculate({ target: 200, channels: ch([28, 34, 33]) });
  assert.equal(short.ok, false);
  assert.equal(short.sumRatio, 95);
  assert.deepEqual(short.errors.map((e) => e.text), ['예산 비율 합계가 95%입니다. 100%가 되도록 5%를 더 채워 주세요.']);
  const over = Core.calculate({ target: 200, channels: ch([30, 40, 40]) });
  assert.match(over.errors[0].text, /합계가 110%입니다\. 100%가 되도록 10%를 줄여 주세요/);
  const decimals = Core.calculate({ target: 200, channels: ch([33.3, 33.3, 33.4]) });
  assert.equal(decimals.ok, true, '33.3+33.3+33.4는 100%로 인정 (소수 오차 무시)');
});

test('잘못된 입력은 어느 칸이 문제인지 알려 준다', () => {
  const errs = (target, ratios, cpas) => Core.calculate({ target, channels: ch(ratios, cpas) }).errors.map((e) => e.field);
  assert.deepEqual(errs(null, [28, 34, 38]), ['target']);
  assert.deepEqual(errs(0, [28, 34, 38]), ['target']);
  assert.deepEqual(errs(200, [28, null, 38]), ['ratio-1']);
  assert.deepEqual(errs(200, [-10, 72, 38]), ['ratio-0']);
  assert.deepEqual(errs(200, [28, 34, 38], [8224, 0, 15653]), ['cpa-1']);
  assert.deepEqual(errs(200, [28, 34, 38], [8224, 14417, null]), ['cpa-2']);
});

test('입력칸의 쉼표·단위는 무시하고 숫자로 읽는다', () => {
  assert.equal(Core.parseInput('8,224'), 8224);
  assert.equal(Core.parseInput(' 800건 '), 800);
  assert.equal(Core.parseInput('33.3%'), 33.3);
  assert.equal(Core.parseInput(''), null);
  assert.equal(Core.parseInput('abc'), null);
  assert.equal(Core.parseInput('1.2.3'), null);
});

// ---------- 실제 브라우저 화면 ----------
const skip = findBrowser() ? false : 'Edge/Chrome이 없어 화면 테스트를 건너뜁니다';
let page;
test.before(async () => { if (!skip) { page = await launchBrowser(); await page.open(1000, BUDGET); } });
test.after(async () => { if (page) await page.close(); });

const snap = () => page.evaluate(`(() => {
  const q = (s) => document.querySelector(s);
  const rows = [...document.querySelectorAll('#result-body tr')].map((tr) => ({
    channel: tr.dataset.channel,
    budget: tr.querySelector('[data-field="budget"]').textContent,
    conversions: tr.querySelector('[data-field="conversions"]').textContent,
  }));
  return {
    inputs: Object.fromEntries([...document.querySelectorAll('input')].map((i) => [i.id, i.value])),
    invalid: [...document.querySelectorAll('input[aria-invalid="true"]')].map((i) => i.id),
    ratioSum: q('#ratio-sum').textContent,
    resultHidden: q('#result').hidden,
    placeholder: q('#placeholder').hidden ? null : q('#placeholder').textContent,
    notice: q('#notice').textContent,
    total: q('#total-budget').textContent,
    totalConv: q('#total-conv').textContent,
    totalNote: q('#total-note').textContent,
    rows,
    formula: [...q('#formula').querySelectorAll('code')].map((c) => c.textContent),
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: innerWidth,
  };
})()`);
const fmt = (n) => n.toLocaleString('ko-KR');
async function enter(c) {
  for (let i = 0; i < 3; i++) {
    await page.type(`#ratio-${i}`, String(c.ratios[i]));
    await page.type(`#cpa-${i}`, fmt(c.cpas[i]));
  }
  await page.type('#target', String(c.target));
}

test('화면: 처음 열면 44주 전환당 비용과 기본 비율이 채워져 있고, 목표를 기다린다', { skip }, async () => {
  const s = await snap();
  assert.deepEqual([s.inputs['cpa-0'], s.inputs['cpa-1'], s.inputs['cpa-2']], ['8,224', '14,417', '15,653']);
  assert.deepEqual([s.inputs['ratio-0'], s.inputs['ratio-1'], s.inputs['ratio-2']], ['28', '34', '38']);
  assert.equal(s.ratioSum, '100%');
  assert.equal(s.resultHidden, true);
  assert.match(s.placeholder, /목표 전환 수를 넣으면/);
  assert.equal(s.notice, '', '처음에는 오류 안내 없음');
});

for (const c of CASES) {
  test(`화면: ${c.title}`, { skip }, async () => {
    await enter(c);
    const s = await snap();
    assert.equal(s.resultHidden, false);
    assert.equal(s.total, `${fmt(c.total)}원`);
    assert.equal(digits(s.total), c.total);
    assert.deepEqual(s.rows.map((r) => r.channel), [...NAMES, '합계']);
    assert.deepEqual(s.rows.slice(0, 3).map((r) => digits(r.budget)), c.budgets);
    assert.equal(digits(s.rows[3].budget), c.total);
    assert.deepEqual(s.rows.slice(0, 3).map((r) => r.conversions), c.conv);
    assert.equal(s.totalConv, `${fmt(c.target)}.0건`, '예상 전환 합 = 목표');
    // 계산식에 넣은 숫자가 그대로 대입되어 보인다
    const terms = c.ratios.map((r, i) => `${r}% ÷ ${fmt(c.cpas[i])}`).join(' + ');
    assert.ok(s.formula.includes(`= ${fmt(c.target)} ÷ (${terms})`), s.formula.join('\n'));
    assert.ok(s.formula.includes(`= ${fmt(c.rounded)}원`));
    NAMES.forEach((n, i) => {
      assert.ok(s.formula.includes(`${n} = ${fmt(c.rounded)} × ${c.ratios[i]}% = ${fmt(c.budgets[i])}원`), `${n} 예산 식`);
      assert.ok(s.formula.includes(`${n} = ${fmt(c.budgets[i])} ÷ ${fmt(c.cpas[i])} = ${c.conv[i]}건`), `${n} 전환 식`);
    });
    assert.ok(s.formula.includes(`합계 = ${c.budgets.map(fmt).join(' + ')} = ${fmt(c.total)}원`));
    if (c.total !== c.rounded) assert.match(s.totalNote, /1원 차이/);
    else assert.doesNotMatch(s.totalNote, /차이/);
  });
}

test('화면: 비율 합이 95%가 되면 안내하고 결과를 숨긴다, 100%로 고치면 다시 계산한다', { skip }, async () => {
  await enter(CASES[0]);
  await page.type('#ratio-2', '33');
  let s = await snap();
  assert.equal(s.ratioSum, '95%');
  assert.match(s.notice, /예산 비율 합계가 100%가 아닙니다/);
  assert.match(s.notice, /합계가 95%입니다\. 100%가 되도록 5%를 더 채워 주세요/);
  assert.deepEqual(s.invalid, ['ratio-0', 'ratio-1', 'ratio-2']);
  assert.equal(s.resultHidden, true);
  await page.screenshot(path.join(SHOTS, '5_예산_비율합오류.png'));
  await page.type('#ratio-2', '38');
  s = await snap();
  assert.equal(s.ratioSum, '100%');
  assert.equal(s.notice, '');
  assert.equal(s.total, '2,441,810원');
});

test('화면: 전환당 비용 칸을 비우거나 0을 넣으면 그 칸을 알려 주고, 기본값 버튼으로 되돌린다', { skip }, async () => {
  await enter(CASES[0]);
  await page.type('#cpa-1', '0');
  let s = await snap();
  assert.deepEqual(s.invalid, ['cpa-1']);
  assert.match(s.notice, /메타 전환당 비용은 0보다 커야 합니다/);
  assert.equal(s.resultHidden, true);
  await page.type('#cpa-0', '9000');
  await page.evaluate("document.getElementById('reset-cpa').click()");
  s = await snap();
  assert.deepEqual([s.inputs['cpa-0'], s.inputs['cpa-1'], s.inputs['cpa-2']], ['8,224', '14,417', '15,653']);
  assert.equal(s.total, '2,441,810원');
});

test('화면: 기본값으로 목표 200건을 넣은 모습 (스크린숏) · 휴대폰 폭에서도 가로 스크롤 없음', { skip }, async () => {
  await enter(CASES[0]);
  await page.screenshot(path.join(SHOTS, '4_예산_기본값_200건.png'));
  await page.setWidth(390);
  const s = await snap();
  assert.ok(s.scrollWidth <= s.innerWidth, `scrollWidth ${s.scrollWidth} > ${s.innerWidth}`);
  await page.screenshot(path.join(SHOTS, '6_예산_휴대폰폭.png'));
  await page.setWidth(1000);
});

test('화면: 외부로 나간 요청이 없고 페이지 오류도 없다', { skip }, async () => {
  assert.deepEqual(page.requests.filter((u) => !/^(file|data|blob|about):/.test(u)), []);
  assert.deepEqual(page.consoleErrors, []);
  assert.equal(await page.evaluate(`fetch('https://example.com/x').then(() => 'sent', () => 'blocked')`), 'blocked');
});
