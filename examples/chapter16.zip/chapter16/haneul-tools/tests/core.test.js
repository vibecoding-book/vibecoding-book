// 대시보드 핵심 로직(엑셀 해석 · 중복 처리 · 증감 계산) 테스트
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPORTS, fixture, loadCore, readExcel, ensureFixtures, parseMemo } = require('./helpers');

const Core = loadCore();
ensureFixtures();
const truth = readExcel(REPORTS); // Python이 따로 읽은 정답
const FIELDS = { cost: '비용(원)', impressions: '노출', clicks: '클릭', conversions: '전환', cpc: 'CPC(원)', cpa: '전환당 비용(원)' };
const parse = (file) => Core.parseReport(fs.readFileSync(file), path.basename(file));

test('엑셀 3개의 모든 숫자를 엑셀과 똑같이 읽는다 (채널 3개 + 합계 × 6개 항목)', async () => {
  let checked = 0;
  for (const t of truth) {
    const r = await parse(t.file);
    assert.equal(r.week, t.week);
    assert.equal(r.sheetName, t.sheet);
    assert.deepEqual(r.warnings, [], `${t.week}주 경고 없음`);
    for (const [name, row] of Object.entries(t.rows)) {
      const got = name === '합계' ? r.total : r.channels.find((c) => c.name === name);
      assert.ok(got, `${t.week}주 ${name} 행`);
      for (const [key, header] of Object.entries(FIELDS)) {
        assert.equal(got[key], row[header], `${t.week}주 ${name} ${header}`);
        checked++;
      }
    }
    assert.equal(r.channels.length, Object.keys(t.rows).length - 1);
  }
  assert.equal(checked, 3 * 4 * 6);
});

test('주차와 기간을 제목에서 읽는다', async () => {
  const periods = [];
  for (const f of REPORTS) periods.push((await parse(f)).period);
  assert.deepEqual(periods, ['10/12~10/18', '10/19~10/25', '10/26~11/1']);
});

test('최근 주(44주) 카드 값과 지난주 대비 증감이 엑셀 합계·메모와 일치한다', async () => {
  const store = Core.createStore();
  for (const f of REPORTS) Core.addReport(store, await parse(f));
  const s = Core.summarize(store);
  const t44 = truth[2].rows['합계'];
  const t43 = truth[1].rows['합계'];
  assert.equal(s.latest.week, 44);
  assert.equal(s.prev.week, 43);
  assert.equal(s.kpis.cost.value, t44['비용(원)']);
  assert.equal(s.kpis.conversions.value, t44['전환']);
  assert.equal(s.kpis.cpa.value, t44['전환당 비용(원)']);
  assert.equal(s.kpis.cost.diff, t44['비용(원)'] - t43['비용(원)']);
  assert.equal(s.kpis.conversions.diff, t44['전환'] - t43['전환']);

  // 엑셀 메모에 사람이(또는 다른 도구가) 적어 둔 증감률과 비교
  const memo = parseMemo(truth[2].memo);
  assert.equal(s.kpis.cost.pct, memo.costPct);
  assert.equal(s.kpis.conversions.diff, memo.convDiff);
  assert.equal(s.kpis.conversions.pct, memo.convPct);
  assert.equal(s.kpis.cpa.pct, memo.cpaPct);
});

test('채널별 전환당 비용 증감이 43주·44주 메모와 일치한다', async () => {
  const store = Core.createStore();
  for (const f of REPORTS) Core.addReport(store, await parse(f));
  const s = Core.summarize(store);
  for (const wi of [1, 2]) {
    const memo = parseMemo(truth[wi].memo);
    assert.equal(Object.keys(memo.channels).length, 3);
    for (const [name, pct] of Object.entries(memo.channels)) {
      const series = s.cpaSeries.find((x) => x.name === name);
      assert.equal(Core.pctChange(series.values[wi], series.values[wi - 1]), pct, `${s.weeks[wi]}주 ${name}`);
    }
  }
});

test('그래프 데이터: 채널별 비용·전환당 비용이 주차 순서대로 엑셀 값과 같다', async () => {
  const store = Core.createStore();
  for (const f of [...REPORTS].reverse()) Core.addReport(store, await parse(f)); // 넣는 순서를 거꾸로 해도
  const s = Core.summarize(store);
  assert.deepEqual(s.weeks, [42, 43, 44]);
  assert.deepEqual(s.channels, ['네이버', '메타', '구글']);
  for (const name of s.channels) {
    assert.deepEqual(s.costSeries.find((x) => x.name === name).values, truth.map((t) => t.rows[name]['비용(원)']));
    assert.deepEqual(s.cpaSeries.find((x) => x.name === name).values, truth.map((t) => t.rows[name]['전환당 비용(원)']));
  }
  assert.deepEqual(s.totalCpa, truth.map((t) => t.rows['합계']['전환당 비용(원)']));
});

test('같은 주 파일을 두 번 넣으면 한 번만 반영된다 (같은 파일 · 이름만 다른 사본)', async () => {
  const store = Core.createStore();
  assert.equal(Core.addReport(store, await parse(REPORTS[2])).action, 'added');
  assert.equal(Core.addReport(store, await parse(REPORTS[2])).action, 'duplicate');
  assert.equal(Core.addReport(store, await parse(fixture('주간보고_44주_사본.xlsx'))).action, 'duplicate');
  assert.equal(store.weeks.size, 1);
  assert.equal(store.weeks.get(44).fileName, '주간보고_44주.xlsx', '처음 파일이 유지됨');
});

test('같은 주인데 숫자가 다른 수정본은 나중 파일로 교체된다', async () => {
  const store = Core.createStore();
  for (const f of REPORTS) Core.addReport(store, await parse(f));
  const res = Core.addReport(store, await parse(fixture('주간보고_44주_수정본.xlsx')));
  assert.equal(res.action, 'replaced');
  assert.equal(res.previousFile, '주간보고_44주.xlsx');
  assert.equal(store.weeks.size, 3);
  assert.equal(Core.summarize(store).kpis.cost.value, 2453512);
});

test('지난주 파일이 없으면 증감을 계산하지 않는다', async () => {
  const store = Core.createStore();
  Core.addReport(store, await parse(REPORTS[0]));
  Core.addReport(store, await parse(REPORTS[2]));
  const s = Core.summarize(store);
  assert.equal(s.latest.week, 44);
  assert.equal(s.prev, null);
  assert.equal(s.kpis.cost.pct, null);
});

const BAD = [
  ['양식다름_머리글.xlsx', /필요한 열이 없습니다: '비용\(원\)', '전환'/],
  ['양식다름_주차없음.xlsx', /몇 주차 보고서인지 알 수 없습니다/],
  ['양식다름_숫자아님.xlsx', /B5 셀\(메타 · 비용\(원\)\): 숫자가 아닙니다 \('약 82만'\)/],
  ['양식다름_다른표.xlsx', /'채널' 머리글이 있는 표를 찾지 못했습니다/],
  ['엑셀아님.xlsx', /엑셀\(\.xlsx\) 파일이 아닙니다/],
  ['예전형식.xls', /예전 엑셀 형식\(\.xls\)/],
];
for (const [name, expected] of BAD) {
  test(`양식이 다른 파일은 무엇이 문제인지 알려 준다: ${name}`, async () => {
    await assert.rejects(parse(fixture(name)), (err) => {
      assert.equal(err.name, 'ReportError');
      assert.match(err.problems.join('\n'), expected);
      return true;
    });
  });
}
